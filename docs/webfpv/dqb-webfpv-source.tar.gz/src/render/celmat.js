/*
 * celmat.js: the cel shading model.
 *
 * The thing that separates a good cel shaded world from a flat one is not
 * the banding, it is that light and shadow are different HUES, not the
 * same hue at two brightnesses. Sunlit surfaces go warm, shadowed surfaces
 * go toward the blue of the sky bouncing into them. Breath of the Wild
 * leans on this constantly and it is why its shadows read as air rather
 * than as dirt.
 *
 * That is done here with a coloured gradient ramp. Three.js samples
 * MeshToonMaterial's gradientMap by N dot L and multiplies the result into
 * the base colour, so an RGB ramp that runs cool to warm gives the split
 * for free while keeping Three's own shadow, fog and light machinery.
 *
 * On top, onBeforeCompile injects two things Three's toon material does
 * not have: a fresnel rim light tinted toward the sky, which separates
 * silhouettes from the background at distance, and a specular band for a
 * hard painted highlight on the craft.
 *
 * This file is part of WebFPVSimulator.
 *
 * WebFPVSimulator is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at
 * your option) any later version.
 *
 * WebFPVSimulator is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY, without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebFPVSimulator. If not, see <https://www.gnu.org/licenses/>.
 */

import * as THREE from 'three';
/* Installs the comic layer on every toon material before any is built. */
import './comic.js';
import { latticeMap, latticeNoiseGlsl } from './lattice.js';

/*
 * Three.js samples the toon gradient map as
 *   return vec3( texture2D( gradientMap, coord ).r );
 * that is, it takes the red channel and splats it to grey. The whole
 * point of the ramp below is that shadow and light are different HUES,
 * and that is thrown away before it reaches a single pixel: every
 * shadowed surface comes out as a grey copy of the lit one, which is
 * exactly what a flat, cheap looking stylised render is.
 *
 * Patch the chunk once, at import, so the ramp is sampled in colour. This
 * keeps all of Three's shadow, fog and light plumbing intact. The guard
 * matters: a Three version bump that rewords this line would otherwise
 * silently drop the renderer back to greyscale with nothing to show for
 * it, and that is a bug nobody would find by looking at the code.
 */
{
  const before = THREE.ShaderChunk.gradientmap_pars_fragment;
  const after = before.replace(
    'vec3( texture2D( gradientMap, coord ).r )',
    'texture2D( gradientMap, coord ).rgb',
  );
  if (after === before) {
    throw new Error(
      'celmat: could not patch gradientmap_pars_fragment for RGB toon ramps. ' +
        'Three.js changed the chunk; the cel shading would silently render grey.',
    );
  }
  THREE.ShaderChunk.gradientmap_pars_fragment = after;
}

/*
 * Four band ramp, cool shadow to warm light. The steps are deliberately
 * uneven: a wide lit band, a narrow terminator, then two shadow bands, so
 * most of a curved surface reads as one flat shape with a crisp edge,
 * which is what makes it look drawn rather than shaded.
 */
function celRamp() {
  /* Seven bands, cool shadow to warm light, from the Gem look (look.js). More, finer steps than
   * the four it had, so neighbouring facets of a polygon land on different tones. The ramp is a
   * texture's content: it costs nothing a pixel that the four band one did not. The warm sliver
   * at the terminator is kept, because a surface half in shade reads tan and not grey. */
  const bands = [
    [0.00, [0.26, 0.30, 0.58]],
    [0.30, [0.36, 0.41, 0.68]],
    [0.40, [0.50, 0.56, 0.80]],
    [0.46, [0.88, 0.76, 0.64]],
    [0.54, [0.97, 0.84, 0.66]],
    [0.66, [1.00, 0.97, 0.88]],
    [0.82, [1.00, 1.00, 0.96]],
  ];
  const width = 64;
  const data = new Uint8Array(width * 4);
  for (let i = 0; i < width; i += 1) {
    const t = i / (width - 1);
    let band = 0;
    for (let k = 0; k < bands.length; k += 1) {
      if (t >= bands[k][0]) {
        band = k;
      }
    }
    const c = bands[band][1];
    data[i * 4 + 0] = Math.round(c[0] * 255);
    data[i * 4 + 1] = Math.round(c[1] * 255);
    data[i * 4 + 2] = Math.round(c[2] * 255);
    data[i * 4 + 3] = 255;
  }
  const tex = new THREE.DataTexture(data, width, 1, THREE.RGBAFormat);
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  return tex;
}

let RAMP = null;
export function celRampTexture() {
  if (!RAMP) {
    RAMP = celRamp();
  }
  return RAMP;
}

const RIM_CHUNK = /* glsl */ `
  vec3 celN = normalize(vNormal);
  vec3 celV = normalize(vViewPosition);
  float celRim = 1.0 - max(dot(celN, celV), 0.0);
  celRim = smoothstep(uRimStart, 1.0, celRim);
  /*
   * Falloff, not a step. This used to be step(0.5, celRim), on the theory
   * that a quantised rim matches the quantised diffuse ramp. It does not:
   * the diffuse ramp is quantised across a whole surface, where the bands
   * read as light. A quantised rim is only ever a few pixels wide, so it
   * lands as a flat slab of constant colour hugging the silhouette, with
   * the ink outline on one side and the surface on the other. Measured on
   * a canopy edge that was a five pixel plateau at 0.296 between
   * neighbours at 0.139 and 0.121. Cubing the smoothstep keeps the rim
   * tight against the edge while giving it a gradient, so it reads as
   * light wrapping round the form.
   */
  celRim = celRim * celRim * celRim;
  /*
   * Couple the rim to the surface under it. A fixed pale colour added at
   * a fixed strength is the same absolute lift on a near black craft body
   * as on a white gate panel, which makes the rim the brightest thing in
   * frame on every dark asset. Scaling by the surface's own luminance
   * keeps the rim subordinate to what it is rimming.
   */
  float celRimLum = dot(gl_FragColor.rgb, vec3(0.2126, 0.7152, 0.0722));
  float celRimFit = mix(0.30, 1.0, clamp(celRimLum * 1.7, 0.0, 1.0));
  gl_FragColor.rgb += uRimColor * (celRim * uRimStrength * celRimFit);

  float celSpec = max(dot(reflect(-celV, celN), normalize(uSpecDir)), 0.0);
  celSpec = step(0.985 - uSpecWidth, celSpec);
  gl_FragColor.rgb += uSpecColor * celSpec * uSpecStrength;
`;

/*
 * Cloud shadows. Slow, soft shapes crawling across the landscape are the
 * single strongest signal that a stylised world is alive rather than a
 * diorama: they break up large flat areas, they give the terrain a sense
 * of scale, and they make the light feel like it comes from a sky rather
 * than from a lamp. Sampled from value noise at world position, three
 * octaves of a lattice that holds this shader's own hash (src/render/
 * lattice.js), a fetch each, where they were four hashes each until the
 * low end pass after the graphics sweep: a terrain pixel's cloud shadow was
 * about two hundred operations, on most of every frame's lower half.
 */
export const CLOUD_SHADOW_GLSL = /* glsl */ `
  ${latticeNoiseGlsl('celNoise', 'uCelNoise')}
  float celCloudShadow(vec2 world, float t) {
    vec2 p = world * 0.0032 + vec2(t * 0.010, t * 0.006);
    float n = celNoise(p) * 0.6 + celNoise(p * 2.3) * 0.3 + celNoise(p * 4.7) * 0.1;
    // wide soft edge: hard edged cloud shadows read as texture, not shadow
    return smoothstep(0.46, 0.66, n);
  }
`;

/*
 * Whether cel materials get their cloud shading at all, set per scene build
 * from the preset (buildFieldScene reads quality.js's field.clouds). The
 * shadow is three octaves of value noise per fragment, over the terrain,
 * the pitch and the clubhouse, which together are most of every frame's
 * lower half; on the integrated laptop of bug-435f6aaa the GPU spent 9.1 ms
 * of a 16.7 ms frame, and the noise is pure fill with every real shadow on
 * Low already gone. The guard in the shader is a uniform branch, so a zero
 * skips the noise without another program. A module flag rather than an
 * option threaded through every call site, because the terrain, the pitch
 * and the clubhouse are built by helpers that do not see the preset, and a
 * preset change rebuilds the world, so the flag is always set before any
 * material that reads it is built. The craft's materials are built at boot,
 * before any scene, and none carries a cloud shadow.
 */
let cloudShadowsOn = 1;

export function setCelCloudShadows(on) {
  cloudShadowsOn = on === false ? 0 : 1;
}

/*
 * Every live cel material's uCelTime uniform, keyed by the material so a
 * shader recompile OVERWRITES the entry instead of adding one, and pruned on
 * the material's own dispose event. This used to be a push-only array: every
 * celMaterial pushed its uniform in onBeforeCompile and nothing ever removed
 * it, so a field to city to field round trip left updateCelTime walking
 * dozens of dead uniform objects belonging to disposed materials, every
 * frame, growing for the life of the session.
 */
const registered = new Map();

/* Called once per frame by the scene: advances every cel material's clock. */
export function updateCelTime(t) {
  for (const u of registered.values()) {
    u.value = t;
  }
}

/* How many materials the per frame walk touches. Harness only: check 16's
 * round trip asserts this does not grow across a map swap. */
export function celTimeCount() {
  return registered.size;
}

/*
 * The cloth wave, injected into the vertex shader.
 *
 * A banner flag has to move or it reads as a painted board on a stick, and
 * moving 72 of them from JavaScript means 72 live meshes the scenery merger
 * cannot touch. So the motion lives in the shader and the geometry stays
 * static, which is what lets every sail on the field merge into ONE draw
 * call and still fly.
 *
 * The weight comes from a per vertex attribute rather than from uv, because
 * three only declares the uv attribute when a uv sampled map is present and
 * a plain coloured sail has none. `aCloth.x` is the distance from the pole,
 * 0 on the seam and 1 on the free edge; `aCloth.y` is the height up the
 * sail. The seam therefore never moves, which is the whole point: a flag
 * that leaves its pole is the defect this replaced.
 *
 * The phase is taken from the vertex's WORLD position, so flags a few metres
 * apart are out of step with each other without carrying a per flag uniform,
 * and the merge stays legal.
 */
export const CLOTH_CHUNK = /* glsl */ `
  {
    vec3 clothWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;
    float clothPh = uCelTime * 2.9 + clothWorld.x * 0.55 + clothWorld.z * 0.41;
    /* Squared, so the seam is still and the free edge carries the travel. */
    float clothAmt = aCloth.x * aCloth.x;
    float clothFlap =
      sin(clothPh + aCloth.y * 3.4) * 0.62 +
      sin(clothPh * 1.73 + aCloth.x * 5.1) * 0.38;
    transformed += normalize(normal) * (clothFlap * clothAmt * uCloth);
    /* A little lift on the free edge as it snaps, so the cloth reads as
     * light fabric rather than as a swinging plank. */
    transformed.y += clothFlap * clothAmt * uCloth * 0.22;
  }
`;

/* Amplitude the field's sails actually use. The next-flag glow overlay
 * has to use this same number or it sits as a stiff sheet in front of
 * the cloth. */
export const FLAG_SAIL_CLOTH = 0.085;

/*
 * opts: color, rim (0..1), rimColor, spec (0..1), specWidth, cloudShadow,
 * map, alphaTest, cloth, key, comic ('ground' or 'foliage')
 *
 * `map` needs `key`, and that is enforced rather than documented. The
 * scenery merger buckets geometry by celKey and celKey is the options
 * object as JSON, in which two different textures are both the empty
 * object: two logos would merge into one bucket and one of them would
 * silently vanish. Naming the key is the caller saying which texture this
 * is.
 */
export function celMaterial(opts = {}) {
  if (opts.map && !opts.key) {
    throw new Error('celmat: a material with a map needs an explicit key');
  }
  const mat = new THREE.MeshToonMaterial({
    color: opts.color ?? 0xffffff,
    gradientMap: celRampTexture(),
    map: opts.map ?? null,
    alphaTest: opts.alphaTest ?? 0,
    transparent: opts.transparent ?? false,
    opacity: opts.opacity ?? 1,
    side: opts.side ?? THREE.FrontSide,
    /* fog false is for the mountain rings: their baked colours ARE the
     * aerial perspective, in deliberate steps; scene fog would wash all
     * of them to one wall. */
    fog: opts.fog ?? true,
  });
  const rimColor = new THREE.Color(opts.rimColor ?? 0x9ec8ff);
  const specColor = new THREE.Color(opts.specColor ?? 0xffffff);
  const cloud = (opts.cloudShadow ?? 0) * cloudShadowsOn;
  const cloth = opts.cloth ?? 0;
  /* The two injections cloth decides, named once. See the cache key below:
   * these strings ARE the key, so the condition cannot be changed in one
   * place and forgotten in the other. */
  const clothDecl = cloth > 0 ? 'attribute vec2 aCloth;' : '';
  const clothBody = cloth > 0 ? CLOTH_CHUNK : '';
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uCloth = { value: cloth };
    shader.uniforms.uRimColor = { value: rimColor };
    shader.uniforms.uRimStrength = { value: opts.rim ?? 0.32 };
    shader.uniforms.uRimStart = { value: opts.rimStart ?? 0.55 };
    shader.uniforms.uSpecColor = { value: specColor };
    shader.uniforms.uSpecStrength = { value: opts.spec ?? 0.0 };
    shader.uniforms.uSpecWidth = { value: opts.specWidth ?? 0.01 };
    shader.uniforms.uSpecDir = { value: new THREE.Vector3(0.45, 0.8, 0.4) };
    shader.uniforms.uCloudShadow = { value: cloud };
    /* The lattice that holds this shader's own hash (lattice.js), built
     * only by a material that draws a cloud shadow; the rest bind three's
     * empty texture, which they never read. */
    shader.uniforms.uCelNoise = { value: cloud > 0 ? latticeMap('cel') : null };
    shader.uniforms.uCelTime = { value: 0 };
    shader.uniforms.uCloudTint = { value: new THREE.Color(0x8397be) };
    if (!registered.has(mat)) {
      mat.addEventListener('dispose', () => {
        registered.delete(mat);
      });
    }
    registered.set(mat, shader.uniforms.uCelTime);

    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
         varying vec3 vCelWorld;
         uniform float uCelTime;
         uniform float uCloth;
         ${clothDecl}`,
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
         ${clothBody}
         vCelWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;`,
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
         varying vec3 vCelWorld;
         uniform vec3 uRimColor;
         uniform float uRimStrength;
         uniform float uRimStart;
         uniform vec3 uSpecColor;
         uniform float uSpecStrength;
         uniform float uSpecWidth;
         uniform vec3 uSpecDir;
         uniform float uCloudShadow;
         uniform float uCelTime;
         uniform vec3 uCloudTint;
         ${CLOUD_SHADOW_GLSL}`,
      )
      .replace(
        '#include <dithering_fragment>',
        `#include <dithering_fragment>
${RIM_CHUNK}
         if (uCloudShadow > 0.0) {
           float cs = celCloudShadow(vCelWorld.xz, uCelTime) * uCloudShadow;
           // tint toward sky blue as well as darkening, so shaded ground
           // stays in the same warm/cool logic as everything else
           gl_FragColor.rgb = mix(gl_FragColor.rgb, gl_FragColor.rgb * uCloudTint * 1.35, cs);
         }`,
      );
  };
  /*
   * THE PROGRAM CACHE KEY, WHICH THREE CANNOT WORK OUT ON ITS OWN.
   *
   * r160's default Material.customProgramCacheKey returns
   * onBeforeCompile.toString(), and WebGLPrograms.getProgramCacheKey pushes
   * that string into the key. Every celMaterial's onBeforeCompile is this
   * one closure, so its SOURCE TEXT is byte identical no matter what the
   * closure captured. Anything the closure bakes into the generated shader
   * is therefore invisible to the cache, and two materials differing only
   * there are handed each other's already linked program.
   *
   * cloth is the only option that does that: it decides whether the vertex
   * shader declares aCloth and injects CLOTH_CHUNK. Everything else, the
   * rim, the spec, the cloud shadow, the colour, arrives as a uniform, and
   * uniforms are per material and not per program.
   *
   * So scene.js's `printed` and its `sailMaterial` differ only in rim and
   * cloth, both invisible, and both carry a map on FrontSide with fog: to
   * three they were the same program. Whichever linked first decided
   * whether the cloth code existed at all, which is a field whose flags
   * wave or do not wave depending on the order the world was built in.
   *
   * THE KEY IS THE INJECTED SOURCE ITSELF, not a name for it. A hand
   * written 'cel' and 'cel-cloth' works today and is the bug waiting to
   * come back: the condition would then live in three places that nothing
   * couples, so a later edit to either ternary, or a second option that
   * varies the source, would leave the key stale. And it would come back
   * camouflaged, because the file would look like it had a considered
   * cache key. Deriving it from clothDecl and clothBody means the key
   * cannot disagree with the shader by construction.
   *
   * Still far shorter than what three did by default, which was the whole
   * closure source: 2361 characters, identical for every cel material.
   * Not the options object either, because that would split the cache by
   * colour and buy a compile per gate for a uniform.
   *
   * Measured on the field, before and after: sail draws using a program
   * that declares aCloth went from 0 of 55 to 55 of 55, so before this the
   * flags did not wave at all. The field's program count went 50 to 52,
   * and cel programs carrying cloth went 1 to 2. Only ONE of the two extra
   * programs is the cloth variant; the other is a non-cloth cel program
   * that used to be sharing with it. Both are the point.
   *
   * KNOWN, and not fixed here: the sail now moves in the colour pass only.
   * post.js's outline prepass overrides the whole scene with a plain
   * ShaderMaterial that has no cloth code, and three's depth material does
   * not carry onBeforeCompile either, so the ink and the shadow are still
   * rasterised at the rest pose. Before this the three passes agreed
   * because none of them waved. The disagreement is bounded by
   * FLAG_SAIL_CLOTH, 85 mm. Looked for and not found: a stale ink line at
   * the rest silhouette, absent at the camera it was hunted from.
   */
  mat.customProgramCacheKey = () => `cel${clothDecl}${clothBody}`;
  mat.userData.cel = true;
  /* What the comic pass draws on it (render/comic.js, GROUND and FOLIAGE).
   * An option rather than a mark set afterwards, so it is in celKey below
   * and the merger never buckets a marked material with an unmarked one. */
  if (opts.comic === 'ground') {
    mat.userData.comicGround = true;
  } else if (opts.comic === 'foliage') {
    mat.userData.comicFoliage = true;
  }
  /* Stable identity for the scenery merger: two materials built from the
   * same options are interchangeable, so their meshes can share one draw.
   * A texture is not JSON, so a keyed material states its own identity and
   * the key is used verbatim. */
  mat.userData.celKey = opts.key ?? JSON.stringify(opts);
  return mat;
}

/*
 * Inverted hull outline for hero objects. The post pass draws edges from
 * depth and normals across the whole world; this adds a heavier, art
 * directed line on the things that need to pop regardless of what is
 * behind them.
 */
export function outlineHull(mesh, thickness = 1.05, color = 0x141a24) {
  const hull = new THREE.Mesh(
    mesh.geometry,
    new THREE.MeshBasicMaterial({ color, side: THREE.BackSide, fog: true }),
  );
  hull.material.userData.hullColor = color;
  hull.scale.multiplyScalar(thickness);
  hull.castShadow = false;
  hull.receiveShadow = false;
  mesh.add(hull);
  return mesh;
}
