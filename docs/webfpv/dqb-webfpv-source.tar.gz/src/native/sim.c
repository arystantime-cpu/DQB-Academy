/*
 * sim.c: Stage 1 physics module entry points and the fixed-step driver.
 *
 * The module is one deterministic unit stepped at exactly 1000 Hz. Input
 * samples carry their own timestamps and are consumed by that timestamp:
 * a sample is applied before the 1 ms step containing it executes, never
 * by arrival time. How the host batches sim_step calls cannot affect the
 * trajectory; there is no frame time anywhere in this file.
 *
 * This file is part of WebFPVSimulator.
 *
 * WebFPVSimulator is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at
 * your option) any later version.
 *
 * WebFPVSimulator is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY, without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebFPVSimulator. If not, see <https://www.gnu.org/licenses/>.
 */

#include "sim_abi.h"
#include "sim_internal.h"
#include "libm/sim_math.h"

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#define SIM_EXPORT EMSCRIPTEN_KEEPALIVE
#else
#define SIM_EXPORT
#endif

#define INPUT_QUEUE_CAP 8192

typedef struct {
  long long t_us;
  double ch[4]; /* roll, pitch, yaw, throttle */
} InputSample;

static SimState S;
static int g_initialised = 0;
static double g_current_rc[4] = { 0.0, 0.0, 0.0, 0.0 };
static double g_override[SIM_MOTOR_COUNT] = { -1.0, -1.0, -1.0, -1.0 };
static InputSample g_queue[INPUT_QUEUE_CAP];
static int g_q_head = 0;
static int g_q_tail = 0;
static long long g_last_input_us = -1;
static int g_stand_on = 0;
static double g_stand_hinge[3];
/* Underside of the parked pose, metres below the CG. Matches REST_HEIGHT
 * in the shell so the hinge sits on the foam, not in the air above it.
 * Per airframe since the whoop landed: a 23 mm thick machine does not park
 * 45 mm off the deck. */
#define STAND_HINGE_Z (-PLANT_W.hull_hz_down)

/*
 * Ground plane, plant frame. Off unless the shell raises it, so a harness
 * replay that never calls sim_set_ground cannot see a floor.
 *
 * The hull is an OBB around the 5 inch airframe. Half extents in x and y
 * are the motor offset plus a motor-bell radius, so a side arrival contacts
 * an arm, not empty air. Down is REST_HEIGHT so a level craft at plant z = 0
 * sits on a plane at z = -0.033, matching the parked pose. Up is the prop
 * disc / camera stack, which is what an inverted craft rests on.
 */
static int g_ground_on = 0;
static double g_ground_n[3] = { 0.0, 0.0, 1.0 };
/* Seeded to the five inch's parked height and re-seated by
 * sim_set_airframe, because a static initialiser cannot read PLANT_W. A host
 * that raises its own ground plane overwrites this on the first call
 * anyway; it matters only to a host that never does. */
static double g_ground_d = -0.033;
static double g_ground_mu = 1.40;
static double g_ground_e = 0.0;
/* The plane exactly as the shell raised it. g_ground_* above is what the
 * solver uses this step, which world.c may replace with the top of a box the
 * CG is over (a roof is ground). With no world it is never touched, so the
 * two are the same doubles and every recorded trace stands. */
static double g_terrain_n[3] = { 0.0, 0.0, 1.0 };
static double g_terrain_d = -0.033;
static int g_ground_hits = 0;
static int g_ground_projected = 0;
static int g_ground_near = 0;

/* The hull half extents are the airframe's now. The five inch's are the
 * numbers that used to be here; the whoop's are a third of them, which is
 * why they could not stay a #define. */
#define CONTACT_HX (PLANT_W.hull_hx)
#define CONTACT_HY (PLANT_W.hull_hy)
#define CONTACT_HZ_DOWN (PLANT_W.hull_hz_down)
#define CONTACT_HZ_UP (PLANT_W.hull_hz_up)
#define CONTACT_CORNERS 8
#define CONTACT_ITERS 4
#define CONTACT_SLOP 0.002
#define CONTACT_BAUMGARTE 0.15
#define CONTACT_REST_VN 0.25
/*
 * The knee in the restitution curve, metres per second.
 *
 * A wall tap should push the quad off a little and let a pilot fly out
 * of it, and it should do that the SAME WAY at every speed. Two shapes
 * have been tried here and both were wrong in the way a pilot notices.
 *
 * 14 m/s of linear falloff was a steel number on a machine made of
 * nylon, carbon plate and a strapped-on lithium brick: a fast hit sprang
 * back. Dropping it to 6 fixed that and broke something worse. The
 * falloff is clamped at the bottom, so the product e * v rose to 0.225
 * m/s at 3 m/s, fell off a cliff to 0.043 by 5.7 m/s where the clamp
 * bites, and then CLIMBED again with speed. A 5 m/s tap came off three
 * times harder than a 6 m/s one. Nothing in the world behaves like that
 * and a pilot cannot learn it.
 *
 * What a structure actually does is store a bounded amount of elastic
 * energy. Below the knee the contact is elastic at the material's own
 * coefficient. Above it the compliant part of the airframe, the skin,
 * the arms, the battery strap, has bottomed out, and everything past
 * that goes into deformation and does not come back. So the SEPARATION
 * SPEED saturates while the impact keeps growing:
 *
 *   e_used = e * min(1, CONTACT_E_KNEE / closing)
 *
 * which is e * closing while slow, and e * CONTACT_E_KNEE for ever
 * after. Monotonic, no cliff, and bounded by the material: a wall caps
 * at 0.26 m/s, PVC at 0.37, bark at 0.20, the train at 0.10, so the
 * materials still differ at speed instead of collapsing together.
 *
 * The low-speed end is untouched. CONTACT_E_FLOOR still holds a gentle
 * touch off the surface: a light tap welding on was the first half of
 * this ticket and must not come back to fix the second half.
 */
#define CONTACT_E_KNEE 1.7
#define CONTACT_STATIC_VT 0.08
#define CONTACT_BIAS_MAX 1.2
#define CONTACT_POS_PUSH 0.20
/*
 * A light tap must not weld.
 *
 * Restitution used to fall off a cliff to zero below CONTACT_REST_VN,
 * which took every joule out of a 20 cm/s touch and left Coulomb
 * friction holding the hull on the face. The owner's report was that
 * tapping a wall with the base of the quad sticks. It ramps to a floor
 * now instead of to nothing, so a slow touch still leaves the surface.
 * The floor is a fraction of the material's own coefficient, so grass
 * (e = 0) still cannot bounce and only a hard face can push back.
 */
#define CONTACT_E_FLOOR 0.35
/*
 * Contact patch radius for resting spin friction, metres.
 *
 * A belly on the ground is not a point. The plane carries the weight
 * over the area between the arms, and a yaw about the normal has to
 * drag the whole of that patch. Half the motor offset is the honest
 * lever for a four-arm footprint.
 */
#define CONTACT_PATCH_R (PLANT_W.contact_patch_r)
/*
 * Largest impulse arm a caller may hand sim_contact_at, metres. The
 * craft sweeps 0.1735 m to a blade tip, so anything past that is not a
 * point on this airframe and must not become a moment.
 */
#define CONTACT_ARM_MAX (PLANT_W.contact_arm_max)
/* Lens glass, plant body metres. Mount is 0.080 forward and 0.018 up;
 * herocraft.js puts the glass another 0.024 past the mount. The hull
 * OBB stops at 0.094, so a nose-down arrival used to park the lens
 * under the plane. Projection samples this point too. */
#define CAMERA_BODY_X (PLANT_W.camera_x)
#define CAMERA_BODY_Y (PLANT_W.camera_y)
#define CAMERA_BODY_Z (PLANT_W.camera_z)
#define CONTACT_INVERT_UPZ -0.50
/* Halo invert-stop is props-down only. A roll or flip that is only
 * partly inverted can put a corner in the 8 mm slab with the CG still
 * a decimetre up; that must not freeze. */
#define CONTACT_INVERT_HALO_UPZ -0.90
#define CONTACT_SLIDE_STOP 0.12
#define CONTACT_OMEGA_STOP 0.35
#define CONTACT_NEAR 0.008
/* Inbound normal faster than this in the 8 mm halo is a live arrival,
 * not a seated props-down slide. Invert-stop on near-only used to
 * freeze a flip the moment a corner entered that slab, with the CG
 * still a decimetre up and hits still 0. */
#define CONTACT_INVERT_DIVE 0.20
/* Deepest-pen sentinel. Must be a large negative: starting at 0 made
 * every airborne hull look "near" the plane (worst stayed 0), so an
 * inverted flip in free air ran invert-stop and froze the craft. */
#define CONTACT_PEN_NONE (-1.0e9)

/*
 * The eight hull corners, rebuilt whenever the airframe changes rather than
 * written as an initialiser, because the half extents are no longer
 * compile time constants. Order is EXACTLY the order the initialiser had:
 * the contact solver iterates it and the projection reports "worst corner"
 * by index, so a reordering would silently change which corner wins a tie.
 */
static double CONTACT_CORNER[CONTACT_CORNERS][3];

static void contact_build_corners(void) {
  const double hx = CONTACT_HX, hy = CONTACT_HY;
  const double dn = -CONTACT_HZ_DOWN, up = CONTACT_HZ_UP;
  const double src[CONTACT_CORNERS][3] = {
    { -hx, -hy, dn }, { hx, -hy, dn }, { -hx, hy, dn }, { hx, hy, dn },
    { -hx, -hy, up }, { hx, -hy, up }, { -hx, hy, up }, { hx, hy, up },
  };
  for (int c = 0; c < CONTACT_CORNERS; c += 1) {
    for (int a = 0; a < 3; a += 1) {
      CONTACT_CORNER[c][a] = src[c][a];
    }
  }
}

SIM_EXPORT int sim_abi_version(void) { return SIM_ABI_VERSION; }

static void reset_dynamics(void) {
  plant_reset(&S);
  bridge_reset();
  g_q_head = 0;
  g_q_tail = 0;
  g_last_input_us = -1;
  for (int i = 0; i < 4; i += 1) {
    g_current_rc[i] = 0.0;
  }
  for (int m = 0; m < SIM_MOTOR_COUNT; m += 1) {
    g_override[m] = -1.0;
  }
  g_stand_on = 0;
  g_ground_on = 0;
  g_ground_hits = 0;
  g_ground_projected = 0;
  g_ground_near = 0;
  world_forget();
}

SIM_EXPORT int sim_init(const unsigned char *diff_utf8, int len) {
  if (diff_utf8 == 0 || len < 0) {
    return SIM_ERR_BAD_ARG;
  }
  const int rc = bridge_parse_config(diff_utf8, len);
  if (rc != SIM_OK) {
    return rc;
  }
  if (!g_initialised) {
    S.cell_voltage_oc = 4.2;
  }
  g_initialised = 1;
  contact_build_corners();
  reset_dynamics();
  return SIM_OK;
}

SIM_EXPORT int sim_reset(void) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  reset_dynamics();
  return SIM_OK;
}

SIM_EXPORT int sim_set_cell_voltage(double volts) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  if (!(volts > 0.5) || !(volts < 5.0)) {
    return SIM_ERR_BAD_ARG;
  }
  S.cell_voltage_oc = volts;
  return SIM_OK;
}

SIM_EXPORT int sim_input(double t_seconds, double roll, double pitch, double yaw,
                         double throttle) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  if (!(t_seconds >= 0.0)) {
    return SIM_ERR_BAD_ARG;
  }
  const long long t_us = (long long)(t_seconds * 1e6 + 0.5);
  if (t_us < g_last_input_us) {
    return SIM_ERR_BAD_ARG;
  }
  const int next = (g_q_tail + 1) % INPUT_QUEUE_CAP;
  if (next == g_q_head) {
    return SIM_ERR_BAD_STATE;
  }
  g_queue[g_q_tail].t_us = t_us;
  g_queue[g_q_tail].ch[0] = roll;
  g_queue[g_q_tail].ch[1] = pitch;
  g_queue[g_q_tail].ch[2] = yaw;
  g_queue[g_q_tail].ch[3] = throttle;
  g_q_tail = next;
  g_last_input_us = t_us;
  return SIM_OK;
}

SIM_EXPORT int sim_rest(void) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  for (int i = 0; i < 3; i += 1) {
    S.vel[i] = 0.0;
    S.omega[i] = 0.0;
  }
  return SIM_OK;
}

/* IEEE NaN and Inf without math.h: NaN != NaN, Inf - Inf is NaN. */
static int sim_finite(double x) {
  return x == x && x - x == 0.0;
}

/* Body vector to world, plant quaternion. */
static void contact_rotate(const double v[3], double out[3]) {
  const double w = S.quat[0];
  const double x = S.quat[1];
  const double y = S.quat[2];
  const double z = S.quat[3];
  const double ux = 2.0 * (y * v[2] - z * v[1]);
  const double uy = 2.0 * (z * v[0] - x * v[2]);
  const double uz = 2.0 * (x * v[1] - y * v[0]);
  out[0] = v[0] + w * ux + (y * uz - z * uy);
  out[1] = v[1] + w * uy + (z * ux - x * uz);
  out[2] = v[2] + w * uz + (x * uy - y * ux);
}

/* World vector to body: conjugate rotation. */
static void contact_rotate_inv(const double v[3], double out[3]) {
  const double w = S.quat[0];
  const double x = -S.quat[1];
  const double y = -S.quat[2];
  const double z = -S.quat[3];
  const double ux = 2.0 * (y * v[2] - z * v[1]);
  const double uy = 2.0 * (z * v[0] - x * v[2]);
  const double uz = 2.0 * (x * v[1] - y * v[0]);
  out[0] = v[0] + w * ux + (y * uz - z * uy);
  out[1] = v[1] + w * uy + (z * ux - x * uz);
  out[2] = v[2] + w * uz + (x * uy - y * ux);
}

/* I_world^{-1} * v, diagonal inertia in the body frame. */
static void contact_iinv(const double v_world[3], double out[3]) {
  double b[3];
  contact_rotate_inv(v_world, b);
  b[0] /= PLANT_W.inertia[0];
  b[1] /= PLANT_W.inertia[1];
  b[2] /= PLANT_W.inertia[2];
  contact_rotate(b, out);
}

/*
 * One rigid-body impulse at offset r from the CG, against unit normal n
 * (out of the solid) and surface velocity vs. pen is positive penetration.
 * Returns 1 if an impulse was applied.
 *
 * Sequential Coulomb, Baraff's form: the normal impulse uses the effective
 * mass along n including the angular term, so a hit on an arm produces
 * spin instead of a point-mass bounce. Restitution falls with closing
 * speed so a crash dumps energy and a skip still skips. Friction cancels
 * as much tangent speed as mu * jn allows, which is a slide when it
 * saturates and a stick when it does not.
 */
static int contact_impulse(const double n[3], const double r[3], const double vs[3],
                           double e, double mu, double pen) {
  double w_world[3];
  contact_rotate(S.omega, w_world);

  double vp[3];
  vp[0] = S.vel[0] + (w_world[1] * r[2] - w_world[2] * r[1]) - vs[0];
  vp[1] = S.vel[1] + (w_world[2] * r[0] - w_world[0] * r[2]) - vs[1];
  vp[2] = S.vel[2] + (w_world[0] * r[1] - w_world[1] * r[0]) - vs[2];

  const double vn = vp[0] * n[0] + vp[1] * n[1] + vp[2] * n[2];
  if (vn >= 0.0 && !(pen > CONTACT_SLOP)) {
    return 0;
  }

  double rn[3];
  rn[0] = r[1] * n[2] - r[2] * n[1];
  rn[1] = r[2] * n[0] - r[0] * n[2];
  rn[2] = r[0] * n[1] - r[1] * n[0];
  double irn[3];
  contact_iinv(rn, irn);
  const double kn = 1.0 / PLANT_W.mass_kg
      + (rn[0] * irn[0] + rn[1] * irn[1] + rn[2] * irn[2]);
  if (kn < 1e-12) {
    return 0;
  }

  /* Restitution falls with closing speed, then ramps to a floor rather
   * than to zero at the bottom. The cliff at CONTACT_REST_VN is what
   * made a gentle wall tap stick: the coefficient went to nothing, the
   * normal impulse cancelled the approach exactly, and friction held
   * what was left. A hard face keeps a fraction of its own e all the
   * way down, so the hull leaves. Grass has e = 0 and is unaffected. */
  const double vin = vn < 0.0 ? -vn : 0.0;
  double e_used = e;
  if (vin > CONTACT_E_KNEE) {
    /* Saturated: the separation speed stops growing with the impact. */
    e_used = e * CONTACT_E_KNEE / vin;
  }
  if (vn > -CONTACT_REST_VN) {
    const double soft = vin / CONTACT_REST_VN;
    e_used *= CONTACT_E_FLOOR + (1.0 - CONTACT_E_FLOOR) * (soft > 0.0 ? soft : 0.0);
  }

  double bias = 0.0;
  if (pen > CONTACT_SLOP) {
    bias = CONTACT_BAUMGARTE * (pen - CONTACT_SLOP) / SIM_DT;
    if (bias > CONTACT_BIAS_MAX) {
      bias = CONTACT_BIAS_MAX;
    }
  }

  const double vn_in = vn < 0.0 ? vn : 0.0;
  const double vn_target = -e_used * vn_in + bias;
  double jn = (vn_target - vn) / kn;
  if (jn < 0.0) {
    return 0;
  }

  double jt[3] = { 0.0, 0.0, 0.0 };
  const double vtx = vp[0] - vn * n[0];
  const double vty = vp[1] - vn * n[1];
  const double vtz = vp[2] - vn * n[2];
  const double vt2 = vtx * vtx + vty * vty + vtz * vtz;
  if (vt2 > 1e-16 && mu > 0.0) {
    const double vtm = sim_sqrt(vt2);
    const double tx = vtx / vtm;
    const double ty = vty / vtm;
    const double tz = vtz / vtm;
    double rt[3];
    rt[0] = r[1] * tz - r[2] * ty;
    rt[1] = r[2] * tx - r[0] * tz;
    rt[2] = r[0] * ty - r[1] * tx;
    double irt[3];
    contact_iinv(rt, irt);
    const double kt = 1.0 / PLANT_W.mass_kg
        + (rt[0] * irt[0] + rt[1] * irt[1] + rt[2] * irt[2]);
    if (kt > 1e-12) {
      double jtm = -vtm / kt;
      const double mu_use = (vtm < CONTACT_STATIC_VT) ? mu * 1.15 : mu;
      const double jmax = mu_use * jn;
      if (jtm < -jmax) {
        jtm = -jmax;
      }
      if (jtm > jmax) {
        jtm = jmax;
      }
      jt[0] = jtm * tx;
      jt[1] = jtm * ty;
      jt[2] = jtm * tz;
    }
  }

  const double Jx = jn * n[0] + jt[0];
  const double Jy = jn * n[1] + jt[1];
  const double Jz = jn * n[2] + jt[2];
  const double invm = 1.0 / PLANT_W.mass_kg;
  S.vel[0] += Jx * invm;
  S.vel[1] += Jy * invm;
  S.vel[2] += Jz * invm;

  double tau[3];
  tau[0] = r[1] * Jz - r[2] * Jy;
  tau[1] = r[2] * Jx - r[0] * Jz;
  tau[2] = r[0] * Jy - r[1] * Jx;
  double dw[3];
  contact_iinv(tau, dw);
  w_world[0] += dw[0];
  w_world[1] += dw[1];
  w_world[2] += dw[2];
  contact_rotate_inv(w_world, S.omega);
  return 1;
}

static void contact_support_neg_n(const double n[3], double r[3]) {
  /* Supporting vertex of the OBB in the -n direction: the hull point that
   * meets a surface with outward normal n. */
  double nb[3];
  const double inn[3] = { -n[0], -n[1], -n[2] };
  contact_rotate_inv(inn, nb);
  double b[3];
  b[0] = nb[0] >= 0.0 ? CONTACT_HX : -CONTACT_HX;
  b[1] = nb[1] >= 0.0 ? CONTACT_HY : -CONTACT_HY;
  b[2] = nb[2] >= 0.0 ? CONTACT_HZ_UP : -CONTACT_HZ_DOWN;
  contact_rotate(b, r);
}

static int contact_unit3(double nx, double ny, double nz, double n[3]) {
  const double n2 = nx * nx + ny * ny + nz * nz;
  if (!(n2 > 0.97) || !(n2 < 1.03)) {
    return 0;
  }
  const double inv = 1.0 / sim_sqrt(n2);
  n[0] = nx * inv;
  n[1] = ny * inv;
  n[2] = nz * inv;
  return 1;
}

/* One hull point against the ground plane. Returns 1 if that point is in
 * the contact band (impulse may or may not have been applied). */
static int ground_hit_at(const double r[3], const double vs[3]) {
  const double px = S.pos[0] + r[0];
  const double py = S.pos[1] + r[1];
  const double pz = S.pos[2] + r[2];
  const double side = g_ground_n[0] * px + g_ground_n[1] * py + g_ground_n[2] * pz;
  const double pen = g_ground_d - side;
  if (!(pen > -CONTACT_SLOP)) {
    return 0;
  }
  const double use_p = pen > 0.0 ? pen : 0.0;
  contact_impulse(g_ground_n, r, vs, g_ground_e, g_ground_mu, use_p);
  if (pen > CONTACT_SLOP) {
    const double push = (pen - CONTACT_SLOP) * CONTACT_POS_PUSH;
    S.pos[0] += g_ground_n[0] * push;
    S.pos[1] += g_ground_n[1] * push;
    S.pos[2] += g_ground_n[2] * push;
  }
  return 1;
}

/*
 * THE FOUR LEG TABLE, NORMAL FIRST AND FRICTION AFTER, since 2026-10-21.
 *
 * The corners used to go through contact_impulse one at a time, normal and
 * friction together, and a corner could only ever be given more. So on a
 * flat landing straight down the first corner took the whole stop, the hull
 * pitched and rolled about it, the other corners' friction met that made up
 * spin as a sideways slide and pushed against it, and the hull left the
 * touch moving sideways: measured, a level drop with no sideways speed at
 * all came off the touch at 0.47 m/s from 1 m, 1.0 from 5 m and 2.1 from
 * 30 m, and rolled 0.24, 0.85 and 1.7 m along the grass (check:props, h1).
 * At mu 1.40 the friction had mostly smothered it; at 0.6, the slide the
 * owner asked for on 2026-10-18, it showed.
 *
 * Now the normal impulses are solved on their own first, each corner's
 * kept as a running total that can be given back when a later corner
 * carries what an earlier one took (the accumulated form of sequential
 * impulses), until the hull stops going into the ground without turning.
 * A normal impulse is along n, so it cannot push the hull sideways at all.
 * Then friction, each corner's own total held to mu times that corner's
 * own normal impulse, against the tangent speed the hull really has: a
 * belly slide arriving at 10 m/s meets the same Coulomb cone it always
 * did, and a straight drop meets none, because there is no slide to meet.
 * Returns the corners that were in the contact band, as a mask.
 */
#define CONTACT_TABLE_ITERS 8
/* An iteration that moves no corner's impulse by more than this, in N s,
 * has converged, and the rest are skipped. A five inch's weight is about
 * 0.01 N s a step, so this is a part in ten million of it. */
#define CONTACT_TABLE_TOL 1e-9
static int ground_table(const double vs[3]) {
  const double *n = g_ground_n;
  const double invm = 1.0 / PLANT_W.mass_kg;
  /*
   * COST. This runs every step the craft is upright, airborne or not, so
   * the airborne case is the corner offsets and one dot product each, as
   * it was. Once a corner is in the band, what does not change inside one
   * step is worked out once: the offsets, each corner's normal lever and
   * its effective mass, and the world frame inverse inertia as a matrix,
   * and the spin is carried in the world frame until the end. The loops
   * stop when an iteration has nothing left to move.
   */
  double r[CONTACT_CORNERS][3];
  int hit_mask = 0;
  for (int c = 0; c < CONTACT_CORNERS; c += 1) {
    contact_rotate(CONTACT_CORNER[c], r[c]);
    const double side = n[0] * (S.pos[0] + r[c][0]) + n[1] * (S.pos[1] + r[c][1]) + n[2] * (S.pos[2] + r[c][2]);
    if (g_ground_d - side > -CONTACT_SLOP) {
      hit_mask |= (1 << c);
    }
  }
  if (hit_mask == 0) {
    return 0;
  }

  double iw[3][3];
  for (int k = 0; k < 3; k += 1) {
    const double e[3] = { k == 0 ? 1.0 : 0.0, k == 1 ? 1.0 : 0.0, k == 2 ? 1.0 : 0.0 };
    double col[3];
    contact_iinv(e, col);
    iw[0][k] = col[0];
    iw[1][k] = col[1];
    iw[2][k] = col[2];
  }
  double w[3];
  contact_rotate(S.omega, w);

  double rn[CONTACT_CORNERS][3];
  double irn[CONTACT_CORNERS][3];
  double kn[CONTACT_CORNERS];
  double jn_acc[CONTACT_CORNERS];
  double jt_acc[CONTACT_CORNERS][3];
  for (int c = 0; c < CONTACT_CORNERS; c += 1) {
    jn_acc[c] = 0.0;
    jt_acc[c][0] = 0.0;
    jt_acc[c][1] = 0.0;
    jt_acc[c][2] = 0.0;
    kn[c] = 0.0;
    if (!(hit_mask & (1 << c))) {
      continue;
    }
    rn[c][0] = r[c][1] * n[2] - r[c][2] * n[1];
    rn[c][1] = r[c][2] * n[0] - r[c][0] * n[2];
    rn[c][2] = r[c][0] * n[1] - r[c][1] * n[0];
    for (int i = 0; i < 3; i += 1) {
      irn[c][i] = iw[i][0] * rn[c][0] + iw[i][1] * rn[c][1] + iw[i][2] * rn[c][2];
    }
    kn[c] = invm + (rn[c][0] * irn[c][0] + rn[c][1] * irn[c][1] + rn[c][2] * irn[c][2]);
  }

  /* The first CONTACT_ITERS passes also lift the hull out by the old corner
   * loop's own measure, CONTACT_POS_PUSH of what is in, and every pass reads
   * the penetration as it now is. If the impulses settle sooner, the passes
   * left are pushes only, so how fast they settled cannot change how far
   * the hull is lifted. */
  int iter = 0;
  for (; iter < CONTACT_TABLE_ITERS; iter += 1) {
    double moved = 0.0;
    for (int c = 0; c < CONTACT_CORNERS; c += 1) {
      if (!(kn[c] > 1e-12)) {
        continue;
      }
      const double side = n[0] * (S.pos[0] + r[c][0]) + n[1] * (S.pos[1] + r[c][1]) + n[2] * (S.pos[2] + r[c][2]);
      const double pen_now = g_ground_d - side;
      const int in_band = pen_now > -CONTACT_SLOP;
      if (!in_band && !(jn_acc[c] > 0.0)) {
        continue;
      }
      const double vn = n[0] * (S.vel[0] + (w[1] * r[c][2] - w[2] * r[c][1]) - vs[0])
          + n[1] * (S.vel[1] + (w[2] * r[c][0] - w[0] * r[c][2]) - vs[1])
          + n[2] * (S.vel[2] + (w[0] * r[c][1] - w[1] * r[c][0]) - vs[2]);
      /* The target is contact_impulse's: restitution from the closing
       * speed, the same knee and floor, and Baumgarte on what is in. */
      double target = 0.0;
      if (in_band) {
        const double vin = vn < 0.0 ? -vn : 0.0;
        double e_used = g_ground_e;
        if (vin > CONTACT_E_KNEE) {
          e_used = g_ground_e * CONTACT_E_KNEE / vin;
        }
        if (vn > -CONTACT_REST_VN) {
          const double soft = vin / CONTACT_REST_VN;
          e_used *= CONTACT_E_FLOOR + (1.0 - CONTACT_E_FLOOR) * (soft > 0.0 ? soft : 0.0);
        }
        double bias = 0.0;
        if (pen_now > CONTACT_SLOP) {
          bias = CONTACT_BAUMGARTE * (pen_now - CONTACT_SLOP) / SIM_DT;
          if (bias > CONTACT_BIAS_MAX) {
            bias = CONTACT_BIAS_MAX;
          }
        }
        target = e_used * vin + bias;
      }
      double next = jn_acc[c] + (target - vn) / kn[c];
      if (next < 0.0) {
        next = 0.0;
      }
      const double dj = next - jn_acc[c];
      jn_acc[c] = next;
      if (dj != 0.0) {
        S.vel[0] += dj * n[0] * invm;
        S.vel[1] += dj * n[1] * invm;
        S.vel[2] += dj * n[2] * invm;
        w[0] += dj * irn[c][0];
        w[1] += dj * irn[c][1];
        w[2] += dj * irn[c][2];
        const double a = dj < 0.0 ? -dj : dj;
        if (a > moved) {
          moved = a;
        }
      }
      if (iter < CONTACT_ITERS && pen_now > CONTACT_SLOP) {
        const double push = (pen_now - CONTACT_SLOP) * CONTACT_POS_PUSH;
        S.pos[0] += n[0] * push;
        S.pos[1] += n[1] * push;
        S.pos[2] += n[2] * push;
      }
    }
    if (!(moved > CONTACT_TABLE_TOL)) {
      iter += 1;
      break;
    }
  }
  for (; iter < CONTACT_ITERS; iter += 1) {
    for (int c = 0; c < CONTACT_CORNERS; c += 1) {
      if (!(hit_mask & (1 << c))) {
        continue;
      }
      const double side = n[0] * (S.pos[0] + r[c][0]) + n[1] * (S.pos[1] + r[c][1]) + n[2] * (S.pos[2] + r[c][2]);
      const double p = g_ground_d - side;
      if (p > CONTACT_SLOP) {
        const double push = (p - CONTACT_SLOP) * CONTACT_POS_PUSH;
        S.pos[0] += n[0] * push;
        S.pos[1] += n[1] * push;
        S.pos[2] += n[2] * push;
      }
    }
  }

  if (g_ground_mu > 0.0) {
    for (int iter = 0; iter < CONTACT_ITERS; iter += 1) {
      double moved = 0.0;
      for (int c = 0; c < CONTACT_CORNERS; c += 1) {
        if (!(jn_acc[c] > 0.0)) {
          continue;
        }
        const double vp[3] = {
          S.vel[0] + (w[1] * r[c][2] - w[2] * r[c][1]) - vs[0],
          S.vel[1] + (w[2] * r[c][0] - w[0] * r[c][2]) - vs[1],
          S.vel[2] + (w[0] * r[c][1] - w[1] * r[c][0]) - vs[2],
        };
        const double vn = vp[0] * n[0] + vp[1] * n[1] + vp[2] * n[2];
        const double vt[3] = { vp[0] - vn * n[0], vp[1] - vn * n[1], vp[2] - vn * n[2] };
        const double vt2 = vt[0] * vt[0] + vt[1] * vt[1] + vt[2] * vt[2];
        if (!(vt2 > 1e-16)) {
          continue;
        }
        const double vtm = sim_sqrt(vt2);
        const double t[3] = { vt[0] / vtm, vt[1] / vtm, vt[2] / vtm };
        double rt[3];
        rt[0] = r[c][1] * t[2] - r[c][2] * t[1];
        rt[1] = r[c][2] * t[0] - r[c][0] * t[2];
        rt[2] = r[c][0] * t[1] - r[c][1] * t[0];
        double irt[3];
        for (int i = 0; i < 3; i += 1) {
          irt[i] = iw[i][0] * rt[0] + iw[i][1] * rt[1] + iw[i][2] * rt[2];
        }
        const double kt = invm + (rt[0] * irt[0] + rt[1] * irt[1] + rt[2] * irt[2]);
        if (!(kt > 1e-12)) {
          continue;
        }
        /* What would stop this corner sliding, added to what it already has,
         * then held inside its cone as a whole. */
        const double jtm = -vtm / kt;
        double next[3] = { jt_acc[c][0] + jtm * t[0], jt_acc[c][1] + jtm * t[1], jt_acc[c][2] + jtm * t[2] };
        const double mu_use = (vtm < CONTACT_STATIC_VT) ? g_ground_mu * 1.15 : g_ground_mu;
        const double jmax = mu_use * jn_acc[c];
        const double nm2 = next[0] * next[0] + next[1] * next[1] + next[2] * next[2];
        if (nm2 > jmax * jmax) {
          const double k = jmax / sim_sqrt(nm2);
          next[0] *= k;
          next[1] *= k;
          next[2] *= k;
        }
        const double J[3] = { next[0] - jt_acc[c][0], next[1] - jt_acc[c][1], next[2] - jt_acc[c][2] };
        jt_acc[c][0] = next[0];
        jt_acc[c][1] = next[1];
        jt_acc[c][2] = next[2];
        S.vel[0] += J[0] * invm;
        S.vel[1] += J[1] * invm;
        S.vel[2] += J[2] * invm;
        const double tau[3] = {
          r[c][1] * J[2] - r[c][2] * J[1],
          r[c][2] * J[0] - r[c][0] * J[2],
          r[c][0] * J[1] - r[c][1] * J[0],
        };
        for (int i = 0; i < 3; i += 1) {
          w[i] += iw[i][0] * tau[0] + iw[i][1] * tau[1] + iw[i][2] * tau[2];
        }
        const double a = sim_sqrt(J[0] * J[0] + J[1] * J[1] + J[2] * J[2]);
        if (a > moved) {
          moved = a;
        }
      }
      if (!(moved > CONTACT_TABLE_TOL)) {
        break;
      }
    }
  }
  contact_rotate_inv(w, S.omega);
  return hit_mask;
}

/*
 * After the impulses, no hull sample may stay below the plane. A single
 * support (turtle, a roll) leaves the other seven corners free, and
 * those sweep through the dirt as the hull rotates. Motors inverted
 * also push along world -z. Without this, the camera clips through the
 * grass and a tumble through a gate opening can score a phantom lap.
 *
 * Translation only: no torque, so the mixer couple that flips the hull
 * is not cancelled. The deepest corner is parked on the slop band; as
 * the craft rotates, a new corner becomes deepest and the CG rises.
 */
static void ground_project_sample(const double body[3], double *worst) {
  double r[3];
  contact_rotate(body, r);
  const double px = S.pos[0] + r[0];
  const double py = S.pos[1] + r[1];
  const double pz = S.pos[2] + r[2];
  const double side = g_ground_n[0] * px + g_ground_n[1] * py + g_ground_n[2] * pz;
  const double pen = g_ground_d - side;
  if (pen > *worst) {
    *worst = pen;
  }
}

static void ground_project_hull(void) {
  double worst = CONTACT_PEN_NONE;
  const double cam[3] = { CAMERA_BODY_X, CAMERA_BODY_Y, CAMERA_BODY_Z };
  for (int c = 0; c < CONTACT_CORNERS; c += 1) {
    ground_project_sample(CONTACT_CORNER[c], &worst);
  }
  ground_project_sample(cam, &worst);
  g_ground_projected = 0;
  g_ground_near = (worst > -CONTACT_NEAR) ? 1 : 0;
  if (!(worst > CONTACT_SLOP)) {
    return;
  }
  g_ground_projected = 1;
  const double push = worst - CONTACT_SLOP;
  S.pos[0] += g_ground_n[0] * push;
  S.pos[1] += g_ground_n[1] * push;
  S.pos[2] += g_ground_n[2] * push;
  /* Only kill inbound speed when the hull was truly buried. A roll
   * drives a corner a few millimetres through as it rotates about the
   * support; zeroing vn there cancelled the linear part of a couple.
   * Turtle is the host-latched mixer path; the ABI self-test still
   * proves crashflip against this plane. */
  if (worst > 0.02) {
    const double vn = S.vel[0] * g_ground_n[0]
        + S.vel[1] * g_ground_n[1]
        + S.vel[2] * g_ground_n[2];
    if (vn < 0.0) {
      S.vel[0] -= g_ground_n[0] * vn;
      S.vel[1] -= g_ground_n[1] * vn;
      S.vel[2] -= g_ground_n[2] * vn;
    }
  }
}

/*
 * A CRASHED CRAFT DOES NOT BALANCE ITSELF, the other half of TUMBLE FLAT
 * (2026-09-24). With the lowest corner carrying it, a craft lying at an
 * angle has its weight on an arm, and it still did not fall: in acro with
 * the sticks centred, Betaflight's airmode spends the motors' whole range
 * holding whatever attitude the crash left, and on one support corner that
 * is enough. Measured on the drop probe, a five inch dropped at 60 degrees
 * of roll danced on its side for five seconds with its motors between 1,900
 * and 15,300 rpm, and a whoop, whose ducts keep its props out of the grass,
 * held 35 degrees on a duct edge indefinitely. A real crashed quad does
 * neither: its props are in the dirt, and its pilot disarms. The sim has no
 * disarm, so the plant stands in for it here.
 *
 * On the ground (a hull point on it or within the 8 mm halo), slower than
 * GROUND_STALL_SPEED, more than 14 degrees from lying flat on its belly or
 * its back, and either more than 60 degrees over or with the throttle stick
 * down: every rotor stalls, and it goes over, below. Flat on the belly is a
 * landing and flat on the back is a turtle, and neither is touched. A pilot
 * holding throttle on a craft only tilted, a landing on a slope or a skid,
 * keeps their motors. Crashflip is exempt: turtle is the motors. The angle
 * is taken against the ground's own normal, so a craft sitting flat on a
 * slope is flat.
 */
#define GROUND_STALL_FLAT 0.97
#define GROUND_STALL_SIDE 0.50
#define GROUND_STALL_SPEED 1.0
#define GROUND_STALL_THROTTLE 0.12
/* A stall, not a rub. Measured at 0.08, the soft props' rate, a rotor
 * the controller keeps asking for settles at about a third of its speed
 * against the motor's own spin up, a ninth of its thrust, and airmode
 * balanced a five inch on its side with that. At 0.5 it settles under a
 * tenth: stopped, as a disarmed motor is. */
#define GROUND_STALL_RUB 0.5
#define GROUND_TIP_ACCEL (PLANT_W.ground_tip_accel)

/* Is this a crashed craft lying on the ground, as above? Writes body up
 * and its component along the ground normal. ground_settle asks it too:
 * spin friction stands aside while a crash is being tipped flat. */
static int ground_stall_wanted(double up[3], double *un_out) {
  if (!(g_ground_hits || g_ground_projected || g_ground_near) || bridge_crashflip_active()) {
    return 0;
  }
  const double zb[3] = { 0.0, 0.0, 1.0 };
  contact_rotate(zb, up);
  const double un = up[0] * g_ground_n[0] + up[1] * g_ground_n[1] + up[2] * g_ground_n[2];
  *un_out = un;
  if (un > GROUND_STALL_FLAT || un < -GROUND_STALL_FLAT) {
    return 0;
  }
  const double v2 = S.vel[0] * S.vel[0] + S.vel[1] * S.vel[1] + S.vel[2] * S.vel[2];
  if (!(v2 < GROUND_STALL_SPEED * GROUND_STALL_SPEED)) {
    return 0;
  }
  /* In 3D mode "throttle down" is the middle of the stick, where the motors
   * make nothing, so the test is on the distance from centre as a fraction
   * of a half. In normal mode the stick IS that number. */
  double thr = g_current_rc[3];
  if (SIM_3D) {
    thr = 2.0 * (thr < 0.5 ? 0.5 - thr : thr - 0.5);
  }
  if (!(un < GROUND_STALL_SIDE) && !(thr < GROUND_STALL_THROTTLE)) {
    return 0;
  }
  return 1;
}

static void ground_stall(void) {
  double up[3];
  double un = 0.0;
  if (!ground_stall_wanted(up, &un)) {
    return;
  }
  for (int m = 0; m < SIM_MOTOR_COUNT; m += 1) {
    S.motor_omega[m] *= 1.0 - GROUND_STALL_RUB;
  }
  /*
   * AND IT GOES OVER. With the motors stalled, a quarter of the drop probe
   * still came to rest off flat, because the hull is a box and a box is
   * content to stand on its narrow side face, or to sit on one corner with
   * the projection holding the others up. A real quad lying on its side is
   * lying on its props and arms, which are thin and springy, and it rolls
   * off them onto its belly or its back. So a stalled craft is tipped toward
   * whichever of the two it is nearer, belly on a tie, at GROUND_TIP_ACCEL.
   * Measured, not chosen by eye: at 40, about what a box's own weight gives
   * it tipping over an edge, the support corner's contact cancelled it every
   * millisecond, because leaving the narrow side face means lifting the CG
   * over its edge, about 0.16 N m against the 0.1 that 40 gives; 60 left
   * ten of the 88 on their side. At 200 all 88 drops of the probe end flat,
   * five inch and whoop, throttle cut and held, and one on its side goes
   * over onto its back in about a quarter of a second. It stops within 14
   * degrees of flat, and flat is the belly's corners or the back's bump.
   * The drop probe: PROGRESS.md, 2026-09-24.
   */
  const double sgn = un >= 0.0 ? 1.0 : -1.0;
  const double t[3] = { g_ground_n[0] * sgn, g_ground_n[1] * sgn, g_ground_n[2] * sgn };
  double ax[3] = {
    up[1] * t[2] - up[2] * t[1],
    up[2] * t[0] - up[0] * t[2],
    up[0] * t[1] - up[1] * t[0],
  };
  const double am = sim_sqrt(ax[0] * ax[0] + ax[1] * ax[1] + ax[2] * ax[2]);
  if (!(am > 1e-9)) {
    return;
  }
  /* About the corner it is going over, not about the CG. Turned about the
   * CG, that corner is driven into the grass every millisecond and the
   * contact, which is inelastic, takes the tip back out: measured, a craft
   * on its side crept over at 0.3 rad/s for seconds. So the CG is given
   * the velocity that keeps the pivot, the lowest corner, where it is. */
  double r[3];
  contact_support_neg_n(g_ground_n, r);
  double w_world[3];
  contact_rotate(S.omega, w_world);
  const double dw = GROUND_TIP_ACCEL * SIM_DT / am;
  const double dwv[3] = { ax[0] * dw, ax[1] * dw, ax[2] * dw };
  w_world[0] += dwv[0];
  w_world[1] += dwv[1];
  w_world[2] += dwv[2];
  contact_rotate_inv(w_world, S.omega);
  S.vel[0] -= dwv[1] * r[2] - dwv[2] * r[1];
  S.vel[1] -= dwv[2] * r[0] - dwv[0] * r[2];
  S.vel[2] -= dwv[0] * r[1] - dwv[1] * r[0];
}

/*
 * Grass is a dead thump, not a trampoline. Baumgarte can leave a 1.2 m/s
 * outbound kick even with e = 0; this removes it once the hull is seated.
 *
 * Props down (upz clearly negative): the discs grab and the hull stops
 * in place. Props up: Coulomb friction against the weight the plane is
 * carrying, which is the block's real work and is derived where it is
 * applied below. A side tumble still rolls; spin friction is belly-only
 * so a 90 deg arrival can fall over instead of welding on an arm.
 *
 * Crashflip is latched by the shell when the hull is inverted and
 * settled. The mixer path is compiled, and the contact self-test still
 * drives it, so settle must not cancel that couple while crashflip is
 * latched. A waiting inverted hull with centered sticks is seated by
 * the shell (sim_rest), not here.
 */
static void ground_settle(double upz, double vn_plant) {
  /* In 3D the back is a base (BOTH SIDES ARE A BASE, ground_apply): it is
   * seated by the table, which counts a corner resting in the slop as a hit,
   * so it needs no halo here, exactly as the belly does not. */
  if (!g_ground_hits && !g_ground_projected) {
    if (SIM_3D) {
      return;
    }
    /* Inverted rest can sit on the slop with no impulse and no
     * push, which used to skip settle and leave a props-down slide.
     * near is only true within CONTACT_NEAR of the plane. Starting
     * the projector's worst pen at 0 made every airborne hull look
     * near, and invert-stop froze a flip in free air. */
    if (!(upz < CONTACT_INVERT_UPZ && g_ground_near)) {
      return;
    }
  }
  if (bridge_crashflip_active()) {
    return;
  }

  const double nx = g_ground_n[0];
  const double ny = g_ground_n[1];
  const double nz = g_ground_n[2];
  double vn = S.vel[0] * nx + S.vel[1] * ny + S.vel[2] * nz;

  /* Strip an outbound kick the contact just invented (Baumgarte, a
   * residual bounce). Leave a climb the plant already had: killing
   * that every step glued a punch to the pad. */
  if (vn > 0.0 && !(vn_plant > 0.0)) {
    S.vel[0] -= nx * vn;
    S.vel[1] -= ny * vn;
    S.vel[2] -= nz * vn;
    vn = 0.0;
  }

  /* Props-down on grass: stop immediately when the hull is on the
   * plane, or when it is only in the 8 mm halo and not diving in.
   * A live flip whose lowest corner just entered that halo must keep
   * vel and omega until it actually hits.
   *
   * Only within about 25 degrees of flat on its back, since 2026-09-24:
   * at CONTACT_INVERT_UPZ this froze a craft that had landed 60 degrees
   * off flat before it could fall the rest of the way. See TUMBLE FLAT.
   *
   * Never in 3D: there the back is a base and slides as the belly does
   * (BOTH SIDES ARE A BASE, ground_apply), which also lets a 3D quad on its
   * back lift off on reverse thrust, as the strip above lets a climb the
   * plant had stand. */
  if (upz < CONTACT_INVERT_HALO_UPZ && !SIM_3D) {
    const int touching = g_ground_hits || g_ground_projected;
    const int seated_halo = g_ground_near
        && upz < CONTACT_INVERT_HALO_UPZ
        && !(vn_plant < -CONTACT_INVERT_DIVE);
    if (touching || seated_halo) {
      S.vel[0] = 0.0;
      S.vel[1] = 0.0;
      S.vel[2] = 0.0;
      S.omega[0] = 0.0;
      S.omega[1] = 0.0;
      S.omega[2] = 0.0;
    }
    return;
  }

  /*
   * Tangent only. Scaling the whole velocity damped the punch while
   * the hull was still in the contact band.
   *
   * THE FRICTION HERE IS COULOMB, NOT AN EXPONENTIAL, AND THAT IS THE
   * WHOLE POINT OF THIS BLOCK. contact_impulse returns early on a hull
   * that is merely resting: vn is zero and the penetration sits inside
   * the slop, so there is no normal impulse, so the friction cone up
   * there has nothing to scale against and a belly slide had no force
   * on it at all. What used to stand in for that was a 0.97 per
   * millisecond keep, which is a 33 ms time constant: a 10 m/s belly
   * arrival stopped inside a third of a metre and the ground read as
   * glue. Carry the weight explicitly instead. The normal load a
   * resting contact supplies is the component of gravity into the
   * plane, friction is mu times that, and it can slow a slide to a
   * stop but never reverse it. At mu 1.40 on the level that is 13.7
   * m/s^2, so a 10 m/s slide runs 3.6 m and takes 0.73 s, which is
   * what a 5 inch on turf actually does.
   */
  double vtx = S.vel[0] - nx * vn;
  double vty = S.vel[1] - ny * vn;
  double vtz = S.vel[2] - nz * vn;
  const double vt2 = vtx * vtx + vty * vty + vtz * vtz;
  if (vt2 < CONTACT_SLIDE_STOP * CONTACT_SLIDE_STOP) {
    S.vel[0] = nx * vn;
    S.vel[1] = ny * vn;
    S.vel[2] = nz * vn;
    if (!(vn > 0.0)) {
      S.vel[0] = 0.0;
      S.vel[1] = 0.0;
      S.vel[2] = 0.0;
    }
  } else {
    const double load = PLANT_W.gravity * SIM_GRAVITY * (nz > 0.0 ? nz : 0.0);
    double dv = g_ground_mu * load * SIM_DT;
    const double vtm = sim_sqrt(vt2);
    if (dv > vtm) {
      dv = vtm;
    }
    const double keep = (vtm - dv) / vtm;
    S.vel[0] = nx * vn + vtx * keep;
    S.vel[1] = ny * vn + vty * keep;
    S.vel[2] = nz * vn + vtz * keep;
  }

  double stall_up[3];
  double stall_un = 0.0;
  if ((upz >= 0.5 || (SIM_3D && upz <= -0.5)) && !ground_stall_wanted(stall_up, &stall_un)) {
    /* Spin friction, the same load acting at the patch radius. A yaw
     * about the normal has no tangent velocity at the impulse point,
     * so the cone above cannot see it: a belly on the grass would spin
     * freely for ever. Torque is mu * N * r, resisted by the inertia
     * along the spin axis, and like the slide it cannot reverse.
     *
     * Not while a crash is being tipped flat, since 2026-09-24 (TUMBLE
     * FLAT, ground_stall). It damps the whole rate vector, so it took the
     * first of a tilted craft's tip every millisecond: measured, drops came
     * to rest balanced on an edge at exactly 60 and 30 degrees. Everywhere
     * else it is as it was, which keeps a launch off the 28 degree block,
     * throttle up with the nose in the grass, bit for bit what it was. */
    const double w2 = S.omega[0] * S.omega[0]
        + S.omega[1] * S.omega[1]
        + S.omega[2] * S.omega[2];
    if (w2 < CONTACT_OMEGA_STOP * CONTACT_OMEGA_STOP) {
      S.omega[0] = 0.0;
      S.omega[1] = 0.0;
      S.omega[2] = 0.0;
    } else {
      const double wm = sim_sqrt(w2);
      const double ux = S.omega[0] / wm;
      const double uy = S.omega[1] / wm;
      const double uz = S.omega[2] / wm;
      const double i_eff = ux * ux * PLANT_W.inertia[0]
          + uy * uy * PLANT_W.inertia[1]
          + uz * uz * PLANT_W.inertia[2];
      const double load = PLANT_W.gravity * SIM_GRAVITY * PLANT_W.mass_kg * (nz > 0.0 ? nz : 0.0);
      const double tau = g_ground_mu * load * CONTACT_PATCH_R;
      double dw = (i_eff > 1e-12) ? (tau / i_eff) * SIM_DT : wm;
      if (dw > wm) {
        dw = wm;
      }
      const double keep = (wm - dw) / wm;
      S.omega[0] *= keep;
      S.omega[1] *= keep;
      S.omega[2] *= keep;
    }
  }
}

static void ground_apply(void) {
  g_ground_hits = 0;
  g_ground_projected = 0;
  g_ground_near = 0;
  if (!g_ground_on || g_stand_on) {
    return;
  }
  const double vn_plant = S.vel[0] * g_ground_n[0]
      + S.vel[1] * g_ground_n[1]
      + S.vel[2] * g_ground_n[2];
  const double vs[3] = { 0.0, 0.0, 0.0 };
  /* World-z of body up. A belly landing wants a four-leg table. Anything
   * past about 60 deg is a roll, a turtle or a side arrival: one support
   * so the contact cannot cancel the motor couple. Four coplanar contacts
   * at 1 kHz locked pitch and turtle could not rotate. */
  const double qx = S.quat[1];
  const double qy = S.quat[2];
  const double upz = 1.0 - 2.0 * (qx * qx + qy * qy);

  /*
   * BOTH SIDES ARE A BASE IN 3D. The owner, 2026-10-26: "In 3d mode we
   * should not differentiate between a quad base strike and a prop strike,
   * both sides of the quad around behave like a base strike". A 3D quad flies
   * on its back as much as the right way up, so within 60 degrees of flat on
   * its back it meets the ground on the table, the four top corners carrying
   * it as the four bottom ones carry the belly, and ground_settle slides and
   * spins it down as it does the belly, with no props down grab. The bump
   * below is for turtle, which 3D has none of. Normal mode never asks.
   */
  if (upz < 0.5 && !(SIM_3D && upz <= -0.5)) {
    int hits = 0;
    /*
     * TUMBLE FLAT, the owner's decision of 2026-09-24 ("yes make it tumble
     * flat always"). The bump used to carry EVERY inverted attitude, from
     * flat on the back to lying on the side. It is the top plate's centre,
     * so off flat it is nowhere near the lowest point: the real support was
     * a corner, held out of the dirt by the projection below, which moves
     * the hull and never turns it. Measured, 70 of 88 drops onto grass at
     * 60 to 150 degrees came to rest exactly as they arrived, a tail first
     * crash pointing at the sky. Now the bump carries only a craft within
     * about 25 degrees of flat on its back, and anything steeper stands on
     * its real lowest corner, where its weight has an arm and tips it over.
     * Except under crashflip, which is the motors turning the hull over on
     * purpose and needs the bump at every inverted angle, for the reason
     * the next comment gives: measured, on a corner the golden's turtle
     * stayed at -0.97 with the flip commanded.
     */
    if (upz < CONTACT_INVERT_HALO_UPZ || (upz < 0.0 && bridge_crashflip_active())) {
      /* Inverted rest is the camera / vtx bump, through the CG, so the
       * mixer couple is free to pitch. Projection, not an arm contact,
       * keeps the free corners out of the dirt. An arm impulse here
       * became a 1 kHz weld once the hull was parked on that vertex,
       * and turtle could not rotate. */
      double r[3];
      const double bump[3] = { 0.0, 0.0, CONTACT_HZ_UP };
      contact_rotate(bump, r);
      if (ground_hit_at(r, vs)) {
        hits = 1;
        for (int iter = 1; iter < CONTACT_ITERS; iter += 1) {
          if (!ground_hit_at(r, vs)) {
            break;
          }
        }
      }
    } else {
      /* Tumble on an arm, or on its side: the supporting vertex only. */
      double r[3];
      contact_support_neg_n(g_ground_n, r);
      for (int iter = 0; iter < CONTACT_ITERS; iter += 1) {
        if (!ground_hit_at(r, vs)) {
          break;
        }
        hits = 1;
      }
    }
    g_ground_hits = hits;
    ground_project_hull();
    ground_settle(upz, vn_plant);
    return;
  }

  int hit_mask = ground_table(vs);
  int hits = 0;
  int m = hit_mask;
  while (m) {
    hits += m & 1;
    m >>= 1;
  }
  g_ground_hits = hits;
  ground_project_hull();
  ground_settle(upz, vn_plant);
}

SIM_EXPORT int sim_contact(double nx, double ny, double nz,
                           double restitution, double mu,
                           double px, double py, double pz,
                           double vsx, double vsy, double vsz) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  if (!sim_finite(nx) || !sim_finite(ny) || !sim_finite(nz)
      || !sim_finite(restitution) || !sim_finite(mu)
      || !sim_finite(px) || !sim_finite(py) || !sim_finite(pz)
      || !sim_finite(vsx) || !sim_finite(vsy) || !sim_finite(vsz)) {
    return SIM_ERR_BAD_ARG;
  }
  if (!(restitution >= 0.0) || !(restitution <= 1.0)) {
    return SIM_ERR_BAD_ARG;
  }
  if (!(mu >= 0.0) || !(mu <= 2.0)) {
    return SIM_ERR_BAD_ARG;
  }
  double n[3];
  if (!contact_unit3(nx, ny, nz, n)) {
    return SIM_ERR_BAD_ARG;
  }
  S.pos[0] = px;
  S.pos[1] = py;
  S.pos[2] = pz;
  double r[3];
  contact_support_neg_n(n, r);
  const double vs[3] = { vsx, vsy, vsz };
  /* Penetration is already resolved by the host placing p on the free
   * side of the face. The impulse still sees the inbound velocity. */
  contact_impulse(n, r, vs, restitution, mu, 0.0);
  return SIM_OK;
}

/*
 * Rigid-body contact with the contact point supplied by the caller.
 *
 * sim_contact derives the impulse arm from the plant's own OBB support
 * in the -n direction, and that support is always an extreme corner:
 * plus or minus every half extent at once. So a belly slapped flat on a
 * wall came out of the solver as a corner strike. The angular term is
 * about two thirds of the effective mass at that arm, so a 5 m/s tap
 * produced something near 1900 deg/s of spin, the hull rotated, another
 * corner went in on the next contact, and the craft wound itself up
 * against the surface. That is the owner's "glitching and flipping
 * around", and it is a modelling error rather than a tuning one.
 *
 * The shell knows better, because the shape it sweeps is the four prop
 * discs and it can average the ones actually in the patch: one arm in
 * gives one point and the full moment, a belly flat on the face gives
 * four and almost none. (rx, ry, rz) is the vector from the CG to that
 * point, plant frame, world axes. Everything else matches sim_contact.
 *
 * The arm is clamped to CONTACT_ARM_MAX so a host that reports nonsense
 * cannot inject an unbounded moment. Additive ABI, version unchanged:
 * no existing entry point moved or changed meaning, and a replay that
 * never calls this is bit-identical to one from before it existed.
 */
SIM_EXPORT int sim_contact_at(double nx, double ny, double nz,
                              double restitution, double mu,
                              double px, double py, double pz,
                              double vsx, double vsy, double vsz,
                              double rx, double ry, double rz) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  if (!sim_finite(nx) || !sim_finite(ny) || !sim_finite(nz)
      || !sim_finite(restitution) || !sim_finite(mu)
      || !sim_finite(px) || !sim_finite(py) || !sim_finite(pz)
      || !sim_finite(vsx) || !sim_finite(vsy) || !sim_finite(vsz)
      || !sim_finite(rx) || !sim_finite(ry) || !sim_finite(rz)) {
    return SIM_ERR_BAD_ARG;
  }
  if (!(restitution >= 0.0) || !(restitution <= 1.0)) {
    return SIM_ERR_BAD_ARG;
  }
  if (!(mu >= 0.0) || !(mu <= 2.0)) {
    return SIM_ERR_BAD_ARG;
  }
  double n[3];
  if (!contact_unit3(nx, ny, nz, n)) {
    return SIM_ERR_BAD_ARG;
  }
  S.pos[0] = px;
  S.pos[1] = py;
  S.pos[2] = pz;
  double r[3] = { rx, ry, rz };
  const double r2 = r[0] * r[0] + r[1] * r[1] + r[2] * r[2];
  if (r2 > CONTACT_ARM_MAX * CONTACT_ARM_MAX) {
    const double scale = CONTACT_ARM_MAX / sim_sqrt(r2);
    r[0] *= scale;
    r[1] *= scale;
    r[2] *= scale;
  }
  const double vs[3] = { vsx, vsy, vsz };
  /* Penetration is already resolved by the host placing p on the free
   * side of the face. The impulse still sees the inbound velocity. */
  contact_impulse(n, r, vs, restitution, mu, 0.0);
  return SIM_OK;
}

/*
 * Blade strike: the rotors lose sev of their speed, 0 to 1.
 *
 * A 5 inch that meets a wall with the discs spinning does not carry its
 * tank through the contact. Without this a wall tap changed the craft's
 * direction and nothing else, so the pilot could scrub along a surface
 * at full tilt and pay only in heading. Applied to all four rotors: the
 * mixer is already asking for whatever it wants and will spin them back
 * up at the motor's own time constant, which is the part that is felt.
 *
 * The plant is untouched otherwise. No damage model, no desync: this is
 * energy leaving through the blades, not a broken machine. Additive ABI,
 * version unchanged, and the harness never calls it.
 */
SIM_EXPORT int sim_prop_strike(double sev) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  if (!sim_finite(sev)) {
    return SIM_ERR_BAD_ARG;
  }
  if (!(sev >= 0.0) || !(sev <= 1.0)) {
    return SIM_ERR_BAD_ARG;
  }
  const double keep = 1.0 - sev;
  for (int m = 0; m < SIM_MOTOR_COUNT; m += 1) {
    S.motor_omega[m] *= keep;
  }
  return SIM_OK;
}

SIM_EXPORT int sim_set_ground(int on,
                              double nx, double ny, double nz,
                              double px, double py, double pz,
                              double mu, double restitution) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  if (!on) {
    g_ground_on = 0;
    g_ground_hits = 0;
    g_ground_projected = 0;
    g_ground_near = 0;
    return SIM_OK;
  }
  if (!sim_finite(nx) || !sim_finite(ny) || !sim_finite(nz)
      || !sim_finite(px) || !sim_finite(py) || !sim_finite(pz)
      || !sim_finite(mu) || !sim_finite(restitution)) {
    return SIM_ERR_BAD_ARG;
  }
  if (!(mu >= 0.0) || !(mu <= 2.0)) {
    return SIM_ERR_BAD_ARG;
  }
  if (!(restitution >= 0.0) || !(restitution <= 1.0)) {
    return SIM_ERR_BAD_ARG;
  }
  double n[3];
  if (!contact_unit3(nx, ny, nz, n)) {
    return SIM_ERR_BAD_ARG;
  }
  g_ground_n[0] = n[0];
  g_ground_n[1] = n[1];
  g_ground_n[2] = n[2];
  g_ground_d = n[0] * px + n[1] * py + n[2] * pz;
  g_ground_mu = mu;
  g_ground_e = restitution;
  g_ground_on = 1;
  g_terrain_n[0] = g_ground_n[0];
  g_terrain_n[1] = g_ground_n[1];
  g_terrain_n[2] = g_ground_n[2];
  g_terrain_d = g_ground_d;
  return SIM_OK;
}

SIM_EXPORT int sim_ground_contacts(void) {
  return g_ground_hits;
}

SIM_EXPORT int sim_set_crashflip(int on) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  bridge_set_crashflip(on);
  return SIM_OK;
}

SIM_EXPORT int sim_crashflip_active(void) {
  if (!g_initialised) {
    return 0;
  }
  return bridge_crashflip_active();
}

SIM_EXPORT int sim_set_pose(double px, double py, double pz,
                            double qw, double qx, double qy, double qz) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  if (!sim_finite(px) || !sim_finite(py) || !sim_finite(pz)
      || !sim_finite(qw) || !sim_finite(qx) || !sim_finite(qy) || !sim_finite(qz)) {
    return SIM_ERR_BAD_ARG;
  }
  const double n2 = qw * qw + qx * qx + qy * qy + qz * qz;
  if (!(n2 > 0.25) || !(n2 < 4.0)) {
    return SIM_ERR_BAD_ARG;
  }
  const double ninv = 1.0 / sim_sqrt(n2);
  S.pos[0] = px;
  S.pos[1] = py;
  S.pos[2] = pz;
  S.quat[0] = qw * ninv;
  S.quat[1] = qx * ninv;
  S.quat[2] = qy * ninv;
  S.quat[3] = qz * ninv;
  world_forget();
  /* The wake trail is where the craft was, and it is not there any more. */
  plant_real_forget(&S, 0);
  return SIM_OK;
}

SIM_EXPORT int sim_deflect(double nx, double ny, double nz,
                           double restitution, double tangent_keep,
                           double rate_keep, double px, double py, double pz) {
  /* Kept so an old caller still compiles. The impulse is the rigid-body
   * one; tangent_keep and rate_keep are range-checked so the ABI does not
   * change meaning of the arguments, then ignored because Coulomb friction
   * and the angular term replace those two scale factors. */
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  if (!sim_finite(tangent_keep) || !sim_finite(rate_keep)) {
    return SIM_ERR_BAD_ARG;
  }
  if (!(tangent_keep >= 0.0) || !(tangent_keep <= 1.0)) {
    return SIM_ERR_BAD_ARG;
  }
  if (!(rate_keep >= 0.0) || !(rate_keep <= 1.0)) {
    return SIM_ERR_BAD_ARG;
  }
  return sim_contact(nx, ny, nz, restitution, 0.35, px, py, pz, 0.0, 0.0, 0.0);
}

static void stand_rotate_body(double bx, double by, double bz, double out[3]) {
  const double w = S.quat[0];
  const double x = S.quat[1];
  const double y = S.quat[2];
  const double z = S.quat[3];
  const double ux = 2.0 * (y * bz - z * by);
  const double uy = 2.0 * (z * bx - x * bz);
  const double uz = 2.0 * (x * by - y * bx);
  out[0] = bx + w * ux + (y * uz - z * uy);
  out[1] = by + w * uy + (z * ux - x * uz);
  out[2] = bz + w * uz + (x * uy - y * ux);
}

static void stand_pitch_only(void) {
  const double w = S.quat[0];
  const double x = S.quat[1];
  const double y = S.quat[2];
  const double z = S.quat[3];
  /* Body forward in world, then drop the lateral component so yaw and
   * roll cannot accumulate. Gyroscopic pitch leaks into roll in free
   * air; a launch block does not allow that. */
  double fx = 1.0 - 2.0 * (y * y + z * z);
  double fz = 2.0 * (x * z - w * y);
  const double f2 = fx * fx + fz * fz;
  if (f2 < 1e-16) {
    return;
  }
  const double inv = 1.0 / sim_sqrt(f2);
  fx *= inv;
  fz *= inv;
  if (fx > 1.0) {
    fx = 1.0;
  }
  if (fx < -1.0) {
    fx = -1.0;
  }
  double qw = sim_sqrt(0.5 * (1.0 + fx));
  double qy;
  if (qw > 1e-12) {
    qy = -0.5 * fz / qw;
  } else {
    qw = 0.0;
    qy = fz < 0.0 ? 1.0 : -1.0;
  }
  const double n2 = qw * qw + qy * qy;
  const double ninv = 1.0 / sim_sqrt(n2);
  S.quat[0] = qw * ninv;
  S.quat[1] = 0.0;
  S.quat[2] = qy * ninv;
  S.quat[3] = 0.0;
}

static void stand_apply(void) {
  if (!g_stand_on) {
    return;
  }
  stand_pitch_only();
  S.vel[0] = 0.0;
  S.vel[1] = 0.0;
  S.vel[2] = 0.0;
  S.omega[0] = 0.0;
  S.omega[2] = 0.0;
  double hingeb[3];
  stand_rotate_body(-PLANT_W.arm_x, 0.0, STAND_HINGE_Z, hingeb);
  S.pos[0] = g_stand_hinge[0] - hingeb[0];
  S.pos[1] = g_stand_hinge[1] - hingeb[1];
  S.pos[2] = g_stand_hinge[2] - hingeb[2];
}

static void stand_capture_hinge(void) {
  double hingeb[3];
  stand_rotate_body(-PLANT_W.arm_x, 0.0, STAND_HINGE_Z, hingeb);
  g_stand_hinge[0] = S.pos[0] + hingeb[0];
  g_stand_hinge[1] = S.pos[1] + hingeb[1];
  g_stand_hinge[2] = S.pos[2] + hingeb[2];
}

SIM_EXPORT int sim_set_launch_stand(int on, double px, double py, double pz,
                                    double qw, double qx, double qy, double qz) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  if (!on) {
    g_stand_on = 0;
    return SIM_OK;
  }
  if (!sim_finite(px) || !sim_finite(py) || !sim_finite(pz)
      || !sim_finite(qw) || !sim_finite(qx) || !sim_finite(qy) || !sim_finite(qz)) {
    return SIM_ERR_BAD_ARG;
  }
  const double n2 = qw * qw + qx * qx + qy * qy + qz * qz;
  if (!(n2 > 0.25) || !(n2 < 4.0)) {
    return SIM_ERR_BAD_ARG;
  }
  const double ninv = 1.0 / sim_sqrt(n2);
  S.pos[0] = px;
  S.pos[1] = py;
  S.pos[2] = pz;
  S.quat[0] = qw * ninv;
  S.quat[1] = qx * ninv;
  S.quat[2] = qy * ninv;
  S.quat[3] = qz * ninv;
  S.vel[0] = 0.0;
  S.vel[1] = 0.0;
  S.vel[2] = 0.0;
  S.omega[0] = 0.0;
  S.omega[2] = 0.0;
  g_stand_on = 1;
  stand_pitch_only();
  stand_capture_hinge();
  stand_apply();
  return SIM_OK;
}

SIM_EXPORT int sim_set_angle_mode(int on) {
  bridge_set_angle_mode(on);
  return SIM_OK;
}

/* Flight style flag, see sim_internal.h. Not reset by reset_dynamics on
 * purpose: it is a mode, not dynamic state, same rule as angle mode. */
int SIM_ARCADE = 0;

SIM_EXPORT int sim_set_flight_style(int arcade) {
  SIM_ARCADE = arcade ? 1 : 0;
  return SIM_OK;
}

/* Prop wash flag, see sim_internal.h. A mode, same rule as the flight
 * style. Anything but 0 is the full model. */
int SIM_PROPWASH = 1;

SIM_EXPORT int sim_set_propwash(int on) {
  SIM_PROPWASH = on ? 1 : 0;
  return SIM_OK;
}

/* 3D mode, see sim_internal.h. A mode, same rule as the flight style, and
 * like the airframe it is latched by the controller's init, so the host
 * follows it with sim_reset for it to fly. */
int SIM_3D = 0;

SIM_EXPORT int sim_set_3d(int on) {
  SIM_3D = on ? 1 : 0;
  return SIM_OK;
}

SIM_EXPORT int sim_3d(void) { return SIM_3D; }

/* Realistic physics, see sim_internal.h. A mode, same rule as the flight
 * style. A change of model forgets what the old one left in the air and
 * in the pack. */
int SIM_REAL = 0;

SIM_EXPORT int sim_set_realism(int mask) {
  /* Refused rather than masked, same argument as sim_set_air: a host that
   * sends a bit this build does not have is a newer host, and it should
   * hear that instead of flying something else. */
  if (mask < 0 || (mask & ~SIM_REAL_ALL) != 0) {
    return SIM_ERR_BAD_ARG;
  }
  /* The two that act through the inflow solve are nothing without it. */
  if (!(mask & SIM_REAL_INFLOW)) {
    mask &= ~(SIM_REAL_TANDEM | SIM_REAL_DYNINFLOW);
  }
  if (mask == SIM_REAL) {
    return SIM_OK;
  }
  SIM_REAL = mask;
  plant_set_realism();
  plant_real_forget(&S, 1);
  return SIM_OK;
}

SIM_EXPORT int sim_realism(void) { return SIM_REAL; }

/* A diagnostic, not part of flight: the realistic thrust curve itself, so
 * scripts/realism-check.js can hold the solver to a bisection and to the
 * two ends it is meant to keep. See plant_real_curve. */
SIM_EXPORT double sim_real_curve(int what, double x, double xp) {
  return plant_real_curve(what, x, xp);
}

/* Air scale, see sim_internal.h. A mode, same rule as the flight style. */
double SIM_AIR = 1.0;

SIM_EXPORT int sim_set_air(double scale) {
  /*
   * The band is refused rather than clamped, because a host that asks for
   * air 5 has a bug and a silent clamp hides it. 0.5 to 2.0 is what the
   * shell offers and what was measured; the plant is stable outside it, the
   * machine just stops being a quadcopter.
   */
  if (!(scale >= 0.5) || !(scale <= 2.0)) {
    return SIM_ERR_BAD_ARG;
  }
  SIM_AIR = scale;
  return SIM_OK;
}

SIM_EXPORT double sim_air(void) { return SIM_AIR; }

/* Gravity scale, see sim_internal.h. A mode, same rule as the air scale. */
double SIM_GRAVITY = 1.0;

SIM_EXPORT int sim_set_gravity(double scale) {
  /* Refused rather than clamped, same argument as sim_set_air. */
  if (!(scale >= 0.5) || !(scale <= 2.5)) {
    return SIM_ERR_BAD_ARG;
  }
  SIM_GRAVITY = scale;
  return SIM_OK;
}

SIM_EXPORT double sim_gravity(void) { return SIM_GRAVITY; }

/* Motor power scale, see sim_internal.h. A mode, same rule as the air scale. */
double SIM_MOTOR_KV = 1.0;

SIM_EXPORT int sim_set_motor_kv(double scale) {
  /*
   * Refused rather than clamped, same argument as sim_set_air. 0.8 to 1.2 is
   * what the shell offers and the only range that was measured.
   */
  if (!(scale >= 0.8) || !(scale <= 1.2)) {
    return SIM_ERR_BAD_ARG;
  }
  SIM_MOTOR_KV = scale;
  return SIM_OK;
}

SIM_EXPORT double sim_motor_kv(void) { return SIM_MOTOR_KV; }

/*
 * The airframe. A MODE, not dynamic state, in exactly the sense
 * sim_set_flight_style above is one: it survives sim_reset and sim_init, the
 * shell owns asserting it, and the default is the five inch so a host that
 * never calls this gets the machine this project was built around.
 *
 * Everything that has to move with it moves here rather than being tested
 * for on the hot path: the plant's parameter pointer, the hull corners, and
 * the parked height the ground plane defaults to.
 */
SIM_EXPORT int sim_set_airframe(int id) {
  if (id < 0 || id >= SIM_AIRFRAME_COUNT) {
    return SIM_ERR_BAD_ARG;
  }
  if (id == plant_airframe()) {
    return SIM_OK;
  }
  plant_set_airframe(id);
  contact_build_corners();
  /* Only if the host has not raised its own plane. A shell that has already
   * called sim_set_ground owns that number and must not have it taken back. */
  if (!g_ground_on) {
    g_ground_d = STAND_HINGE_Z;
  }
  return SIM_OK;
}

SIM_EXPORT int sim_airframe(void) { return plant_airframe(); }

SIM_EXPORT int sim_set_launch_control(int on) {
  bridge_set_launch_control(on);
  return SIM_OK;
}

SIM_EXPORT int sim_launch_control_state(void) {
  return bridge_launch_control_state();
}

SIM_EXPORT int sim_motor_override(int motor, double duty) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  if (motor < -1 || motor >= SIM_MOTOR_COUNT) {
    return SIM_ERR_BAD_ARG;
  }
  double d = duty;
  if (d > 1.0) {
    d = 1.0;
  }
  if (d < 0.0) {
    d = -1.0; /* clears */
  }
  if (motor == -1) {
    for (int m = 0; m < SIM_MOTOR_COUNT; m += 1) {
      g_override[m] = d;
    }
  } else {
    g_override[motor] = d;
  }
  return SIM_OK;
}

SIM_EXPORT int sim_step(int n) {
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  if (n < 0) {
    return SIM_ERR_BAD_ARG;
  }
  for (int k = 0; k < n; k += 1) {
    /* Consume every sample whose timestamp falls inside this step. Each
     * consumed sample is an RC frame for the controller. */
    const long long step_end_us = (S.step_index + 1) * (1000000LL / SIM_STEP_HZ);
    int rx_new = 0;
    while (g_q_head != g_q_tail && g_queue[g_q_head].t_us < step_end_us) {
      g_current_rc[0] = g_queue[g_q_head].ch[0];
      g_current_rc[1] = g_queue[g_q_head].ch[1];
      g_current_rc[2] = g_queue[g_q_head].ch[2];
      g_current_rc[3] = g_queue[g_q_head].ch[3];
      g_q_head = (g_q_head + 1) % INPUT_QUEUE_CAP;
      rx_new = 1;
    }
    double duty[SIM_MOTOR_COUNT];
    bridge_run(&S, g_current_rc, rx_new, duty);
    for (int m = 0; m < SIM_MOTOR_COUNT; m += 1) {
      if (g_override[m] >= 0.0) {
        duty[m] = g_override[m];
      }
    }
    /*
     * Where the floor is, for the plant's ground effect. The same plane the
     * contact solver below resolves against, measured to the CG along its
     * normal; negative when no plane has been raised, which switches the
     * term off. Computed here rather than in the plant because the plane is
     * this file's, and handed over as two numbers rather than a callback so
     * plant_step stays a pure function of its state.
     */
    /* This step's ground: the shell's plane, or a roof the CG is over. Only
     * with a world loaded, so a harness replay never reaches it. */
    if (g_ground_on && !g_stand_on && world_active()) {
      world_select_support(&S, g_terrain_n, g_terrain_d, g_ground_n, &g_ground_d);
    }
    if (g_ground_on) {
      S.ground_h = g_ground_n[0] * S.pos[0] + g_ground_n[1] * S.pos[1]
        + g_ground_n[2] * S.pos[2] - g_ground_d;
      S.ground_n[0] = g_ground_n[0];
      S.ground_n[1] = g_ground_n[1];
      S.ground_n[2] = g_ground_n[2];
    } else {
      S.ground_h = -1.0;
    }
    plant_step(&S, duty);
    ground_apply();
    if (g_ground_on && !g_stand_on) {
      ground_stall();
    }
    if (!g_stand_on) {
      world_step(&S, g_ground_on, g_ground_n, g_ground_d);
    }
    stand_apply();
    /* The road vehicles' clock, here and not in world_step, because the
     * stand skips world_step and the traffic does not wait for a launch. */
    world_tick();
    S.step_index += 1;
  }
  return SIM_OK;
}

SIM_EXPORT int sim_state_size(void) { return SIM_STATE_DOUBLES; }

SIM_EXPORT int sim_state(double *out) {
  if (out == 0) {
    return SIM_ERR_BAD_ARG;
  }
  if (!g_initialised) {
    return SIM_ERR_BAD_STATE;
  }
  out[0] = (double)S.step_index / (double)SIM_STEP_HZ;
  out[1] = S.pos[0];
  out[2] = S.pos[1];
  out[3] = S.pos[2];
  out[4] = S.vel[0];
  out[5] = S.vel[1];
  out[6] = S.vel[2];
  out[7] = S.quat[0];
  out[8] = S.quat[1];
  out[9] = S.quat[2];
  out[10] = S.quat[3];
  out[11] = S.omega[0];
  out[12] = S.omega[1];
  out[13] = S.omega[2];
  /* rad/s to RPM is a display conversion fixed by the ABI. */
  const double to_rpm = 60.0 / (2.0 * 3.14159265358979323846);
  out[14] = S.motor_omega[0] * to_rpm;
  out[15] = S.motor_omega[1] * to_rpm;
  out[16] = S.motor_omega[2] * to_rpm;
  out[17] = S.motor_omega[3] * to_rpm;
  out[18] = S.vbat_load;
  out[19] = S.pack_current;
  return SIM_OK;
}
