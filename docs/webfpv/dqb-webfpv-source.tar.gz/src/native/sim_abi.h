/*
 * sim_abi.h: the ABI between the compiled physics module and every host,
 * meaning the verification harness (Node and browser) and later the render
 * shell. This header is the contract. The harness in tests/ is written
 * against it and tests/ is read-only to the simulator implementer, so any
 * change here is an ABI change and must be argued in PROGRESS.md first.
 *
 * This file is part of WebFPVSimulator.
 *
 * WebFPVSimulator is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at
 * your option) any later version.
 *
 * WebFPVSimulator is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY, without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebFPVSimulator. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef SIM_ABI_H
#define SIM_ABI_H

/*
 * Conventions, fixed by CLAUDE.md and this header:
 *
 * World frame: right-handed, z up, metres, SI throughout.
 * Body frame: right-handed, x forward, y left, z up.
 *   Positive p (about body x) rolls the quad to the right.
 *   Positive q (about body y) pitches the nose down.
 *   Positive r (about body z) yaws the nose to the left, counter-clockwise
 *   seen from above.
 *
 * Stick channels, as stored in .rec files and passed to sim_input:
 *   roll     -1..+1, +1 commands a roll to the right
 *   pitch    -1..+1, +1 commands nose up
 *   yaw      -1..+1, +1 commands nose right
 *   throttle  0..+1
 * Mapping these RC-convention channels onto Betaflight's internal signs is
 * the bridge's job, not the host's.
 *
 * Time: the module steps at a fixed 1000 Hz. One step is exactly 1 ms of
 * simulated time. sim_step(n) advances n steps. How the host batches calls
 * to sim_step must not affect the trajectory. Input samples carry their own
 * timestamps and the module consumes them by that timestamp, never by
 * arrival order relative to real time.
 */

#define SIM_ABI_VERSION 1

/* Physics step rate, Hz. Fixed. */
#define SIM_STEP_HZ 1000

/* Return codes. Every entry point returning int uses these. */
#define SIM_OK 0
#define SIM_ERR_NOT_IMPLEMENTED -1
#define SIM_ERR_BAD_ARG -2
#define SIM_ERR_BAD_STATE -3
#define SIM_ERR_CONFIG_PARSE -4

/*
 * State block layout, doubles, written by sim_state:
 *   [0]      t, simulated time, seconds
 *   [1..3]   position x y z, metres, world frame
 *   [4..6]   velocity x y z, m/s, world frame
 *   [7..10]  attitude quaternion w x y z, body to world
 *   [11..13] angular rate p q r, rad/s, body frame
 *   [14..17] motor RPM, motors 0..3 in Betaflight order
 *            (0 rear right, 1 front right, 2 rear left, 3 front left)
 *   [18]     pack voltage under load, volts
 *   [19]     pack current draw, amps
 */
#define SIM_STATE_DOUBLES 20

/*
 * Entry points. All are exported from the WASM module under these exact
 * names. The stub implementation returns SIM_ERR_NOT_IMPLEMENTED from every
 * entry point except sim_abi_version, which must always report the version
 * so a host can tell "module loaded, not implemented yet" from "wrong
 * module".
 */

/* Returns SIM_ABI_VERSION compiled into the module. */
int sim_abi_version(void);

/*
 * Initialise from a Betaflight CLI diff, UTF-8 text of the given length.
 * Full reset: config parsed and applied, dynamic state zeroed as in
 * sim_reset. Returns SIM_OK or an error code.
 */
int sim_init(const unsigned char *diff_utf8, int len);

/*
 * Reset dynamic state, keeping the parsed config. After reset: t = 0, quad
 * level and at rest at the world origin, free in the air (no ground contact
 * in the reset pose), motors stopped, armed, airmode on, battery at the
 * currently configured open-circuit cell voltage.
 */
int sim_reset(void);

/* Set open-circuit per-cell voltage, volts. Takes effect immediately. */
int sim_set_cell_voltage(double volts);

/*
 * Deliver one input sample. t_seconds is the sample's own timestamp on the
 * simulated clock. Samples arrive in non-decreasing timestamp order, always
 * before the 1 ms step in which their timestamp falls is executed. The
 * stream restarts at t = 0 after sim_init or sim_reset.
 */
int sim_input(double t_seconds, double roll, double pitch, double yaw,
              double throttle);

/* Advance n fixed 1 ms steps. n >= 0. */
int sim_step(int n);

/*
 * Bench override for check 8, motor-step-response. While a motor is
 * overridden the flight controller output for that motor is replaced by
 * the given duty, 0..1. motor is 0..3, or -1 for all motors. A negative
 * duty clears the override for the addressed motor or motors.
 */
int sim_motor_override(int motor, double duty);

/*
 * The ground holds the craft: zero the linear velocity and the body rates,
 * keeping position, attitude, motor speeds and battery state. The shell
 * calls this once at the moment a touchdown is judged a landing, because a
 * craft resting on the ground is held by a normal force this free-air model
 * does not have. Without it the frozen landed state kept its touchdown
 * descent rate, every freeze/unfreeze cycle of a slow takeoff resumed and
 * grew it, and at 60 fps a gentle throttle ramp accumulated 2.1 m/s of
 * phantom descent and was judged a crash the pilot never flew. Additive ABI
 * change, version unchanged: no existing entry point moved or changed
 * meaning. A replay that reproduces a flown session must issue the same
 * call at the same step, which the shell guarantees by deriving it from the
 * deterministic landing judgement.
 */
int sim_rest(void);

/*
 * Bounce off a world-frame contact. n is a unit normal pointing out of the
 * obstacle (from the solid toward the craft). Incoming speed along n is
 * reflected with the given restitution, the tangent is scaled by
 * tangent_keep, body rates are scaled by rate_keep, and the craft is placed
 * at world position p (metres, z up). The shell supplies p at the first
 * contact plus a small outward separation, already converted into the plant
 * frame, so a tunneled frame is rewound to the entry face rather than
 * pushed further through.
 *
 * This is the obstacle counterpart of sim_rest: the plant has no scene
 * geometry, so the shell judges the contact and writes the impulse. Additive
 * ABI change, version unchanged: no existing entry point moved or changed
 * meaning. A replay that never calls this is bit-identical to one from
 * before it existed. The verification harness never calls it.
 */
int sim_deflect(double nx, double ny, double nz,
                double restitution, double tangent_keep, double rate_keep,
                double px, double py, double pz);

/*
 * Rigid-body contact against a world-frame surface. n is a unit normal
 * pointing out of the solid. The impulse is applied at the airframe hull
 * support in the -n direction, so an offset hit produces spin: a wall tap
 * yaws, a side arrival rolls. Coulomb friction with coefficient mu kills
 * or limits the tangent speed at that point, which is what a ground slide
 * and a tumbling crash both are. vs is the surface velocity (zero for a
 * static wall, the train's velocity for a moving car). The craft is placed
 * at p, already converted into the plant frame, so a tunneled frame is
 * rewound to the entry face.
 *
 * Restitution falls with closing speed inside the solver, so a 20 m/s
 * arrival dumps energy instead of bouncing like a ball, and a slow skip
 * still skips. Additive ABI, version unchanged. The harness never calls
 * this: a replay that never touches a surface is bit-identical to one
 * from before it existed.
 */
int sim_contact(double nx, double ny, double nz,
                double restitution, double mu,
                double px, double py, double pz,
                double vsx, double vsy, double vsz);

/*
 * Rigid-body contact with the contact point supplied by the caller.
 *
 * sim_contact takes its impulse arm from the hull's own support in the
 * -n direction, which is always an extreme corner, so a belly slapped
 * flat on a wall solved as a corner strike and produced the largest
 * moment the geometry allows. The shell sweeps the four prop discs and
 * knows which of them are actually in the patch, so it passes the arm
 * in: (rx, ry, rz) is the vector from the CG to the contact point,
 * plant frame, world axes, clamped inside the airframe. One disc in
 * gives a full moment, four gives almost none, which is the difference
 * between an arm catching a wall and a belly meeting it.
 *
 * Everything else matches sim_contact. Additive ABI, version unchanged.
 * The harness never calls this.
 */
int sim_contact_at(double nx, double ny, double nz,
                   double restitution, double mu,
                   double px, double py, double pz,
                   double vsx, double vsy, double vsz,
                   double rx, double ry, double rz);

/*
 * Blade strike: every rotor loses sev of its speed, sev in 0 to 1.
 *
 * A spinning 5 inch does not carry its rotor energy through a wall.
 * The mixer spins them back up at the motor's own time constant, which
 * is the part the pilot feels. No damage model and no desync. Additive
 * ABI, version unchanged. The harness never calls this.
 */
int sim_prop_strike(double sev);

/*
 * Persistent ground plane, applied after every 1 ms plant_step, the same
 * way the launch stand is. n is a unit normal pointing out of the ground,
 * (px,py,pz) is a point on the plane, both plant frame. mu and restitution
 * are Coulomb friction and the low-speed coefficient of restitution.
 * Off (0) is the default, and the path every harness replay takes, so
 * free-air checks cannot see a floor. Additive ABI, version unchanged.
 */
int sim_set_ground(int on,
                   double nx, double ny, double nz,
                   double px, double py, double pz,
                   double mu, double restitution);

/*
 * How many hull points took a ground contact on the last step. Belly
 * landings count penetrating corners. A roll or a turtle is a single
 * support, so this is 0 or 1. The shell uses it to know whether the
 * craft is in contact (turtle, perch) without re-deriving the hull.
 * Zero when the ground plane is off.
 */
int sim_ground_contacts(void);

/*
 * Enable or disable Betaflight crashflip (turtle mode). Off (0) is the
 * default and the path every harness replay takes. On (non-zero) makes
 * mixTable take applyFlipOverAfterCrashModeToMotors, which is already
 * compiled in from mixer.c: pitch and roll sticks spin the high motors
 * to flip the craft over. I-term is dumped on both edges so a wound PID
 * cannot yank the craft when turtle latches or drops. The plant does not
 * read this, and DShot reverse is not modelled (the same stub as other
 * DShot commands). Additive ABI, version unchanged.
 */
int sim_set_crashflip(int on);

/* 1 when crashflip is latched, 0 otherwise. */
int sim_crashflip_active(void);

/*
 * Write plant pose. Quaternion is normalised. Velocity and rates are
 * untouched; call sim_rest after if the host wants a still pose. Additive
 * ABI, version unchanged. The harness never calls this. Used by the
 * contact self-test to seat an inverted hull for turtle, and available
 * to the shell if a future path needs to place the craft without the
 * launch-stand constraint.
 */
int sim_set_pose(double px, double py, double pz,
                 double qw, double qx, double qy, double qz);

/*
 * Enable or disable Betaflight ANGLE_MODE. Off (0) is acro, the default,
 * and the path every harness replay takes. On (non-zero) feeds the plant
 * attitude into Betaflight's compiled pidLevel and sets ANGLE_MODE, so
 * stick is a tilt target and centred sticks recover to level. Plant,
 * mixer and the acro PID are not reimplemented here: this is the same
 * flag a radio aux switch would raise. Additive ABI change, version
 * unchanged: no existing entry point moved or changed meaning. A replay
 * that never calls this is bit-identical to one from before it existed.
 */
int sim_set_angle_mode(int on);

/*
 * Enable or disable Betaflight launch control, the race-start hold.
 * Off (0) is the default, and the path every harness replay takes.
 * On (non-zero) is BOXLAUNCHCONTROL at arm: pid.c's applyLaunchControl
 * holds attitude at idle throttle until the stick crosses
 * launch_trigger_throttle_percent, then the mixer releases throttle
 * and the feature latches off. Additive ABI change, version unchanged:
 * no existing entry point moved or changed meaning. A replay that never
 * calls this is bit-identical to one from before it existed.
 */
int sim_set_launch_control(int on);

/*
 * Launch control state for the OSD. 0 off, 1 holding, 2 holding and
 * throttle within 10 percent of the trigger, 3 launched this arm.
 * Additive, same rule as sim_set_launch_control.
 */
int sim_launch_control_state(void);

/*
 * Mechanical launch stand. Off (0) is the default. On (non-zero) holds
 * the craft on a hinge at the rear underside: linear velocity is killed,
 * roll and yaw rates are killed, attitude is projected onto pitch about
 * world y (nose down), and the rear contact stays put so pitching does
 * not walk the quad off the block. qw..qz is the pitch-only pose to
 * seed when raising the stand, matching a ramp that the shell drew as
 * a render overlay while landed. Applied inside sim_step, so a batched
 * frame cannot accumulate gyroscopic roll between pins. Additive ABI,
 * version unchanged. The harness never calls this.
 */
int sim_set_launch_stand(int on, double px, double py, double pz,
                         double qw, double qx, double qy, double qz);

/*
 * Flight style. 0 is expert, the default and the full model, the path
 * every harness replay takes. Non-zero is arcade: the imperfection terms
 * are switched off so the craft flies as the symmetric ideal it is drawn
 * as. Arcade removes the propwash turbulence application, the per rotor
 * ring state asymmetry, the motor cant tables (thrust axes become exactly
 * vertical, so the build tolerance yaw coupling and its hover trim go),
 * and the gyro vibration and noise floor. The smooth aerodynamics stay:
 * advance ratio, ring state thrust loss, rotor drag, translational lift,
 * body side lift and the torque inflow coupling are physics, not
 * imperfections. Survives sim_reset and sim_init, exactly as the angle
 * mode flag does, so a shell that set it before a tune swap still has it
 * after. Additive ABI change, version unchanged: a replay that never
 * calls this is bit-identical to one from before it existed, which is
 * what keeps every recorded check honest.
 */
int sim_set_flight_style(int arcade);

/*
 * Prop wash. 1, the default, is the full model. 0 removes only the shake a
 * quad feels in its own wash: the propwash turbulence application and the
 * per rotor ring state asymmetry, the same two terms arcade removes, while
 * the cant tables, the gyro noise and the smooth ring state thrust loss
 * stay. Survives sim_reset and sim_init, same as the flight style. Additive
 * ABI change, version unchanged: a replay that never calls this is
 * bit-identical to one from before it existed.
 */
int sim_set_propwash(int on);

/*
 * 3D mode. 0, the default, is the quad every check was measured on. 1 is
 * Betaflight's FEATURE_3D with a bidirectional DShot ESC and 3D props: the
 * throttle channel's middle is no thrust, the top half drives the motors
 * forward and the bottom half drives them backwards, so the quad can hang
 * and fly upside down. The controller latches it when it is initialised,
 * so it takes effect at the next sim_reset or sim_init; the plant reads it
 * every step. Survives sim_reset and sim_init, same as the flight style.
 * sim_3d returns what is set. Additive ABI change, version unchanged: a
 * replay that never calls this is bit identical to one from before it
 * existed. In 3D mode the motor speeds sim_state reports are signed,
 * negative for a rotor spinning backwards.
 */
int sim_set_3d(int on);
int sim_3d(void);

/*
 * Realistic physics. 0, the default, is the plant every check was measured
 * on and every pilot has flown. Otherwise a set of bits, each one
 * correction to that plant:
 *
 *     1  thrust from blade element and momentum theory solved together
 *     2  the airframe's inertia and the motors' lag, as logged
 *     4  ground effect on the five inch
 *     8  prop wash from the craft's own remembered wake
 *    16  a pack that runs down, with sag that builds and recovers
 *    32  downstream rotors in the upstream rotors' wake (needs 1)
 *    64  the air's own lag behind a throttle change (needs 1)
 *   128  the pack's resistance as logged, without the running down
 *
 * 255 is all of them. A bit this build does not have is refused with
 * SIM_ERR_BAD_ARG. Takes effect on the next step, mid flight included, and
 * a change forgets the remembered wake and puts the pack back to the
 * charge sim_set_cell_voltage gave it. Survives sim_reset and sim_init,
 * same as the flight style; sim_reset is a fresh pack. sim_realism returns
 * what is set. It does not touch gravity: a host that wants the real
 * weight asks sim_set_gravity for 1.0 as well.
 *
 * Additive ABI change, version unchanged: a replay that never calls this
 * is bit identical to one from before it existed, and the state block
 * sim_state fills is the same twenty doubles either way.
 */
int sim_set_realism(int mask);
int sim_realism(void);
/* A diagnostic for the checks, not part of flight: the realistic thrust
 * curve for the airframe in force. what 0 is the thrust factor at axial
 * speed x and edgewise speed xp, both as multiples of the induced velocity
 * at rest; 1 is the induced velocity as the same multiple; 2 is the blade
 * element constant. */
double sim_real_curve(int what, double x, double xp);

/*
 * Choose the airframe: 0 is the five inch this project was built around and
 * is the default, 1 is a 65 mm 1S brushless whoop. Returns SIM_ERR_BAD_ARG
 * for anything else.
 *
 * Additive ABI change, version unchanged: no existing entry point moved or
 * changed meaning, and a replay that never calls this is bit identical to
 * one from before it existed. That last clause is MEASURED rather than
 * asserted, because selecting a plant at runtime costs the compiler its
 * constant folding of the parameter block; the build's -fno-fast-math and
 * -ffp-contract=off make a folded expression and a computed one the same
 * IEEE double, and the five inch's trace hash is checked unchanged across
 * the change. See PROGRESS.md.
 *
 * A MODE, not state: it survives sim_reset and sim_init, exactly as the
 * flight style does. Changing it swaps the plant's mass, inertia, motors,
 * rotors, pack, drag, duct terms, collision hull and camera position in one
 * step, so a host should do it between runs and then sim_reset.
 */
#define SIM_AIRFRAME_5IN_ID 0
#define SIM_AIRFRAME_WHOOP65_ID 1
int sim_set_airframe(int id);

/* Which airframe is in force. */
int sim_airframe(void);

/*
 * Air: a scale on everything the air does to slow the craft down. 1.0 is the
 * default and the machine every threshold in tests/ and every band in
 * gates.config.json was measured against, and it is the path every harness
 * replay takes. The accepted range is 0.5 to 2.0; anything outside it returns
 * SIM_ERR_BAD_ARG rather than being clamped, because a host asking for air 5
 * has a bug and a silent clamp hides it.
 *
 * This is the pilot's answer to "floaty", which is the word the board keeps
 * sending back. It scales the per axis body drag areas, the rotor H force and
 * the ducted descent brake, and nothing else: hover throttle, punch, climb,
 * rate response and the whole electrical model are untouched, so what moves
 * is how far the craft carries with the sticks centred and how fast it will
 * go flat out. What each term is and why the others are left alone is in
 * src/native/sim_internal.h at SIM_AIR.
 *
 * A MODE, not state: it survives sim_reset and sim_init exactly as the flight
 * style and the airframe do, so a shell that set it before a tune swap still
 * has it after. Additive ABI change, version unchanged: no existing entry
 * point moved or changed meaning, and a replay that never calls this is bit
 * identical to one from before it existed. That is MEASURED against the
 * recorded trace hash rather than asserted, because a runtime multiply costs
 * the compiler its constant folding, which is the same argument
 * sim_set_airframe carries. See PROGRESS.md.
 */
int sim_set_air(double scale);

/* The air scale in force. */
double sim_air(void);

/*
 * Gravity: a scale on the weight the craft carries. 1.0 is 9.80665 and the
 * machine every threshold in tests/ and every band in gates.config.json was
 * measured against, and it is the path every harness replay takes. The
 * accepted range is 0.5 to 2.5; outside it returns SIM_ERR_BAD_ARG rather
 * than being clamped, same argument as sim_set_air.
 *
 * THIS IS THE AXIS A PILOT MEANS BY FLOATY, and sim_set_air above is the
 * other one. Air is horizontal: how far the craft carries with the sticks
 * centred. Gravity is vertical: how fast it comes down and how little it
 * hangs. Asked to fly the air slider across its whole band, the pilot who
 * reported the complaint said the difference was hardly discernible, and
 * named what they wanted instead: floaty to sinky. Measured over each band,
 * on the vertical axis, air moved hover throttle not at all, the balloon
 * after a short punch by nine percent, and the time to fall ten metres the
 * WRONG WAY, because more drag lowers the terminal. Gravity moves hover from
 * 21.7 to 37.2 percent of stick, the balloon from 6.28 to 1.26 m and the fall
 * from 1.88 to 1.13 s.
 *
 * It scales the weight term in plant_step and the two ground load terms in
 * sim.c, because a heavier craft presses harder on the floor. Inertia,
 * drag, the motors and the pack are untouched, so the craft rotates
 * identically and every rate figure holds.
 *
 * A MODE, not state: it survives sim_reset and sim_init exactly as the air
 * scale, the flight style and the airframe do. Additive ABI change, version
 * unchanged, and a replay that never calls this is bit identical to one from
 * before it existed. MEASURED against the recorded trace hash, not asserted.
 */
int sim_set_gravity(double scale);

/* The gravity scale in force. */
double sim_gravity(void);

/*
 * Motor power: a scale on the motor's kV. 1.0 is the motor the airframe table
 * describes, the machine every threshold in tests/ and every band in
 * gates.config.json was measured against, and the path every harness replay
 * takes. The accepted range is 0.8 to 1.2; outside it returns SIM_ERR_BAD_ARG
 * rather than being clamped, same argument as sim_set_air.
 *
 * It is the pilot's answer to "more power" or "less twitchy": the same motor
 * wound hotter or milder on the same pack. The back EMF constant goes down by
 * the scale and the winding resistance by its square, so the no load speed
 * and the stall torque both go up by the scale, the stall current by its
 * square, and the motor's own time constant stays where it was. Hover needs
 * the same rotor speed as before and so sits 1 / scale as deep in the duty
 * range; full throttle turns the rotor faster. Mass, inertia, the prop, the
 * pack, the air and every Betaflight setting are untouched. What it does and
 * does not claim is in src/native/sim_internal.h at SIM_MOTOR_KV.
 *
 * A MODE, not state: it survives sim_reset and sim_init exactly as the air
 * scale, the gravity scale, the flight style and the airframe do. Additive ABI
 * change, version unchanged: no existing entry point moved or changed meaning,
 * and a replay that never calls this, or calls it with 1.0, is bit identical
 * to one from before it existed. MEASURED against the plant golden and the
 * recorded trace hash, not asserted. See PROGRESS.md.
 */
int sim_set_motor_kv(double scale);

/* The motor power scale in force. */
double sim_motor_kv(void);

/*
 * THE SOLID WORLD, src/native/world.c. Since 2026-09-24 every wall, roof,
 * gate, tree and the train is resolved inside the plant at 1 kHz, by the
 * same step as the ground, instead of by a shell pass that ran after the
 * fact every 4 ms. The owner approved the move with soft props and with no
 * automatic teleport; PROGRESS.md carries the review and the numbers.
 *
 * All positions are the physics frame (Z up, SI), the shell converting
 * through src/render/frame.js as it does every other position. The world is
 * held in WORLD coordinates and the plant's own origin is placed in it by
 * sim_world_frame, so a restart moves one origin rather than every shape.
 *
 * Additive ABI change, version unchanged: no existing entry point moved or
 * changed meaning, and a module that is never handed a world is bit
 * identical to one from before these existed. That is MEASURED, by
 * scripts/plant-golden.js, which hashes the state after every 1 ms step
 * across 21 scenarios and was recorded before world.c was written. The
 * harness never calls any of these.
 *
 * e and mu are the low-speed restitution and the Coulomb friction, e in 0
 * to 1 and mu in 0 to 2, anything else SIM_ERR_BAD_ARG.
 */

/* Empty the world: shapes, movers and the grid. */
int sim_world_clear(void);

/*
 * Place the plant's origin in the world: a world point is Rz(yaw) times the
 * plant point, plus (ox, oy, oz). yaw is radians about world +z, turned into
 * a rotation with the module's own libm. Must follow every move of the
 * shell's spawn, or the world the plant sees is somewhere else.
 */
int sim_world_frame(double ox, double oy, double oz, double yaw);

/*
 * An axis aligned box, world frame, min corner then max corner. Returns its
 * index, which is the order shapes were added in, so the host can keep its
 * own table beside it and read a reported contact against it. Returns
 * SIM_ERR_BAD_STATE when the world is full.
 */
int sim_world_box(double x0, double y0, double z0,
                  double x1, double y1, double z1,
                  double e, double mu);

/* A capsule: the segment a to b and a radius r > 0, world frame. A sphere
 * is a capsule with a == b. Returns its index, as sim_world_box does. */
int sim_world_capsule(double ax, double ay, double az,
                      double bx, double by, double bz,
                      double r, double e, double mu);

/* Change box i's vertical extent, for the level crossing's booms. The
 * footprint is what the grid files a box under, so it cannot change. */
int sim_world_box_z(int i, double z0, double z1);

/*
 * Mover m (0 to 63): a box that moves, set every step from the map's own
 * closed form, so its position is a function of the step count and nothing
 * else. v is its surface velocity, m/s, which the contact reads for
 * friction and restitution. x1 < x0 parks it. The movers and the road
 * vehicles below share the 64 slots; seating or parking a box in a slot
 * ends a vehicle there.
 */
int sim_world_mover(int m, double x0, double y0, double z0,
                    double x1, double y1, double z1,
                    double vx, double vy, double vz,
                    double e, double mu);

/*
 * File every shape in the ground-plane grid. Nothing is solved until this
 * has run. Returns the number of shapes, or SIM_ERR_BAD_STATE when the
 * grid cannot hold them, which a host must treat as loudly as a missing
 * export: a world the plant does not have is one the craft flies through.
 */
int sim_world_build(void);

/* How many shapes the world holds. */
int sim_world_count(void);

/*
 * The box acting as the ground this step, or -1 for the shell's own plane.
 * A roof is ground: when the CG is over the top of a box higher than the
 * plane sim_set_ground raised, that top replaces the plane for the step,
 * so a roof lands, slides, settles, perches and turtles as the street does.
 */
int sim_world_support(void);

/*
 * What touched what since the last read, then cleared. Eleven doubles:
 *   [0]      steps with any obstacle contact
 *   [1]      largest closing speed, m/s
 *   [2]      largest CG velocity change in one step, m/s
 *   [3]      the shape of [2]; -2 - m for mover m, -1 none
 *   [4..6]   its normal, world frame, out of the solid
 *   [7]      steps with a prop disc in contact
 *   [8]      steps with a frame or lens contact
 *   [9]      deepest penetration seen, m
 *   [10]     the support box now, -1 for the shell's plane
 */
#define SIM_WORLD_REPORT_DOUBLES 11
int sim_world_report(double *out);

/*
 * ROAD VEHICLES, src/native/world.c section 5 (Stage D part 2, P2 of
 * FREESTYLE-MAPS-PLAN.md): movers that turn, and follow a road inside the
 * module, their pose a pure function of the module's own step clock. That
 * file's header carries the whole of it; in brief:
 *
 *   sim_world_road(xyz, n, closed)   a road, n points of x y z, world frame;
 *                                    returns its index
 *   sim_world_road_info(road, out)   [points kept, length m, closed]
 *   sim_world_vehicle(m, road, offset, top_speed, lateral, drift,
 *                     length, width, height, clearance, e, mu)
 *                                    mover m follows the road
 *   sim_world_clock(step)            the vehicles' clock, whole 1 ms steps
 *   sim_world_vehicle_poses(out)     every slot's pose, 64 of 16 doubles:
 *     [0] 1 when the slot is a road vehicle, else the slot is all zeros
 *     [1..3] the road point under its centre, world, m
 *     [4..5] its heading in plan, unit, the drift in it
 *     [6] speed along the road, m/s   [7] distance driven, m
 *     [8..10] velocity, world, m/s    [11] yaw rate about +z, rad/s,
 *       how fast the box turns from this pose to the next step's (the
 *       two are what a contact on the car reads)
 *     [12..13] direction of travel in plan, unit
 *     [14] the path's curvature along the travel, 1/m, left positive
 *     [15] tan(slip / 2), left positive, 0 for an ordinary car
 *   sim_world_vehicle_contacts(out, max)
 *                                    the last step's contacts against road
 *                                    vehicles, up to max of 12 doubles;
 *                                    returns how many there were:
 *     [0] slot m   [1] 0 the hull, 1 the lens, 2 a prop (at its hub)
 *     [2..4] the point, world, m     [5..7] the normal, world, unit, from
 *     the car toward the craft       [8..10] the car's surface velocity
 *     there, world, m/s              [11] the depth, m
 *
 * A vehicle is never ground. Additive: a module that is never handed a road
 * steps exactly as it did before these existed. A road with a point that
 * turns more than 30 degrees in plan, or folds back, is refused: bends are
 * eased over several points.
 */
#define SIM_VEHICLE_POSE_DOUBLES 16
#define SIM_VEHICLE_CONTACT_DOUBLES 12
#define SIM_ROAD_INFO_DOUBLES 3
int sim_world_road(const double *xyz, int n, int closed);
int sim_world_road_info(int road, double *out);
int sim_world_vehicle(int m, int road, double offset,
                      double top_speed, double lateral, double drift,
                      double length, double width, double height,
                      double clearance, double e, double mu);
int sim_world_clock(double step);
int sim_world_vehicle_poses(double *out);
int sim_world_vehicle_contacts(double *out, int max);

/* Number of doubles sim_state writes. SIM_STATE_DOUBLES for this version. */
int sim_state_size(void);

/* Write the state block described above into out. */
int sim_state(double *out);

#endif /* SIM_ABI_H */
