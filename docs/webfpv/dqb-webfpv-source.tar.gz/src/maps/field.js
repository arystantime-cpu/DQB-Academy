/*
 * field.js: the track world's composer wrap.
 *
 * The world itself is still src/render/scene.js and its post chain is still
 * src/render/post.js. This file is the join: it hands the scene builder the
 * session's renderer, camera and airframe, wraps the composer so maps
 * present the same `post` object, and adds a dispose that frees the
 * composer's render targets as well as the scene graph. custom.js is the
 * map the player flies; this file is the shared wrap.
 *
 * This file is part of WebFPVSimulator.
 *
 * WebFPVSimulator is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at
 * your option) any later version.
 *
 * WebFPVSimulator is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY, without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebFPVSimulator. If not, see <https://www.gnu.org/licenses/>.
 */

import { buildFieldScene } from '../render/scene.js';
import { yieldToPaint } from '../ui/loading.js';
import { buildComposer } from '../render/post.js';
import { qualityFor } from '../render/quality.js';
import { warmPrograms } from '../render/warm.js';

/*
 * Give a built scene its composer, and a dispose that frees both.
 *
 * Exported because custom.js needs the identical seven lines: the field and
 * the custom map are the same world with a different course in it, and the
 * dispose in particular is not a detail to keep two copies of.
 */
export async function attachComposer(shell, map, q) {
  const post = buildComposer(shell.renderer, map.scene, shell.camera, q);
  const d = shell.resize();
  post.setSize(d.w, d.h);
  /* The scene's programs, linked now and against the composer's own target,
   * which is what its frames draw into: see render/warm.js. */
  await warmPrograms(shell.renderer, map.scene, shell.camera, post.composer.renderTarget1);
  const sceneDispose = map.dispose;
  map.post = post;
  map.dispose = () => {
    /* The composer knows what it owns: targets, the bloom ladder, and the
     * pass materials whose compiled programs the renderer caches. Freeing
     * only the targets here is how a handful of shader programs used to
     * leak on every swap. */
    post.dispose();
    sceneDispose();
  };
  return map;
}

/*
 * Report a phase AND give the loading screen a frame to draw it in.
 *
 * buildFieldScene awaits whatever its progress callback returns, so this is
 * where the map decides that a report is worth a paint. It is: without it
 * the seven phases inside the build all land in one blocked run of the main
 * thread and the bar shows none of them. Two frames and a task is the
 * shortest sequence that guarantees the pixels are actually on screen; see
 * yieldToPaint in src/ui/loading.js for why one is not enough.
 */
function reporter(progress) {
  return async (f) => {
    progress(f);
    await yieldToPaint();
  };
}

export async function buildMap(shell, onProgress, options) {
  const progress = onProgress ?? (() => {});
  const q = qualityFor(options && options.quality);
  return attachComposer(shell, await buildFieldScene(shell, reporter(progress), null, q), q);
}
