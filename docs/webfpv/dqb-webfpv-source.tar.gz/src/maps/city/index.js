/*
 * city.js: the freestyle map. A whole Japanese suburban railway crossing
 * town, vendored from sakura-crossing under MIT and flown rather than walked.
 *
 * WHAT IS OURS AND WHAT IS THEIRS. Everything under ./vendored/ is Kenton
 * Wang's, MIT, and stays that way: see /NOTICE and ./vendored/LICENSE. This
 * file is ours, GPLv3, and it is the whole of the join. It builds the town,
 * lights it, gives it a contact model a quad can crash into, and drives its
 * one moving part from the physics clock instead of from frame time.
 *
 * THE FLAT AUTHORING IS TAKEN, THE PLANET IS NOT. The town is authored on a
 * flat plane and its own source says so at the bake call site: "Everything
 * above this line is still authored on a flat plane and has no idea the
 * planet exists". `bakeToPlanet` is a pure post pass over the object graph,
 * so it is a choice. We decline it, for two reasons that both matter.
 *
 *   1. Our physics is right handed Z up and the conversion to three.js Y up
 *      happens exactly once, in src/render/frame.js. A sphere of radius 160 m
 *      compresses x by cos(z / R), which is 0.37 at z = -190, and no single
 *      conversion can express that. Taking the flat authoring means the town
 *      drops into our space with NO transform and frame.js is not touched.
 *   2. The bake bends every mesh onto a 160 m sphere, which gives every one
 *      of them a bounding sphere the size of the planet, which disables
 *      frustum culling for the whole world. Measured both ways in this file's
 *      round of PROGRESS.md.
 *
 * The cost is the curved horizon, which is a look rather than a feature, and
 * the town's x wrap, which a quad has no reason to reach.
 *
 * This file is part of WebFPVSimulator.
 *
 * WebFPVSimulator is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at
 * your option) any later version.
 *
 * WebFPVSimulator is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY, without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with WebFPVSimulator. If not, see <https://www.gnu.org/licenses/>.
 */

import * as THREE from 'three';
import { PAL } from './vendored/core/palette.js';
import { Pipeline } from './vendored/core/post.js';
import { mangaPipeline } from '../../render/manga.js';
import { fisheyePipeline } from '../../render/fisheye.js';
import { glowPipeline, GLOW_DAY } from '../../render/glow.js';
import { shadePipeline } from '../../render/shade.js';
import { comicPipeline, setComicQuality } from '../../render/comic.js';
import { comicSky } from '../../render/comicsky.js';
import { clumpBlob } from '../../render/clump.js';
import { buildSky } from './vendored/core/sky.js';
import { setOutlineResolution } from './vendored/core/outline.js';
import { buildWorld } from './vendored/world/index.js';
/* The town's cars are drawn by our model (src/art/cars.js); the vendored
 * builders place them and hand the drawing over through these two hooks,
 * ./vendored/PATCH-world-vehicles.diff and PATCH-world-props.diff. Both
 * modules are already in the graph through world/index.js. */
import { makeVehicle, setVehicleModel } from './vendored/world/vehicles.js';
import { makeKeiTruck, setKeiTruckModel } from './vendored/world/props.js';
import { townVehicle, townKeiTruck } from '../../art/cars.js';
/* The road's own centreline, so the title screen's camera flies the street
 * the town was laid out along instead of a circle drawn over the top of it.
 * Already in the import graph through world/index.js, so this costs no
 * module fetch and check 16's module count is unmoved. */
import { centerX, Z_MIN, Z_MAX } from './vendored/world/street.js';
import { Colliders } from '../../game/collide.js';
import { disposeSceneGraph } from '../../render/shell.js';
import { SESSION_TEXTURES } from '../../render/session-textures.js';
import { cityAnimation, findBoomBlocks } from './animation.js';
import {
  bakeCity, loadSimplifier, buildCullGrid, chunkInstanced, fogFloor, thinFoliage, freezeStill,
} from './bake.js';
import { cityReferences, boomColliderExtent } from './references.js';
import { buildPlaces } from './places/index.js';
import { drawnBoxes } from './drawn.js';
import { yieldToPaint } from '../../ui/loading.js';
import { qualityFor } from '../../render/quality.js';
import { makeShadowRate } from '../../render/shadowrate.js';
import { warmPrograms } from '../../render/warm.js';

/*
 * Where a run starts. On the road south of the level crossing, facing north
 * up the street at the crossing and the shop, which is the town's own
 * establishing shot and the densest thing to fly at. Yaw is measured the same
 * way the race field measures it, as a rotation about world up with zero
 * along +z, so facing -z (north up the street) is pi.
 */
const SPAWN = { x: 0, z: 24, yaw: Math.PI };

/*
 * The title screen's flythrough.
 *
 * THE OLD SHOT FLEW THROUGH THE BUILDINGS. It was an 11 m circle round the
 * spawn at 3.2 m, and the spawn is in the middle of a 6.3 m carriageway
 * with shopfronts hard against both footways, so two thirds of every
 * revolution was spent inside somebody's front room. A circle drawn on a
 * street plan does not know there are buildings on it.
 *
 * So the camera flies the ROAD. `centerX(z)` is the same centreline every
 * builder in the town placed itself against, which is what makes this
 * clearance a property of the layout rather than a value somebody tuned by
 * flying it: the carriageway is 6.3 m wide and empty by construction, and
 * anything at street level that is not empty, the crossing, the traffic,
 * the poles, stands off it.
 *
 * Up the street at 3.3 m, over the railway, then out and back over the
 * roofs, which is a lap of the district rather than a lap of one junction
 * and reads as a place rather than as a diorama.
 *
 * THE HOP OVER THE CROSSING IS NOT DECORATION. A train car's roof is at
 * 3.96 m and its pantograph reaches higher, the contact wire is at 4.88 and
 * the messenger at 5.95 (railway.js), so between the road and the wires
 * there is NO height that clears a train. 6.9 m at the crossing is over the
 * messenger with most of a metre to spare, and the district's tallest thing
 * anywhere near the road is a 9.2 m utility pole standing beside it.
 */
const STREET_EYE = 3.3;
const CROSSING_EYE = 6.9;
const CROSSING_SPAN = 15;
/*
 * The return leg's height, and it is set by the TREES.
 *
 * Two forces pull against each other here. Low is better to look at, because
 * the shot aims a fixed drop below a point a fixed distance ahead, so the
 * higher the leg the more of the frame is sky: at 24 m the town was a strip
 * along the bottom edge. But the height query answers with the walkable
 * SURFACE, and a surface is not a canopy. A pass at 14 m read beautifully
 * over the shotengai and put the camera inside a cedar at the school, and a
 * sugi in this town is 10.6 m of trunk before its own scale factor, up to
 * about 12.5 m.
 *
 * So 19 m: over the cedars with six metres to spare, over the 9.2 m utility
 * poles, over the roofs and over the 7.2 m overbridge deck, and low enough
 * that the district still fills the frame.
 */
const ROOF_EYE = 19;
/*
 * WHERE THE CLIMB HAPPENS, and it is the whole of what makes this loop
 * flyable.
 *
 * The first version climbed on the turn, and the turn is the one part of
 * the loop that leaves the road: it sweeps out into the school grounds at
 * the north end, and the school has cedars in it. The height query answers
 * with the walkable SURFACE, so a camera told to stay 8 m over the ground
 * flew straight through a canopy, twice, at two different heights. There is
 * no height between the road and the treetops that is safe out there.
 *
 * So the climb moves onto the LAST STRETCH OF ROAD instead. The carriageway
 * is empty by construction, its poles stand beside it and its wires run
 * along it, so a camera rising over the middle of it passes nothing. By the
 * time the turn begins the shot is already at roof height and the turn is
 * flat. The descent at the other end is the same thing mirrored.
 *
 * HOW LONG THE CLIMB IS, is a question about the FRAME rather than about
 * clearance. The camera looks lookAhead metres down the line, so on a ramp
 * it is pointed down the ramp: 15.7 m of height over 24 m of road is a
 * gradient of 0.65, and 0.65 plus the aim drop is forty degrees of nose
 * down. Forty degrees at roof height is a photograph of tarmac, which is
 * what the return leg's cards looked like and were reported as. Thirty two
 * metres puts it near thirty, and it costs sixteen metres of the low street
 * run, which is the part of this loop worth having. That trade is the
 * reason this number is not larger.
 */
const CLIMB_RUN = 32;
/* The lowest the shot ever gets, over any surface. Only the street legs go
 * anywhere near it, and they are over a road. */
const MIN_CLEAR = 2.6;
/* Where the street leg starts and stops. Inside the carriageway's own ends,
 * because the road stops at a dead end north of the school and simply runs
 * out south of the canal. */
const LEG_SOUTH = Z_MAX - 6;
const LEG_NORTH = Z_MIN + 8;
/*
 * Where the loop is rotated to start.
 *
 * THE FIRST POINT IS THE FIRST FRAME OF THE CARD. The thumbnail recorder
 * rewinds its camera clock to zero before it records, so whatever is at the
 * head of this array is what a player sees when the clip begins, and what
 * the still it replaces has to hand over to. Built in road order the head is
 * LEG_SOUTH, which is the TOP of the climb: nineteen metres up, looking down
 * the ramp at the tarmac. The best frame this town has is the street itself,
 * so the array is rotated to open there, on the flat run a little south of
 * the level crossing, pointed north at it.
 */
const OPEN_Z = 12;
/* Plan offset of the return leg from the outbound one, and the radius of
 * the two turns that join them. The return runs over the blocks east of the
 * road rather than back along the road itself, so the two legs are two
 * different shots rather than the same one at two heights. */
const RETURN_OFFSET = 22;
const TURN_R = RETURN_OFFSET * 0.5;

function smoothstep01(x) {
  const t = Math.max(0, Math.min(1, x));
  return t * t * (3 - 2 * t);
}

function crossingEye(z) {
  const k = Math.max(0, 1 - Math.abs(z) / CROSSING_SPAN);
  return STREET_EYE + (CROSSING_EYE - STREET_EYE) * smoothstep01(k);
}

/*
 * Height above the road at z on the street leg: street height, lifted over
 * the crossing, and lifted again into the climb at each end.
 */
function streetEye(z) {
  const base = crossingEye(z);
  const up = Math.max(
    smoothstep01((LEG_NORTH + CLIMB_RUN - z) / CLIMB_RUN),
    smoothstep01((z - (LEG_SOUTH - CLIMB_RUN)) / CLIMB_RUN),
  );
  return base + (ROOF_EYE - base) * up;
}

function cityAttractPath(world) {
  const ground = (x, z) => {
    const bare = world.heightAt(x, z, -1000);
    return Number.isFinite(bare) ? bare : 0;
  };
  const pts = [];
  const push = (x, z, y) => {
    pts.push({ x, y: Math.max(y, ground(x, z) + MIN_CLEAR), z });
  };

  /* Up the street, south to north: down at road height through the middle,
   * over the railway, and climbing out at each end. */
  const legSteps = Math.round((LEG_SOUTH - LEG_NORTH) / 5);
  for (let i = 0; i <= legSteps; i += 1) {
    const z = LEG_SOUTH + (LEG_NORTH - LEG_SOUTH) * (i / legSteps);
    const x = centerX(z);
    push(x, z, ground(x, z) + streetEye(z));
  }

  /*
   * The two turns, as half circles in plan swept AWAY from the town, flat at
   * roof height. Away rather than back over the district on purpose: a turn
   * that cuts inward crosses the leg it just flew, and a closed spline
   * through a self intersection is a knot.
   */
  const turn = (z0, cx, from, to) => {
    const steps = 9;
    for (let i = 1; i <= steps; i += 1) {
      const a = from + (to - from) * (i / steps);
      const x = cx + Math.cos(a) * TURN_R;
      const z = z0 + Math.sin(a) * TURN_R;
      push(x, z, ground(x, z) + ROOF_EYE);
    }
  };

  const northX = centerX(LEG_NORTH);
  const southX = centerX(LEG_SOUTH);
  turn(LEG_NORTH, northX + TURN_R, Math.PI, Math.PI * 2);

  /* Back over the roofs, north to south. */
  for (let i = 1; i < legSteps; i += 1) {
    const z = LEG_NORTH + (LEG_SOUTH - LEG_NORTH) * (i / legSteps);
    const x = centerX(z) + RETURN_OFFSET;
    push(x, z, ground(x, z) + ROOF_EYE);
  }

  turn(LEG_SOUTH, southX + TURN_R, 0, Math.PI);

  /* Rotate, do not rebuild. The loop is closed, so its start is a free
   * choice and every other point keeps the spacing it was given. */
  let head = 0;
  for (let i = 1; i <= legSteps; i += 1) {
    const z = LEG_SOUTH + (LEG_NORTH - LEG_SOUTH) * (i / legSteps);
    if (Math.abs(z - OPEN_Z) < Math.abs(pts[head].z - OPEN_Z)) {
      head = i;
    }
  }
  return pts.slice(head).concat(pts.slice(0, head));
}

/*
 * Fog and far plane.
 *
 * The town's own values are a fog of 44 to 205 m and a far plane of 600, set
 * for a walker with a 1.7 m eye whose sight lines are down streets. A quad
 * climbs, and from 60 m up the whole district is inside one frustum, so the
 * far plane has to hold the far side of the town and the fog has to not eat
 * it.
 *
 * THE FOG IS WHAT MAKES THE CULL INVISIBLE, so it is set from CULL_RADIUS
 * rather than chosen for itself. Anything switched off at the radius has to
 * already be the fog's colour when it goes, or the cull is a pop instead of a
 * cull, and that means FOG_FAR at or inside the radius rather than past it.
 * It was 135 against a radius of 145, which held; cutting the radius to 100
 * without moving the fog would have left a 35 m band where the town winks out
 * in clear air.
 *
 * HOW SHORT IS SET BY THE FLYING, NOT BY THE FRAME. 65 m of fog at 100 km/h is
 * 2.3 s of sight, which is enough to read a gap and commit to it. The sweep
 * kept paying below that, 1153 draw calls at the worst view for a radius of 50
 * against 1236 for 70, and 45 m of fog is 1.6 s, which is being asked to
 * commit to a line before it exists. 83 draw calls is not worth flying blind,
 * so this stops at the last value a pilot can use rather than at the last one
 * the ledger likes.
 *
 * The far plane stays long. It costs nothing, it is depth precision rather
 * than draw calls, and the sky dome and the hills behind the town live out
 * there.
 *
 * High's live numbers (fog 22 to 65, cull 70, foliage keep 0.65, shadow
 * half 22) live in src/render/quality.js so Medium and Low can scale them
 * without a second copy of the reasoning.
 */
const CAMERA_FAR = 900;

/*
 * Distance past which a district's contents are hidden outright.
 *
 * This is not an optimisation looking for a problem. A walker sees about 23 m
 * of ground; a quad at 80 m sees the entire town, and the town is drawn as
 * thousands of separate small meshes because nothing that draws it ever
 * expected them all to be in one frustum. Frustum culling alone cannot help
 * with a view that genuinely contains everything. So the far half of the town
 * is dropped past this radius, measured from the camera, on a grid of cells
 * whose contents are grouped at build time. Numbers in PROGRESS.md.
 *
 * ROUND 29 CHANGED WHAT THIS LEVER IS WORTH, so the value moved with it. When
 * almost everything cast a shadow, cutting the radius from 100 to 70 bought
 * 174 draw calls at street and the conclusion was that the radius was a weak
 * lever. With the casters restricted it buys 402 at the worst view, 1638 to
 * 1236, because the work it removes is no longer being paid for a second time
 * in a shadow pass that the radius cannot reach.
 *
 * THE CELL STAYS AT 40 AND THAT WAS SWEPT, NOT ASSUMED. Coarser cells make
 * fewer instanced chunks, 1200 at 40 m against 458 at 80 m, and every one of
 * the draw calls that saves is handed back in triangles: at 80 m and a 100 m
 * radius the worst view is 3.43 M triangles against 2.51 M at 40 m, because a
 * cell is only dropped once ALL of it is out of range and an 80 m cell rarely
 * is. 40 m is better on both axes at every radius measured.
 */
const CULL_CELL = 40;

/*
 * How finely the shadow proxies are cut. See buildShadowProxies in ./bake.js
 * for what they are and why they exist.
 *
 * Small enough that the 44 m shadow box holds only a few of them, large enough
 * that the handful inside the box are not a draw call each. A 24 m cell puts
 * between four and nine inside the box depending on where the craft sits,
 * against the 351 calls the shadow pass cost when the town cast for itself.
 */

/*
 * How much of the town's hill decoration survives at bake time.
 *
 * Tree canopies are not in this list. Remaining trees have their
 * collision authored per leaf, so thinning the blobs after that would
 * put a wall where the drawing no longer is. Hill tufts, moss, rocks
 * and lake reeds still thin. High keeps 0.48; Medium and Low keep less.
 * The live value is src/render/quality.js.
 */

/*
 * How coarsely the static merge groups geometry, and why it is NOT CULL_CELL.
 *
 * These were one constant, and making them one was a mistake that hid the
 * town's real cost for two rounds. Sweeping it moved three things at once,
 * the merge, the instanced chunking and the cull grid, so every value looked
 * like a bad trade and the conclusion was that there was nothing to win.
 *
 * Measured separately they want opposite things, because the town's draw
 * calls and the town's triangles live in different objects:
 *
 *   static, merged     7229 meshes    1,338,381 triangles
 *   instanced foliage  1565 meshes    4,540,348 triangles
 *
 * The static half is almost all draw call and almost no triangle. At the
 * street viewpoint 1,229,557 of those 1,338,381 triangles were being drawn
 * anyway, so culling the static half at 40 m was buying 8 percent of its
 * triangles at a cost of thousands of separate objects, in a frame of 5981
 * draw calls. A draw call is what the town is actually short of. So the merge
 * is given the whole town, geometry that shares a material becomes one mesh
 * wherever it stands, and the 8 percent is paid gladly.
 *
 * The instanced half is the mirror image: 4.5 M triangles in objects that are
 * already one draw call each, where a bounding sphere spanning a grove means
 * every tree in it is submitted whether or not one is in frame. That half
 * keeps CULL_CELL, and so does the cull grid.
 *
 * buildCullGrid needs no change to cope: it already routes anything whose
 * bounding sphere exceeds a cell into `always`, so a town wide merge is
 * frustum culled and never distance culled, which is the correct handling and
 * not a special case written for this.
 */
/*
 * ROUND 32 PUT THIS BACK TO Infinity, and the reason is a measurement rather
 * than a preference. Splitting the static merge spatially makes it distance
 * cullable, which costs draw calls and buys triangles, monotonically. Swept
 * twice, before and after the texture atlas, worst of four viewpoints at a
 * 70 m radius:
 *
 *   Infinity   1372 calls   2,426,187 triangles
 *   120        1597 calls   2,367,100
 *   80         1611 calls   2,329,544
 *   60         1807 calls   2,069,086
 *
 * 225 draw calls for 59,000 triangles at 120. Draw calls are the binding
 * budget by a wide margin, 3.5x over against 2.0x, so the trade is negative
 * until that stops being true. It is a real lever and it is pointing the wrong
 * way today.
 */
const MERGE_CELL = Infinity;

/*
 * The same, for geometry that casts a shadow, and it is NOT Infinity.
 *
 * A caster is culled by a second camera: the shadow camera is a SHADOW_HALF
 * box that follows the craft, 44 m a side, and a mesh spanning the town is
 * never outside it. Merged town wide the casters put every static triangle
 * into the shadow pass every frame, which measured at +0.57 M triangles on a
 * change whose whole point was a cheaper frame.
 *
 * Swept at the street viewpoint, as draw calls against triangles:
 *
 *    40   4686 calls   3.20 M
 *    80   4041 calls   3.41 M
 *   120   3986 calls   3.47 M
 *   inf   3476 calls   3.76 M
 *
 * 80 is the knee: 40 to 80 buys 645 calls for 0.21 M triangles, and 80 to 120
 * buys 55 for another 0.06 M, which is the same trade four times worse. It is
 * also about twice the shadow box, which is the relationship that makes it the
 * right shape of number rather than a lucky one.
 */
const MERGE_SHADOW_CELL = 80;

/*
 * How big a thing has to be before it casts a shadow.
 *
 * The reasoning, the sweep and the reason a size test is allowed here when two
 * previous ones were not are all at `restrictCasters` in ./bake.js. The short
 * version: the shadow pass was 35 percent of this map's draw calls and 39
 * percent of its triangles, most of it thousands of objects too small to cast
 * a shadow anyone flying could see, and every one of those also held a
 * MERGE_SHADOW_CELL bucket open in the colour pass.
 *
 * Two numbers rather than one, and the reason is the canopy: a single
 * threshold anywhere above this town's 1.0 m canopy blob turns off every tree
 * shadow in the town, and the 190 draw calls that buys are not worth the
 * cherry trees. A mesh standing on its own has to be 1.4 m to cast. One member
 * of an instanced crowd only has to be 0.8, because what the eye reads there
 * is the cluster and never the blob. Hill tufts and lake reeds are 0.5 and
 * stop casting either way.
 */
const CASTER_MIN_RADIUS = 1.4;
const CASTER_MIN_RADIUS_INSTANCED = 0.8;

/*
 * The city's pipeline, with the two things it does to a shared renderer
 * undone.
 *
 * `Pipeline.setSize` forces `renderer.setPixelRatio(1)` and calls
 * `renderer.setSize(w, h, true)`. Both are correct for a page that owns its
 * renderer and wrong for ours: the pixel ratio is the session's and the race
 * field's render targets are sized against it, and `updateStyle` true writes
 * inline width and height onto a canvas the stylesheet sizes. Calling
 * setSize again with updateStyle false does not clear those styles, so they
 * have to be stripped here. Subclassing rather than patching the vendored
 * file keeps ./vendored/core/post.js byte identical to upstream.
 */
class CityPipeline extends Pipeline {
  constructor(renderer, scene, camera, opts) {
    super(renderer, scene, camera, opts);
    this.minScale = opts && opts.minScale != null ? opts.minScale : 1;
    this.preferScale = opts && opts.preferScale != null ? opts.preferScale : null;
    /* The Render scale slider times Auto graphics' factor (renderScaleOf in
     * main.js), applied to these targets in setSize. main.js writes it on
     * every change and keeps the canvas at the preset's own ratio, since
     * this pipeline scales its own targets: see applyRenderScale there. */
    this.userScale = opts && opts.userScale > 0 ? opts.userScale : 1;
    this.scaleAtFull = 1;
    this.cssArea = 0;
    /* Stage F's manga layer, folded into the grade and the fxaa pass on
     * this pipeline's own materials: see src/render/manga.js. */
    this.manga = mangaPipeline(this);
    /* The pilot's fisheye setting, folded into the grade's one fetch: see
     * src/render/fisheye.js. Off, it reads the coordinate it always read. */
    this.fisheye = fisheyePipeline(this);
    /* The comic layer's pen and grade: see src/render/comic.js. The
     * blobs option is the ink half of markCanopies' comicBlob. */
    comicPipeline(this, { blobs: true });
  }

  setSize(w, h) {
    /* The shell's pixel ratio as it is now, put back after the resize below.
     * It used to be captured once at construction, which put the boot ratio
     * back on every resize and undid any change the shell had made since. */
    const shellPr = this.renderer.getPixelRatio();
    /* Own scale math, not super.setSize. The vendored walker pipeline
     * floors scale at 1.0 so a low-DPI screen supersamples for clean ink.
     * Low on a Deck has to go below 1.0 or the fill rate is the whole
     * frame. High keeps minScale 1 so 1080p matches the measured budget. */
    const dpr = window.devicePixelRatio || 1;
    let scale = this.forceScale
      || this.preferScale
      || (dpr < 1.5 ? 1.5 : Math.min(dpr, 2));
    if (w * h * scale * scale > this.pixelBudget) {
      scale = Math.max(this.minScale, Math.sqrt(this.pixelBudget / (w * h)));
    }
    /*
     * THE RENDER SCALE AND AUTO, which never reached this pipeline: the
     * slider and Auto's factor were written into a property nothing read,
     * and every change of the shell's ratio was undone below (review
     * finding F1, 2026-09-27). The factor now scales the scale above, never
     * under this preset's minScale (Low 0.55, Medium 0.85, High 1.0 of the
     * CSS size), and at 1 it is exactly the scale the budgets were measured
     * at. scaleAtFull is kept for autoFloor.
     */
    this.scaleAtFull = scale;
    this.cssArea = w * h;
    const floor = this.minScale < scale ? this.minScale : scale;
    scale *= this.userScale;
    if (scale < floor) {
      scale = floor;
    }
    this.scale = scale;
    const rw = Math.max(2, Math.floor(w * scale));
    const rh = Math.max(2, Math.floor(h * scale));
    this.size.set(rw, rh);

    this.rtScene.setSize(rw, rh);
    this.rtA.setSize(rw, rh);
    this.rtB.setSize(rw, rh);

    const texel = new THREE.Vector2(1 / rw, 1 / rh);
    this.ink.mat.uniforms.uTexel.value.copy(texel);
    this.fxaa.mat.uniforms.uTexel.value.copy(texel);
    this.ink.mat.uniforms.uNear.value = this.camera.near;
    this.ink.mat.uniforms.uFar.value = this.camera.far;
    /* Times the comic layer's heavier pen (src/render/comic.js). */
    this.ink.mat.uniforms.uThickness.value = (1.05 + 0.55 * scale) * (this.inkWeight || 1);

    this.renderer.setPixelRatio(shellPr);
    this.renderer.setSize(w, h, false);
    this.renderer.domElement.style.width = '';
    this.renderer.domElement.style.height = '';
    setOutlineResolution(this.size.x, this.size.y);
  }

  /* The render scale factor under which Auto may not take these targets,
   * over the scale at full, so Auto counts its time at the floor where the
   * floor really is (autoFloorFor in main.js): minScale, where they stop
   * shrinking, or the preset's pixel floor if that is higher
   * (autoMinPixels in src/render/quality.js, the owner's decision of
   * 2026-09-28), never above the full scale. 1 when that leaves no room. */
  autoFloor(minPixels = 0) {
    const full = this.scaleAtFull > 0 ? this.scaleAtFull : 1;
    let floor = this.minScale;
    if (minPixels > 0 && this.cssArea > 0) {
      const px = Math.sqrt(minPixels / this.cssArea);
      if (px > floor) {
        floor = px;
      }
    }
    return (floor < full ? floor : full) / full;
  }
}

/*
 * The city's contact model.
 *
 * The town's colliders are axis aligned rectangles with a `top` and, rarely, a
 * `bottom`. Read as the walker reads them, `top` is a ceiling: the walker
 * skips any collider whose top is at or below its feet, which is how it steps
 * over a kerb. So a rectangle with a top and no bottom is a solid box from the
 * ground up to `top`, not an infinitely tall wall, and a quad at altitude
 * flies over a signpost exactly as a walker steps over a kerb. The count of
 * colliders with no `top` at all is measured and published in stats().
 *
 * Platforms are the other half of the model and they are what makes a city
 * worth flying: a roof, the supermarket roof car park and the overbridge deck
 * are surfaces you can land on. `heightAt(x, z, fromY)` already returns them,
 * gated on being within a step of where the query is made from, which is
 * exactly the behaviour a quad wants: above a deck you land on it, below it
 * you fly under it. What `heightAt` cannot express is that a deck is also
 * solid from underneath, so every platform raised more than PLATFORM_SOLID_MIN
 * above the bare ground gets a thin slab collider as well. The slab's top sits
 * 2 cm below the deck so that a craft descending onto it meets the landing
 * judgement first and the slab only ever catches something arriving from
 * below.
 *
 * `solid: false` keeps the platform for walking (`heightAt`) and skips the
 * slab. Stair treads are the case: the going is narrower than the craft, so
 * consecutive slabs overlap in plan and the climb line hits the next pan.
 */
const PLATFORM_SOLID_MIN = 0.6;
const PLATFORM_SLAB_THICK = 0.25;
const PLATFORM_SLAB_CLEAR = 0.02;
/* Below any terrain in this town, so a box with no `bottom` reaches the
 * ground. The lake bed is the deepest thing here at about -7 m. */
const BOX_FLOOR = -60;
/* Above anything in this town, for the rare box with no `top` at all. */
const BOX_CEIL = 400;

/*
 * Trimming the town's keep-out volumes down to the things they stand for.
 *
 * THE TOWN'S RECTANGLES ARE NOT THE TOWN'S SURFACES. They were authored for a
 * walker, and a walker's collider is a keep-out volume with the walker's own
 * body allowed for: `plotCollide` pads every building plot by 0.1 m a side,
 * `district.js` pads one frontage by 1.0 m and one flank by 1.8 m, a 1.3 by
 * 0.7 m shed gets a 1.4 by 1.4 m box, and a tree trunk gets 1.15 times its
 * own radius. None of that is visible to a person on foot, who cannot put
 * their shoulder in the 10 cm anyway. All of it is visible to a quad, which
 * is flown at the gaps on purpose and reads a barrier standing off the wall
 * it belongs to as an invisible wall. The owner's report was exactly that:
 * "the collisions need to HUG the graphics, i want to hit gaps but in many
 * places they are actually invisible walls".
 *
 * AND THE RECTANGLE IS THE WRONG SHAPE, NOT ONLY THE WRONG SIZE. A walker
 * cannot go under a torii's lintel, through the gap between two sheds or
 * beneath a verandah, so the town draws one rectangle around each of those
 * and is right to. A quad can do all three, and does it on purpose. So the
 * fit below does not only shrink a rectangle, it CUTS it wherever the drawing
 * inside it leaves a hole big enough to fly.
 *
 * The algorithm is the slab fit, and it is documented where it is written,
 * further down this file. What is here is the vocabulary it works in.
 *
 * It runs before src/maps/city/bake.js for the same reason references.js
 * does: after the merge a wall is anonymous floats in a shared buffer.
 */
/* Footprint above which a mesh is a SURFACE, not an object: the terrain, the
 * road, the canal, the lake. Nothing that large is what a 7 m plot rectangle
 * stands for, and letting one vote would hold every collider it underlies at
 * full size. The largest thing in this town that a collider does stand for is
 * the school block at about 40 by 25 m. */
const FIT_MAX_FOOTPRINT = 1400;
/* Broadphase for the fit itself. Build time only, so a plain Map of arrays is
 * the right shape here where the per frame path would not tolerate it. */
const FIT_CELL = 4;

/*
 * Bounds on the pass that gives a collider to drawn objects that had none.
 * Every one of them is there to keep the pass away from something whose
 * bounding box is not a fair contact volume, and the numbers come from the
 * survey of the town rather than from taste: the widest thing the pass should
 * catch is a bus shelter or a vending bank at about 4 m, the tallest lamp
 * post measured 8.4 m, and the shortest thing worth being solid is a bollard.
 */
const COVER_MIN_HEIGHT = 0.4;
const COVER_MIN_THICK = 0.03;
const COVER_MAX_FOOTPRINT = 12;
const COVER_MAX_SPAN = 6;
/* How far an object's underside may sit above the surface under it and still
 * be treated as standing on the ground. A canopy sits 20 m up; an awning or a
 * sign on a post sits under a metre. */
const COVER_MAX_LIFT = 1.0;
/*
 * How much of its own bounding box an object has to actually fill before a
 * single box is a fair contact volume for it.
 *
 * Without this the pass makes every SEE THROUGH object solid, and a town like
 * this is full of them: a torii is two posts and a lintel inside a 3 by 3 m
 * box that is 90 percent air, and turning that into a block is the exact
 * complaint being fixed here, pointing the other way. Estimated as the sum of
 * the object's own mesh boxes over its union box, which over counts where
 * meshes overlap and therefore only ever errs toward calling something solid
 * that is; a frame or an archway still lands far below the threshold. An
 * object that fails is left exactly as it was, with no collider, because the
 * status quo is better than a wall across a gap the pilot can see through.
 */
const COVER_MIN_FILL = 0.4;
/* Foliage, ground decoration, and see-through frames, excluded by
 * name. Tree leaves are collided as one box per blob in trees.js.
 * A torii, a 渡り廊下, a walk-up gallery, a 狭小住宅 bay, the overbridge cage and a bell housing bake
 * posts and beams into one mesh whose AABB is a wall across the
 * opening; COVER_MIN_FILL cannot save them because that AABB is
 * the fill. The slab fit skips the same names, because a named
 * frame sitting on a building is still inside that building's
 * rectangle and roof-lift would fill the opening from the floor
 * to the cap. A chain-link ring around a roof votes on every slab
 * of that block the same way. Authored posts and beams stay. */
/* `Trim` is the suffix every non solid mesh in ./places/ carries: paint,
 * glazing, cladding ribs, sign boards, weed patches. It is one word rather
 * than a list because those two places author it, and a solid mesh there is
 * forbidden from taking the name. See ./places/kit.js. */
const COVER_SOFT = /canopy|tuft|moss|reed|petal|lily|ripple|windLane|chalk|doormat|paper|crow|cat|ivy|grass|blossom|leaf|flower|strippedClutter|torii|schoolLink|overbridgeCage|schoolBell|openFrame|temizuya|haiden|chainLink|walkup|garageHouse|Trim/;
/*
 * AND GEOMETRY THAT IS NOT WHERE IT IS DRAWN, WHICH IS A DIFFERENT THING.
 *
 * The fit hugs a rectangle onto the drawing standing in it, and that is only
 * meaningful for drawing that stays there. The train does not: it is built
 * parked in the station and then circles the planet, with its own moving
 * colliders that follow it. The fit read its parked geometry anyway, and the
 * station platform's rectangle -- authored to the 0.98 m deck, bulky, and so
 * allowed to reach for a roof -- found a train roof at 3.74 m and became a
 * solid block 22 by 3.9 m from the deck to above head height. 94 m3 of it,
 * standing under the canopy and along the whole platform, in the one place on
 * the map a pilot has an obvious line: through the station.
 *
 * Separate from COVER_SOFT because the reason is separate. A torii is skipped
 * for being see-through where it stands; the train is skipped for not
 * standing anywhere.
 */
const FIT_MOVING = /^train$/;

/*
 * One object's world extent, skipping foliage, or null if it draws nothing.
 * `child` is a direct child of the town root, which is the granularity the
 * town adds things at: one prop, one house, one pole per ctx.add.
 */
const extentBox = new THREE.Box3();
const extentInst = new THREE.Matrix4();
const extentWorld = new THREE.Matrix4();
function objectExtent(child) {
  let x0 = Infinity; let y0 = Infinity; let z0 = Infinity;
  let x1 = -Infinity; let y1 = -Infinity; let z1 = -Infinity;
  let vol = 0;
  let any = false;
  child.traverse((o) => {
    if (!o.isMesh || !o.geometry) {
      return;
    }
    for (let p = o; p && p !== child.parent; p = p.parent) {
      if (COVER_SOFT.test(p.name || '')) {
        return;
      }
    }
    const g = o.geometry;
    if (!g.boundingBox) {
      g.computeBoundingBox();
    }
    if (!g.boundingBox) {
      return;
    }
    const take = (m) => {
      extentBox.copy(g.boundingBox).applyMatrix4(m);
      if (extentBox.min.x < x0) { x0 = extentBox.min.x; }
      if (extentBox.min.y < y0) { y0 = extentBox.min.y; }
      if (extentBox.min.z < z0) { z0 = extentBox.min.z; }
      if (extentBox.max.x > x1) { x1 = extentBox.max.x; }
      if (extentBox.max.y > y1) { y1 = extentBox.max.y; }
      if (extentBox.max.z > z1) { z1 = extentBox.max.z; }
      vol += (extentBox.max.x - extentBox.min.x)
        * (extentBox.max.y - extentBox.min.y)
        * (extentBox.max.z - extentBox.min.z);
      any = true;
    };
    if (o.isInstancedMesh) {
      for (let i = 0; i < o.count; i += 1) {
        o.getMatrixAt(i, extentInst);
        extentWorld.multiplyMatrices(o.matrixWorld, extentInst);
        take(extentWorld);
      }
      return;
    }
    take(o.matrixWorld);
  });
  return any ? { x0, y0, z0, x1, y1, z1, vol } : null;
}

/* Is any authored rectangle already solid at this point? Linear over the
 * town's 2731 rectangles, run once per root child at build time. */
function coveredAlready(list, x, z, y) {
  for (let i = 0; i < list.length; i += 1) {
    const c = list[i];
    if (x < c.x0 || x > c.x1 || z < c.z0 || z > c.z1) {
      continue;
    }
    const top = c.top === undefined ? BOX_CEIL : c.top;
    const bottom = c.bottom === undefined ? BOX_FLOOR : c.bottom;
    if (y >= bottom && y <= top) {
      return true;
    }
  }
  return false;
}

/*
 * HAS THE AUTHOR ALREADY COLLIDED THIS OBJECT, SOMEWHERE OTHER THAN ITS MIDDLE?
 *
 * coveredAlready asks about the centre of the object's box, which is the
 * right question for a thing that is solid where it is drawn and the wrong
 * one for a thing whose box is mostly arm. A utility pole is a 0.4 m post
 * with crossarms 2.1 m long and, on the lamp poles, a 1.3 m arm and shade out
 * over the road, and the town collides the post and nothing else, by hand,
 * beside every makePole (`ctx.collide`, 0.44 m square, to the pole's top).
 * The centre of the box is out under the lamp arm, so it read as uncovered.
 *
 * Then COVER_MIN_FILL could not see the air either, because the pole is
 * baked into one mesh per material: the crossarms and the cable bundle that
 * runs down the pole are one 'dark' mesh whose own box is the crossarm's
 * width by the pole's height, and the sum of mesh boxes it measures came out
 * as full. So the pass stood a solid block over the whole thing, 1.9 by 2.1 m
 * from the footway to 9.85 m, built by the slab cut out of the arms at the
 * top and filled to the ground under them.
 *
 *   bug-32feeb4a  "Bumped into this invisible wall next to the power pole
 *                 near the gum vending machines on the corner": the lamp
 *                 pole at (-2.6, -60.5) in approach.js, read off the page
 *                 with __colliderBoxes.
 *
 * So a TALL object with an authored rectangle standing wholly inside its own
 * footprint, as high as its middle, is a post the author has already decided
 * the collision of, and it is left to that. Wholly inside, so a wall or a
 * kerb running past a bench is not mistaken for the bench's own. Tall,
 * because measured on the town it is the nine poles whose box centre is
 * out under an arm and nothing else, where the rule alone also took four
 * tunnel walkways (0.5 m slabs with a kerb collider along one edge) and a
 * low cart, all of which are solid where they are drawn and keep their box.
 */
const AUTHORED_POST_MIN_HEIGHT = 3;
function authoredInside(list, b) {
  const midY = (b.y0 + b.y1) * 0.5;
  for (let i = 0; i < list.length; i += 1) {
    const c = list[i];
    if (c.x0 < b.x0 || c.x1 > b.x1 || c.z0 < b.z0 || c.z1 > b.z1) {
      continue;
    }
    const top = c.top === undefined ? BOX_CEIL : c.top;
    const bottom = c.bottom === undefined ? BOX_FLOOR : c.bottom;
    if (bottom <= midY && top >= midY) {
      return true;
    }
  }
  return false;
}

/* The town's drawn geometry now comes from ./drawn.js, which subdivides a
 * sloped mesh into a staircase rather than handing the fit one box for it. */

/*
 * THE SLAB FIT, which is what actually makes the solid world hug the drawn
 * one, and what replaced the ownership vote above.
 *
 * WHAT THE OWNERSHIP VOTE COULD NOT DO, MEASURED. Scanned by ./scan.js
 * against the town as it stood, 3261 of the 5885 authored rectangles had NO
 * geometry that passed the two thirds ownership test, so the fit could say
 * nothing about them and they kept every centimetre of their authored
 * standoff. Another 2190 had owned geometry and were still declined by the
 * coverage rule. The result was 55,083 m3 of solid volume with nothing drawn
 * under it, 1940 boxes reaching over a metre past the drawing, 468 over five
 * metres, and 935 standing on air outright. That is the invisible wall, and
 * it is most of the town.
 *
 * THE IDEA. A rectangle is cut into SLABS across its long axis, each slab a
 * strip spanning the whole of its short axis, and every drawn mesh that
 * touches a slab writes its own extent into it. A slab then knows four
 * things about the drawing standing in it: how high it reaches, how low it
 * starts, and how far across the strip it spreads. Runs of adjacent slabs
 * become one box each, and a box is the UNION of the mesh boxes assigned to
 * it, clipped to the rectangle the town authored.
 *
 * WHY THIS CANNOT OPEN A HOLE, WHICH THE OWNERSHIP VERSION COULD. Every
 * drawn mesh inside the rectangle is assigned to some slab, and every
 * occupied slab is inside some run, and every run box contains the union of
 * its slabs' mesh boxes. So the solid volume always contains the drawn
 * geometry: it is a hull, not a sample. The 78.9 m lineside railing that an
 * earlier version collapsed to a single 0.18 m post cannot collapse here,
 * because each baluster's own box is inside the run that covers it. That is
 * why the coverage rule and the two metre cap are both gone: they existed to
 * guard a fit that could lose geometry, and this one cannot.
 *
 * WHY A SLAB IS A STRIP AND NOT A COLUMN. A strip crosses the whole
 * rectangle, so it meets both of a building's side walls whatever is or is
 * not drawn between them. A column in the middle of a house would see only
 * the roof, whose underside is the eaves, and lifting the box to the eaves
 * would hollow the building out. The strip makes enclosure along the short
 * axis free, and the short axis is split by a second pass over each run, at
 * which point the run is small enough that the same argument holds again.
 *
 * WHAT IS DELIBERATELY LEFT ALONE. A rectangle with nothing drawn in it at
 * all keeps its authored box exactly. It is usually load bearing: the lake
 * edge, the map boundary, a parked level crossing boom.
 */
/* A slab count per rectangle, and the step that follows from it. The step
 * has to resolve GAP_MIN or a gap a quad fits through is invisible to the
 * cut, and it must not be so fine that a 300 m lakeside barrier costs a
 * thousand slabs. */
const SLAB_MAX = 160;
const SLAB_MIN_STEP = 0.12;
const SLAB_MAX_STEP = 0.5;
/*
 * The gap a pilot can actually use.
 *
 * The craft is 0.347 m on its diagonal, 0.282 m square-on, and about 0.08 m
 * thick in level flight. A knife-edge line uses the thin axis, so a visual
 * gap of a quarter metre has to stay a gap in the solid world. Fence
 * balusters at 0.15 m stay merged. A torii still splits.
 */
const GAP_MIN = 0.22;
/* How far above the ground the drawing has to reach before a slab counts as
 * occupied. A road patch, a manhole cover and a painted line are all drawn
 * and none of them is a wall. */
const SLAB_MIN_SOLID = 0.1;
/* A change in the profile this large starts a new run. Same number as the
 * gap, because the question is the same one: is what changed something a
 * quad could fly through. */
const SLAB_STEP_TOL = 0.15;
/* Boxes per authored rectangle, per cut. The cut is greedy and merges the
 * cheapest pair until it is under this, so a busy rectangle loses its least
 * useful gap first rather than its most useful one. */
const MAX_RUNS = 64;
/* And per rectangle over both cuts, so a rectangle full of detail cannot
 * turn into a hundred boxes. */
const MAX_PIECES = 160;
/*
 * Solid volume a split has to save before it is worth a second box.
 *
 * This is the whole box budget, expressed as a price rather than as a count.
 * A count cannot tell a shed from a hipped roof: eight boxes are far too many
 * for the first and nowhere near enough for the second. So a rectangle keeps
 * cutting for as long as each further cut removes at least this much solid
 * volume that has nothing drawn under it, and MAX_RUNS is only the backstop
 * that stops a pathological rectangle running away. A metre and a half is
 * about the volume of the craft's own flight envelope through a gap, which is
 * the smallest amount of invisible wall worth a second entry in the
 * broadphase.
 */
const MERGE_TRIVIAL = 0.25;
/*
 * A box this small in BOTH plan axes is a post, a bollard or a trunk.
 * Leaf clusters skipFit themselves. A 1.4 m slide used to sit under a
 * 2.4 m cap and never got cut, which is how a playground frame became a
 * van. Only a square this tight stays as authored.
 */
const FIT_TIGHT = 0.55;
/*
 * The fit only ever shrinks, which leaves one thing undone: a house collider
 * authored to the wall plate never reached the ridge, and the roof above it
 * was drawn and not solid. So a run whose footprint is bulky enough to be a
 * building, and over which the drawing reaches a little above the authored
 * top, is raised to it. A little, because a metre or two is a gable and five
 * is a tree overhanging the plot.
 */
const ROOF_LIFT_MIN_FOOT = 1.0;
const ROOF_LIFT_MAX = 2.8;
/*
 * And the lift only reaches what is CONTINUOUS with the rectangle's own top,
 * not the first thing it finds above it.
 *
 * A gable's roof slab starts at the wall plate the rectangle was authored to,
 * which is why raising the rectangle finds it. A station canopy starts 2.5 m
 * over the platform on four posts, and the platform's rectangle, raised by
 * 2.8 m, found that too: the run's top became the canopy roof and 94 m3 of the
 * air a pilot flies under it became solid, along the whole platform, in the
 * one place on the map with an obvious line through it. Same shape of mistake
 * for a verandah over a forecourt or a bus shelter over a pad.
 *
 * A gap test is not enough, and the station is why: a 0.08 m handrail runs the
 * whole back edge of the platform from the deck to 2.18 m, so SOMETHING does
 * start at the authored top, and the lift would follow that and then jump to
 * the canopy anyway. So the lift band is sliced and a slab keeps only the
 * CONTIGUOUS run of occupied slices starting at its own top: the handrail
 * lifts the slab to 2.18, the canopy does not lift it at all, and the second
 * cut then puts the handrail back where it is in z.
 *
 * 32 slices over ROOF_LIFT_MAX is 87 mm, so a gap under that is not a gap.
 */
const ROOF_LIFT_SLICES = 32;
/* Before a run's floor is lifted off the ground, the space underneath has to
 * be worth flying through. */
const RAISE_MIN_CLEAR = 0.16;
/*
 * THE GRID CUT, which is for the one shape two passes of strips cannot hug.
 *
 * A slab is a STRIP across the whole rectangle and it takes the MAXIMUM over
 * its own width. That is exactly right for a gable, whose height varies along
 * one axis only: cut across the ridge and every strip steps. It is wrong for
 * anything that varies along BOTH. A hip roof's first cut sees the ridge from
 * every x and its second sees the hip end from every z, so neither finds a
 * step to break a run on and what comes back is one box at the ridge over a
 * roof that falls away from it in four directions. A flat roof with a parapet
 * round it is the same: the parapet is in every strip both ways.
 *
 * Measured by src/maps/city/cavity.js before this existed, that shape is most
 * of the invisible wall left in the town: ひばり湖's cafe 166 m3, the onsen's
 * 房 116, the school's teaching block 46 and its second block 28, and most of
 * a long tail of houses.
 *
 * So the rectangle is also rasterised into a GRID, each cell holding what the
 * drawing does over that cell alone, and the grid is decomposed into boxes by
 * growing each one along z and then along x while the run stays inside
 * SLAB_STEP_TOL -- the same tolerance and the same "against the run, not
 * against the neighbour" rule the strip cut uses, in two dimensions. The
 * cheaper of the two answers wins, so nothing the strips already did well
 * changes.
 *
 * ONLY FOR A RECTANGLE BULKY IN BOTH AXES. A 78 m lineside barrier is a
 * strip by nature and a grid over it is a thousand cells to say what one cut
 * says. GRID_MIN_FOOT is the same number ROOF_LIFT_MIN_FOOT uses for the same
 * reason: below it, this is not a building.
 */
const GRID_MIN_FOOT = 1.0;
const GRID_MAX_SIDE = 64;
const GRID_MAX_CELLS = 4096;
/*
 * The floor is sampled on its own coarse lattice, not per cell. It is the
 * bare ground, it varies over metres, and `floorAt`'s memo is a Map keyed by
 * a built string: four thousand cells per rectangle over nine hundred
 * rectangles is three and a half million lookups to answer a question that
 * has a hundred different answers.
 */
const GRID_FLOOR_LATTICE = 12;
/* And the grid has to WIN by this much, so a rectangle does not swap a
 * six box answer for a forty box one to save a cupful of air. */
const GRID_GAIN = 0.5;

function clampStep(v, lo, hi) {
  if (v < lo) {
    return lo;
  }
  if (v > hi) {
    return hi;
  }
  return v;
}

/*
 * Every drawn mesh box overlapping one rectangle, gathered once.
 *
 * `list` is filled with indices into `boxes` and its length returned. The
 * stamp array is the same duplicate rejection the ownership version used: a
 * mesh in four grid cells must be counted once.
 */
function gatherBoxes(c, boxes, grid, seen, mark, list) {
  let n = 0;
  const ca0 = Math.floor(c.x0 / FIT_CELL);
  const ca1 = Math.floor(c.x1 / FIT_CELL);
  const cb0 = Math.floor(c.z0 / FIT_CELL);
  const cb1 = Math.floor(c.z1 / FIT_CELL);
  for (let a = ca0; a <= ca1; a += 1) {
    for (let b = cb0; b <= cb1; b += 1) {
      const bucket = grid.get(`${a},${b}`);
      if (bucket === undefined) {
        continue;
      }
      for (let bi = 0; bi < bucket.length; bi += 1) {
        const i = bucket[bi];
        if (seen[i] === mark) {
          continue;
        }
        seen[i] = mark;
        list[n] = i;
        n += 1;
        if (n >= list.length) {
          return n;
        }
      }
    }
  }
  return n;
}

/*
 * Cut one rectangle along one axis into boxes that hug what is drawn in it.
 *
 * `rect` is {x0, y0, z0, x1, y1, z1} in world space and is never grown: every
 * box returned is inside it. `alongX` picks the axis to cut. `floorAt` is the
 * bare ground, which is what "reaches above the ground" is measured from and
 * what a lifted floor is measured against.
 *
 * Returns an array of boxes, or null when nothing is drawn in the rectangle,
 * which the caller reads as "leave this one exactly as the town authored it".
 */
function cutAxis(rect, alongX, boxes, list, count, floorAt, scratch) {
  const L0 = alongX ? rect.x0 : rect.z0;
  const L1 = alongX ? rect.x1 : rect.z1;
  const S0 = alongX ? rect.z0 : rect.x0;
  const S1 = alongX ? rect.z1 : rect.x1;
  const span = L1 - L0;
  if (!(span > 0) || !(S1 > S0)) {
    return null;
  }
  let n = Math.ceil(span / clampStep(span / SLAB_MAX, SLAB_MIN_STEP, SLAB_MAX_STEP));
  if (n < 1) {
    n = 1;
  }
  if (n > SLAB_MAX) {
    n = SLAB_MAX;
  }
  const step = span / n;
  const {
    hi, lo, s0, s1, l0, l1, lift,
  } = scratch;
  const yTop = rect.yTop === undefined ? Infinity : rect.yTop;
  const liftBand = Number.isFinite(yTop) ? rect.y1 - yTop : 0;
  const sliceH = liftBand > 0 ? liftBand / ROOF_LIFT_SLICES : 0;
  for (let k = 0; k < n; k += 1) {
    hi[k] = -Infinity;
    lo[k] = Infinity;
    s0[k] = Infinity;
    s1[k] = -Infinity;
    l0[k] = Infinity;
    l1[k] = -Infinity;
    lift[k] = 0;
  }
  let any = false;
  for (let idx = 0; idx < count; idx += 1) {
    const g = boxes[list[idx]];
    /* Only what is inside the rectangle, in all three axes. A neighbour's
     * wall clipping the corner is deliberately allowed to vote: the box that
     * results still hugs something the pilot can see, which is the whole
     * point, and the ownership rule that used to exclude it is what left
     * three thousand rectangles unfitted. */
    if (g.y1 < rect.y0 || g.y0 > rect.y1) {
      continue;
    }
    const gl0 = Math.max(alongX ? g.x0 : g.z0, L0);
    const gl1 = Math.min(alongX ? g.x1 : g.z1, L1);
    const gs0 = Math.max(alongX ? g.z0 : g.x0, S0);
    const gs1 = Math.min(alongX ? g.z1 : g.x1, S1);
    if (gl1 <= gl0 || gs1 <= gs0) {
      continue;
    }
    let a = Math.floor((gl0 - L0) / step);
    let b = Math.ceil((gl1 - L0) / step) - 1;
    if (a < 0) {
      a = 0;
    }
    if (b > n - 1) {
      b = n - 1;
    }
    if (b < a) {
      b = a;
    }
    const gy1 = Math.min(g.y1, rect.y1);
    const gy0 = Math.max(g.y0, rect.y0);
    for (let k = a; k <= b; k += 1) {
      if (gy1 > hi[k]) {
        hi[k] = gy1;
      }
      /* Which slices of the lift band this box occupies, so the lift can
       * follow what is continuous with the rectangle's top and stop at a
       * gap. See ROOF_LIFT_SLICES. */
      if (sliceH > 0 && gy1 > yTop) {
        let q0 = Math.floor((Math.max(gy0, yTop) - yTop) / sliceH);
        let q1 = Math.ceil((gy1 - yTop) / sliceH) - 1;
        if (q0 < 0) { q0 = 0; }
        if (q1 > ROOF_LIFT_SLICES - 1) { q1 = ROOF_LIFT_SLICES - 1; }
        for (let q = q0; q <= q1; q += 1) {
          lift[k] |= (1 << q);
        }
      }
      if (gy0 < lo[k]) {
        lo[k] = gy0;
      }
      if (gs0 < s0[k]) {
        s0[k] = gs0;
      }
      if (gs1 > s1[k]) {
        s1[k] = gs1;
      }
      /*
       * CLIPPED TO THE SLAB, not to the rectangle, and this line is the
       * difference between a cut and a mess. A 20 m mesh writes into every
       * slab it crosses; if each of those slabs recorded the mesh's whole
       * extent then two runs at opposite ends of it would both claim the
       * middle, the boxes would overlap along their whole length, and the
       * town's solid volume would double. Clipping makes the runs disjoint,
       * so a cut removes volume rather than adding it.
       */
      const sl0 = L0 + k * step;
      const sl1 = sl0 + step;
      const cl0 = gl0 > sl0 ? gl0 : sl0;
      const cl1 = gl1 < sl1 ? gl1 : sl1;
      if (cl0 < l0[k]) {
        l0[k] = cl0;
      }
      if (cl1 > l1[k]) {
        l1[k] = cl1;
      }
    }
    any = true;
  }
  if (!any) {
    return null;
  }

  /*
   * The roof lift, taken back wherever what is up there is not on the roof.
   *
   * See ROOF_LIFT_SLICES: the rectangle was allowed to reach ROOF_LIFT_MAX over
   * its authored top so a gable sitting on the wall plate would be found. A
   * slab whose only geometry up there STARTS clear of the authored top has a
   * canopy over it, not a roof on it, and keeping that height is the bus
   * shelter complaint at building scale.
   */
  if (sliceH > 0) {
    for (let k = 0; k < n; k += 1) {
      if (!(hi[k] > yTop)) {
        continue;
      }
      let run = 0;
      while (run < ROOF_LIFT_SLICES && (lift[k] & (1 << run)) !== 0) {
        run += 1;
      }
      const cap = yTop + run * sliceH;
      if (hi[k] > cap) {
        hi[k] = cap;
      }
      if (lo[k] > hi[k]) {
        lo[k] = hi[k];
      }
    }
  }

  /* Occupancy, measured against the ground rather than against the box's own
   * bottom, because a box with no authored bottom starts 60 m down. */
  const sMid = (S0 + S1) * 0.5;
  let occupied = 0;
  for (let k = 0; k < n; k += 1) {
    const lMid = L0 + (k + 0.5) * step;
    const ground = alongX ? floorAt(lMid, sMid) : floorAt(sMid, lMid);
    const base = Math.max(rect.y0, ground);
    scratch.floor[k] = base;
    scratch.occ[k] = hi[k] !== -Infinity && hi[k] > base + SLAB_MIN_SOLID ? 1 : 0;
    occupied += scratch.occ[k];
  }
  if (occupied === 0) {
    return null;
  }

  /*
   * Segments: a break wherever the strip stops being drawn, starts being
   * drawn, or steps away from what the run has been so far.
   *
   * AGAINST THE RUN, NOT AGAINST THE PREVIOUS SLAB, and the difference is a
   * roof. Comparing neighbours only breaks on a STEP, and a slope is not a
   * step: at a slab every 0.12 m a 30 degree pitch changes height by 0.07 m
   * between neighbours and never trips any threshold worth having, so the
   * whole roof came out as one run at the height of its ridge. Measured, the
   * worst boxes left in the town after the cut first landed were all houses,
   * seven to ten metres square with the drawing reaching the top of the box
   * over five percent of its footprint and six metres of nothing above the
   * rest. Compared against the run's own accumulated extent, the same slope
   * breaks every time it has fallen SLAB_STEP_TOL below the run, which is a
   * staircase down the pitch with treads that size.
   */
  const segs = [];
  let cur = null;
  for (let k = 0; k < n; k += 1) {
    if (!scratch.occ[k]) {
      cur = null;
      continue;
    }
    if (cur !== null
      && Math.abs(Math.max(cur.hi, hi[k]) - Math.min(cur.hi, hi[k])) <= SLAB_STEP_TOL
      && Math.abs(Math.max(cur.lo, lo[k]) - Math.min(cur.lo, lo[k])) <= SLAB_STEP_TOL) {
      cur.hi = Math.max(cur.hi, hi[k]);
      cur.lo = Math.min(cur.lo, lo[k]);
      cur.s0 = Math.min(cur.s0, s0[k]);
      cur.s1 = Math.max(cur.s1, s1[k]);
      cur.l0 = Math.min(cur.l0, l0[k]);
      cur.l1 = Math.max(cur.l1, l1[k]);
      cur.floor = Math.min(cur.floor, scratch.floor[k]);
      continue;
    }
    cur = {
      hi: hi[k],
      lo: lo[k],
      s0: s0[k],
      s1: s1[k],
      l0: l0[k],
      l1: l1[k],
      floor: scratch.floor[k],
    };
    segs.push(cur);
  }
  if (segs.length === 0) {
    return null;
  }

  /*
   * Merge back everything that is not a gap a quad could fly.
   *
   * Two runs stay apart only if what is between them is at least GAP_MIN
   * across, or one of them starts at least GAP_MIN higher off the ground
   * than the other. A fence's balusters fail the first, a kerb's dropped
   * crossing fails the second, and a torii passes. Everything else is
   * merged cheapest pair first until the rectangle is inside its box budget.
   */
  const vol = (a) => (a.l1 - a.l0) * (a.s1 - a.s0) * (a.hi - a.lo);
  const cost = (a, b) => {
    const ul0 = Math.min(a.l0, b.l0);
    const ul1 = Math.max(a.l1, b.l1);
    const us0 = Math.min(a.s0, b.s0);
    const us1 = Math.max(a.s1, b.s1);
    const uy0 = Math.min(a.lo, b.lo);
    const uy1 = Math.max(a.hi, b.hi);
    return (ul1 - ul0) * (us1 - us0) * (uy1 - uy0) - vol(a) - vol(b);
  };
  const flyable = (a, b) => {
    /* Side by side with room between them: fly through. */
    if (b.l0 - a.l1 >= GAP_MIN) {
      return true;
    }
    /* A step down in the top: fly over the lower one. Merging these was the
     * first version's worst mistake, because the merge takes the taller top
     * and a 36 m lineside barrier inherited the height of the one pylon
     * standing at the end of it. */
    if (Math.abs(a.hi - b.hi) >= GAP_MIN) {
      return true;
    }
    /* A step up in the underside: fly under the higher one. Under-roof
     * clearances use the same 0.16 m the raise pass already keeps. */
    return Math.abs(a.lo - b.lo) >= RAISE_MIN_CLEAR;
  };
  const merge = (a, b) => ({
    hi: Math.max(a.hi, b.hi),
    lo: Math.min(a.lo, b.lo),
    s0: Math.min(a.s0, b.s0),
    s1: Math.max(a.s1, b.s1),
    l0: Math.min(a.l0, b.l0),
    l1: Math.max(a.l1, b.l1),
    floor: Math.min(a.floor, b.floor),
  });
  /*
   * Two tiers. Normally a pair is merged when it is cheap and not a gap a
   * pilot could use; a gap is never merged for being cheap. Over MAX_RUNS
   * the cheapest NON-flyable pair still goes, so a fence of slivers can
   * collapse. A flyable gap is never the pair that is spent, even over
   * budget: extra boxes beat a wall across a knife-edge line.
   */
  for (;;) {
    let at = -1;
    let best = Infinity;
    for (let i = 0; i + 1 < segs.length; i += 1) {
      if (flyable(segs[i], segs[i + 1])) {
        continue;
      }
      const cc = cost(segs[i], segs[i + 1]);
      if (cc < best) {
        best = cc;
        at = i;
      }
    }
    if (at >= 0 && best < MERGE_TRIVIAL) {
      segs.splice(at, 2, merge(segs[at], segs[at + 1]));
      continue;
    }
    if (segs.length > MAX_RUNS && at >= 0) {
      segs.splice(at, 2, merge(segs[at], segs[at + 1]));
      continue;
    }
    break;
  }

  const out = [];
  for (const g of segs) {
    /*
     * The floor. A run whose lowest drawn point is well clear of the ground
     * is lifted onto it, which is what turns a torii into two posts and a
     * lintel and a verandah into a roof a quad can fly under. Anything less
     * than RAISE_MIN_CLEAR stays on the rectangle's own bottom, so a wall
     * standing on a 5 cm plinth does not float.
     */
    const lift = g.lo - g.floor >= RAISE_MIN_CLEAR;
    const y0 = lift ? g.lo : rect.y0;
    const y1 = Math.max(y0 + 0.001, Math.min(g.hi, rect.y1));
    out.push(alongX
      ? {
        x0: Math.max(g.l0, rect.x0),
        y0,
        z0: Math.max(g.s0, rect.z0),
        x1: Math.min(g.l1, rect.x1),
        y1,
        z1: Math.min(g.s1, rect.z1),
      }
      : {
        x0: Math.max(g.s0, rect.x0),
        y0,
        z0: Math.max(g.l0, rect.z0),
        x1: Math.min(g.s1, rect.x1),
        y1,
        z1: Math.min(g.l1, rect.z1),
      });
  }
  return out;
}

/*
 * One rectangle cut on a GRID, for the shapes strips cannot hug. See
 * GRID_MIN_FOOT above for why this exists and when it runs.
 *
 * Returns an array of boxes inside the rectangle, or null when the grid has
 * nothing to say: too thin to be a building, nothing drawn in it, or more
 * pieces than the budget allows even after coarsening.
 */
function cutGrid(rect, boxes, list, count, floorAt, scratch) {
  const spanX = rect.x1 - rect.x0;
  const spanZ = rect.z1 - rect.z0;
  if (!(spanX > 0) || !(spanZ > 0)) {
    return null;
  }
  if (Math.min(spanX, spanZ) < GRID_MIN_FOOT) {
    return null;
  }
  let nx = Math.max(1, Math.ceil(spanX / clampStep(spanX / GRID_MAX_SIDE, SLAB_MIN_STEP, SLAB_MAX_STEP)));
  let nz = Math.max(1, Math.ceil(spanZ / clampStep(spanZ / GRID_MAX_SIDE, SLAB_MIN_STEP, SLAB_MAX_STEP)));
  if (nx > GRID_MAX_SIDE) { nx = GRID_MAX_SIDE; }
  if (nz > GRID_MAX_SIDE) { nz = GRID_MAX_SIDE; }
  const {
    gHi, gLo, gX0, gX1, gZ0, gZ1, gFloor, gLat, gLift, gOcc, gUsed,
  } = scratch;
  const yTop = rect.yTop === undefined ? Infinity : rect.yTop;
  const liftBand = Number.isFinite(yTop) ? rect.y1 - yTop : 0;
  const sliceH = liftBand > 0 ? liftBand / ROOF_LIFT_SLICES : 0;

  /* Coarsened and re-run rather than merged down, if the first answer is
   * over budget. Merging boxes in two dimensions wants an adjacency graph
   * and three halvings is bounded, cheap and predictable. */
  for (let attempt = 0; attempt < 4; attempt += 1) {
    while (nx * nz > GRID_MAX_CELLS) {
      if (nx >= nz) { nx = Math.max(1, nx >> 1); } else { nz = Math.max(1, nz >> 1); }
    }
    const dx = spanX / nx;
    const dz = spanZ / nz;
    const n = nx * nz;
    for (let k = 0; k < n; k += 1) {
      gHi[k] = -Infinity;
      gLo[k] = Infinity;
      gX0[k] = Infinity;
      gX1[k] = -Infinity;
      gZ0[k] = Infinity;
      gZ1[k] = -Infinity;
      gLift[k] = 0;
      gUsed[k] = 0;
    }
    let any = false;
    for (let idx = 0; idx < count; idx += 1) {
      const g = boxes[list[idx]];
      if (g.y1 < rect.y0 || g.y0 > rect.y1) {
        continue;
      }
      const bx0 = Math.max(g.x0, rect.x0);
      const bx1 = Math.min(g.x1, rect.x1);
      const bz0 = Math.max(g.z0, rect.z0);
      const bz1 = Math.min(g.z1, rect.z1);
      if (bx1 <= bx0 || bz1 <= bz0) {
        continue;
      }
      let a0 = Math.floor((bx0 - rect.x0) / dx);
      let a1 = Math.ceil((bx1 - rect.x0) / dx) - 1;
      let b0 = Math.floor((bz0 - rect.z0) / dz);
      let b1 = Math.ceil((bz1 - rect.z0) / dz) - 1;
      if (a0 < 0) { a0 = 0; }
      if (b0 < 0) { b0 = 0; }
      if (a1 > nx - 1) { a1 = nx - 1; }
      if (b1 > nz - 1) { b1 = nz - 1; }
      if (a1 < a0) { a1 = a0; }
      if (b1 < b0) { b1 = b0; }
      const gy1 = Math.min(g.y1, rect.y1);
      const gy0 = Math.max(g.y0, rect.y0);
      let q0 = 0;
      let q1 = -1;
      if (sliceH > 0 && gy1 > yTop) {
        q0 = Math.floor((Math.max(gy0, yTop) - yTop) / sliceH);
        q1 = Math.ceil((gy1 - yTop) / sliceH) - 1;
        if (q0 < 0) { q0 = 0; }
        if (q1 > ROOF_LIFT_SLICES - 1) { q1 = ROOF_LIFT_SLICES - 1; }
      }
      for (let a = a0; a <= a1; a += 1) {
        const sx0 = rect.x0 + a * dx;
        const sx1 = sx0 + dx;
        /* Clipped to the CELL, not to the rectangle, for the reason the
         * strip cut gives at the same place: it is what makes the pieces
         * disjoint, so a cut removes volume rather than adding it. */
        const ex0 = bx0 > sx0 ? bx0 : sx0;
        const ex1 = bx1 < sx1 ? bx1 : sx1;
        for (let b = b0; b <= b1; b += 1) {
          const sz0 = rect.z0 + b * dz;
          const sz1 = sz0 + dz;
          const ez0 = bz0 > sz0 ? bz0 : sz0;
          const ez1 = bz1 < sz1 ? bz1 : sz1;
          const k = a * nz + b;
          if (gy1 > gHi[k]) { gHi[k] = gy1; }
          if (gy0 < gLo[k]) { gLo[k] = gy0; }
          if (ex0 < gX0[k]) { gX0[k] = ex0; }
          if (ex1 > gX1[k]) { gX1[k] = ex1; }
          if (ez0 < gZ0[k]) { gZ0[k] = ez0; }
          if (ez1 > gZ1[k]) { gZ1[k] = ez1; }
          for (let q = q0; q <= q1; q += 1) {
            gLift[k] |= (1 << q);
          }
        }
      }
      any = true;
    }
    if (!any) {
      return null;
    }
    /* The roof lift, taken back per cell wherever what is up there is not on
     * the roof. Same rule as the strip cut's, cell by cell. */
    if (sliceH > 0) {
      for (let k = 0; k < n; k += 1) {
        if (!(gHi[k] > yTop)) {
          continue;
        }
        let run = 0;
        while (run < ROOF_LIFT_SLICES && (gLift[k] & (1 << run)) !== 0) {
          run += 1;
        }
        const cap = yTop + run * sliceH;
        if (gHi[k] > cap) { gHi[k] = cap; }
        if (gLo[k] > gHi[k]) { gLo[k] = gHi[k]; }
      }
    }
    /* Occupancy, against the ground and not the rectangle's own bottom. The
     * ground itself is read off a coarse lattice: see GRID_FLOOR_LATTICE. */
    const fx = Math.min(nx, GRID_FLOOR_LATTICE);
    const fz = Math.min(nz, GRID_FLOOR_LATTICE);
    const fw = fz + 1;
    for (let i = 0; i <= fx; i += 1) {
      const cx = rect.x0 + (i * spanX) / fx;
      for (let j = 0; j <= fz; j += 1) {
        gLat[i * fw + j] = floorAt(cx, rect.z0 + (j * spanZ) / fz);
      }
    }
    let occupied = 0;
    for (let a = 0; a < nx; a += 1) {
      const la = Math.min(fx - 1, Math.floor((a * fx) / nx));
      for (let b = 0; b < nz; b += 1) {
        const lb = Math.min(fz - 1, Math.floor((b * fz) / nz));
        /*
         * The LOWEST of the four lattice corners around the cell, not the
         * nearest of them. On a slope the lattice is up to a few metres
         * across and a ground reading taken too high drops a cell that has
         * a low wall on it, which is a hole. Taken too low it keeps a cell
         * whose only drawing is buried, and a box under the ground stops
         * nobody.
         */
        let ground = gLat[la * fw + lb];
        const c1 = gLat[(la + 1) * fw + lb];
        const c2 = gLat[la * fw + lb + 1];
        const c3 = gLat[(la + 1) * fw + lb + 1];
        if (c1 < ground) { ground = c1; }
        if (c2 < ground) { ground = c2; }
        if (c3 < ground) { ground = c3; }
        const k = a * nz + b;
        const base = Math.max(rect.y0, ground);
        gFloor[k] = base;
        gOcc[k] = gHi[k] !== -Infinity && gHi[k] > base + SLAB_MIN_SOLID ? 1 : 0;
        occupied += gOcc[k];
      }
    }
    if (occupied === 0) {
      return null;
    }
    /*
     * The decomposition: grow each box along z, then along x for whole
     * columns, while the run's own spread in `hi` and in `lo` both stay
     * inside SLAB_STEP_TOL. Against the RUN and not against the neighbour,
     * which is the same argument the strip cut makes: a slope is not a step,
     * and comparing neighbours never breaks on one.
     */
    const out = [];
    let over = false;
    for (let a = 0; a < nx && !over; a += 1) {
      for (let b = 0; b < nz; b += 1) {
        const k0 = a * nz + b;
        if (!gOcc[k0] || gUsed[k0]) {
          continue;
        }
        let hiMin = gHi[k0];
        let hiMax = gHi[k0];
        let loMin = gLo[k0];
        let loMax = gLo[k0];
        let h = 1;
        while (b + h < nz) {
          const k = a * nz + b + h;
          if (!gOcc[k] || gUsed[k]) {
            break;
          }
          const h1 = Math.min(hiMin, gHi[k]);
          const h2 = Math.max(hiMax, gHi[k]);
          const l1 = Math.min(loMin, gLo[k]);
          const l2 = Math.max(loMax, gLo[k]);
          if (h2 - h1 > SLAB_STEP_TOL || l2 - l1 > SLAB_STEP_TOL) {
            break;
          }
          hiMin = h1; hiMax = h2; loMin = l1; loMax = l2;
          h += 1;
        }
        let w = 1;
        for (;;) {
          const a2 = a + w;
          if (a2 >= nx) {
            break;
          }
          let h1 = hiMin;
          let h2 = hiMax;
          let l1 = loMin;
          let l2 = loMax;
          let ok = true;
          for (let t = 0; t < h; t += 1) {
            const k = a2 * nz + b + t;
            if (!gOcc[k] || gUsed[k]) { ok = false; break; }
            if (gHi[k] < h1) { h1 = gHi[k]; }
            if (gHi[k] > h2) { h2 = gHi[k]; }
            if (gLo[k] < l1) { l1 = gLo[k]; }
            if (gLo[k] > l2) { l2 = gLo[k]; }
            if (h2 - h1 > SLAB_STEP_TOL || l2 - l1 > SLAB_STEP_TOL) { ok = false; break; }
          }
          if (!ok) {
            break;
          }
          hiMin = h1; hiMax = h2; loMin = l1; loMax = l2;
          w += 1;
        }
        let ux0 = Infinity;
        let ux1 = -Infinity;
        let uz0 = Infinity;
        let uz1 = -Infinity;
        let uFloor = Infinity;
        for (let i2 = 0; i2 < w; i2 += 1) {
          for (let t = 0; t < h; t += 1) {
            const k = (a + i2) * nz + b + t;
            gUsed[k] = 1;
            if (gX0[k] < ux0) { ux0 = gX0[k]; }
            if (gX1[k] > ux1) { ux1 = gX1[k]; }
            if (gZ0[k] < uz0) { uz0 = gZ0[k]; }
            if (gZ1[k] > uz1) { uz1 = gZ1[k]; }
            if (gFloor[k] < uFloor) { uFloor = gFloor[k]; }
          }
        }
        const lifted = loMin - uFloor >= RAISE_MIN_CLEAR;
        const py0 = lifted ? loMin : rect.y0;
        const py1 = Math.max(py0 + 0.001, Math.min(hiMax, rect.y1));
        out.push({
          x0: Math.max(ux0, rect.x0),
          y0: py0,
          z0: Math.max(uz0, rect.z0),
          x1: Math.min(ux1, rect.x1),
          y1: py1,
          z1: Math.min(uz1, rect.z1),
        });
        if (out.length > MAX_PIECES) {
          over = true;
          break;
        }
      }
    }
    if (!over) {
      return out;
    }
    if (nx <= 1 && nz <= 1) {
      return null;
    }
    nx = Math.max(1, nx >> 1);
    nz = Math.max(1, nz >> 1);
  }
  return null;
}

/*
 * One rectangle, cut along its long axis and then each piece cut again along
 * the other one.
 *
 * The second pass is what opens a courtyard: a plot with a house on one side
 * and a shed on the other is one run after the first cut, because a strip
 * across it meets both. Cutting that run the other way separates them. Two
 * passes and no more, because the third would be cutting pieces already
 * smaller than the craft.
 */
function fitRect(c, y0, y1, boxes, grid, floorAt, scratch, { roof = true } = {}) {
  scratch.mark += 1;
  const count = gatherBoxes(c, boxes, grid, scratch.seen, scratch.mark, scratch.list);
  if (count === 0) {
    /* Nothing drawn anywhere near it, as opposed to something drawn that
     * does not reach above the ground. The audit tells the two apart. */
    scratch.lastEmpty = 'nothing';
    return null;
  }
  scratch.lastEmpty = 'below-ground';
  /*
   * The roof, which a fit that only shrinks could never reach.
   *
   * A house collider is authored to the wall plate and the roof above it was
   * drawn and not solid. Rather than raise a finished box afterwards, which
   * raises it over its whole footprint including the half with no roof on it,
   * the rectangle is simply allowed to reach ROOF_LIFT_MAX higher before the
   * cut runs. The cut then hugs the roof where the roof is and stops at the
   * plate where it is not. Only for a rectangle bulky enough to be a
   * building: a kerb does not grow a gable.
   */
  const bulky = roof && Math.min(c.x1 - c.x0, c.z1 - c.z0) > ROOF_LIFT_MIN_FOOT;
  const rect = {
    x0: c.x0, y0, z0: c.z0, x1: c.x1, y1: bulky ? y1 + ROOF_LIFT_MAX : y1, z1: c.z1,
    /* The authored top, so the cut can tell a roof sitting on the rectangle
     * from a canopy standing over it. See ROOF_LIFT_SLICES. */
    yTop: bulky ? y1 : Infinity,
  };
  /*
   * WHICH WAY TO CUT, MEASURED RATHER THAN GUESSED. The first version cut the
   * longer axis, which is right for a barrier and arbitrary for a house. A
   * gable roof is a staircase in one direction and a flat block in the other,
   * so cutting the wrong way removes nothing. Both are tried and the one that
   * leaves less solid volume wins. It is two passes over a list already in
   * cache, against a fit that costs under a second in total.
   */
  const solid = (list) => {
    if (list === null) {
      return Infinity;
    }
    let v = 0;
    for (const b of list) {
      v += (b.x1 - b.x0) * (b.z1 - b.z0) * (b.y1 - Math.max(b.y0, y0));
    }
    return v;
  };
  const byX = cutAxis(rect, true, boxes, scratch.list, count, floorAt, scratch);
  const byZ = cutAxis(rect, false, boxes, scratch.list, count, floorAt, scratch);
  if (byX === null && byZ === null) {
    return null;
  }
  const alongX = solid(byX) <= solid(byZ);
  const first = alongX ? byX : byZ;
  if (first === null) {
    return null;
  }
  const out = [];
  for (const r of first) {
    if (out.length >= MAX_PIECES) {
      out.push(r);
      continue;
    }
    const second = cutAxis(r, !alongX, boxes, scratch.list, count, floorAt, scratch);
    if (second === null || second.length === 0) {
      out.push(r);
      continue;
    }
    for (const q of second) {
      out.push(q);
    }
  }
  /*
   * And the grid, when strips of strips still leave a lot of air. Two passes
   * of strips are a good fit for anything whose height is a function of one
   * axis, and the grid only wins where it is a function of both, so the strip
   * answer is kept unless the grid beats it by GRID_GAIN. A tie goes to the
   * strips because they emit fewer boxes.
   */
  const gridded = cutGrid(rect, boxes, scratch.list, count, floorAt, scratch);
  if (gridded !== null && gridded.length > 0 && solid(gridded) < solid(out) - GRID_GAIN) {
    return gridded;
  }
  return out;
}

/*
 * THE TOWN'S CARS, AND WHAT THE COLLIDER FIT READS OF THEM.
 *
 * The cars are drawn by src/art/cars.js at the town's own sizes, and each
 * car's own solid is parkVehicle's box from vehicleSize, which skips the fit
 * and so does not move. But the fit hugs every OTHER authored rectangle onto
 * the drawing standing in it, and a car parked inside one is drawing: the
 * multi storey car park's deck pieces reach up over the cars on it, and the
 * lake layby's pieces round the truck and the hatch. Fitted to the new
 * drawing, 94 of the town's 19,515 boxes changed shape and 46 more were cut,
 * measured on 2026-09-26: a change to the town's solids, which is the
 * owner's to approve and was not asked for. So the fit goes on reading the
 * drawing it was always fitted to: each car is built twice, the new model to
 * draw and the vendored one (the hooks unset, so makeVehicle and makeKeiTruck
 * draw as upstream does) in an invisible holder beside it, which the fit's
 * drawnBoxes reads (it skips a mesh only when the mesh itself is hidden) and
 * the renderer never draws; the new model is marked `fitSkip`. The holder is
 * dropped as soon as the colliders are built, before the audits, the
 * references and the merge, so none of them ever sees it. The traversal
 * order of the old meshes is what it was, so the fit is fed the same boxes
 * in the same order and every collider comes out to the bit.
 */
function townCar(o, draw, vendored, carFit) {
  const car = draw(o);
  setVehicleModel(null);
  setKeiTruckModel(null);
  let was;
  try {
    was = vendored(o);
  } finally {
    setVehicleModel((q) => townCar(q, townVehicle, makeVehicle, carFit));
    setKeiTruckModel((q) => townCar(q, townKeiTruck, makeKeiTruck, carFit));
  }
  const holder = new THREE.Group();
  holder.name = car.name;
  holder.position.copy(car.position);
  holder.rotation.copy(car.rotation);
  holder.userData = car.userData;
  car.position.set(0, 0, 0);
  car.rotation.set(0, 0, 0);
  car.userData = { ...car.userData, fitSkip: true };
  was.position.set(0, 0, 0);
  was.rotation.set(0, 0, 0);
  was.visible = false;
  holder.add(car, was);
  carFit.push({ holder, was });
  return holder;
}

function dropCarFit(carFit) {
  for (const { holder, was } of carFit) {
    holder.remove(was);
    was.traverse((o) => {
      if (o.isMesh) {
        o.geometry.dispose();
        if (o.material && o.material.isShaderMaterial) {
          o.material.dispose();
        }
      }
    });
  }
  carFit.length = 0;
}

/*
 * THE CANOPIES TAKE THE COMIC PASS'S LEAF CLUMPS (render/comic.js, FOLIAGE).
 *
 * By name: the five canopy sets trees.js builds, for the town and for the
 * two places, which use the same builders. On a COPY of the material, one
 * per material however many sets share it. cel() hands the same material to
 * anything built with the same arguments, and bakeColourToVertices gives
 * the merged material it makes the userData of the first material it folds
 * in, the object itself and not a copy, so a mark on a shared material
 * could put leaves on a wall. The copy keeps the hook and the program key,
 * which Material.copy does not carry, exactly as the bake's own copies do.
 * Each set is its own draw already, so this adds a handful of materials and
 * no draw call. Before the bake and the chunking, so every chunk of a set
 * carries the copy.
 *
 * The cherry and grove sets, the round blobs, are also marked comicBlob
 * (graphics pass 19): each blob writes a code the ink reads, so the creases
 * between its own faces are not inked and it outlines as one round shape
 * (render/comic.js, A CANOPY BLOB'S CODE). The cedars, the bamboo and the
 * shrubs are faceted on purpose and keep their creases, so a material is
 * copied once per kind as well as once per original: a shrub that happens
 * to share a grove's paint gets a copy without the mark.
 */
const CANOPY = /^(sakura|grove|cedar|bamboo|shrub)Canopy\d+$/;

function markCanopies(root) {
  const made = new Map();
  root.traverse((o) => {
    if (!o.isInstancedMesh || !CANOPY.test(o.name) || Array.isArray(o.material)) {
      return;
    }
    const m = o.material;
    const blob = ROUND_CANOPY.test(o.name);
    let kinds = made.get(m);
    if (!kinds) {
      kinds = new Map();
      made.set(m, kinds);
    }
    let c = kinds.get(blob);
    if (!c) {
      c = m.clone();
      c.onBeforeCompile = m.onBeforeCompile;
      if (typeof m.customProgramCacheKey === 'function') {
        c.customProgramCacheKey = m.customProgramCacheKey;
      }
      c.userData = { ...m.userData, comicFoliage: true, comicBlob: blob };
      kinds.set(blob, c);
    }
    o.material = c;
  });
  let size = 0;
  made.forEach((kinds) => {
    size += kinds.size;
  });
  return size;
}

/*
 * ROUND CANOPIES NEAR THE EYE (graphics pass 15).
 *
 * The cherry and grove canopies are twenty faced blobs, shaded round since
 * PATCH-world-trees.diff, but the outline still found their facets: the ink
 * pass reads creases from depth, and a 42 degree turn at every edge is a
 * crease, so a tree beside the quad was a bunch of inked gems. An eighty
 * faced blob turns about 20 degrees at an edge and outlines as a near
 * circle. It is drawn at 0.92 of the sphere, which matches the twenty
 * faced blob's average silhouette (0.906 by projected area, 0.938 by mean
 * width), so a canopy does not swell as the eye nears it.
 *
 * Near cells only, because the town's triangles are its trees: the eighty
 * faced blob is four times the twenty, and the town carries 6,798 cherry
 * and grove blobs after thinning on High. A cell takes the round blob while
 * its nearest point is within `q.city.leafRound` metres of the eye; past
 * that the fog has started and a facet is a few pixels. The swap is the
 * mesh's geometry pointer, written only when a cell crosses the line, so it
 * costs no draw call, no program and no buffer beyond one eighty faced
 * blob per set, and it changes nothing a collider or the bake reads: it is
 * done on the chunks after both. Low keeps the twenty faced blob.
 *
 * Sets are found by name and checked by shape, an icosahedron at detail 0
 * whose normals are radial, which is the blob buildSakura and buildGrove
 * draw; the shrubs and the bamboo are faceted on purpose and are left
 * alone, as is anything not in a cell (a set too wide for one is drawn
 * from every distance and keeps its blob).
 *
 * CLUMPS NEAR THE EYE (graphics pass 24). With its facets gone the near
 * blob was a smooth balloon, and a cherry beside the quad was a bunch of
 * them, pale and round, which is what the yard's trees were until pass 23.
 * So on Medium and High (the quality table's leafClumps) the near blob is
 * one of the yard's clumps of lumps (src/render/clump.js), a different one
 * for each tone of each kind, under every blob's own spin and squash. It
 * is drawn at 0.92, the round blob's scale, which gives it the twenty faced
 * blob's mean silhouette: as the radius of a circle of the same area,
 * averaged over 300 directions, 0.877 against 0.874 (the round blob 0.887),
 * so a tree still does not swell as the eye nears it. The one shape of the
 * eight that is leaner than the rest (0.857 at full size) is left out. 180
 * faces on 92 vertices where the round blob is 80 on 240, and still no draw
 * call or program, and no buffer beyond one clump per shape, made with the
 * town and freed with it.
 *
 * Nothing a collider reads changes, as before. A town blob's solid is the
 * box round its unturned ellipsoid (collideLeaves in the vendored trees.js),
 * and every blob is drawn turned inside it. A clump at 0.92 reaches at most
 * 0.975 of the radius at the top of a lump, so across the blob it stays
 * inside the box as the round blob did; above and below it a turned blob
 * already reached past the box, and a clump reaches at most 0.055 of the
 * radius further than the round blob there. Its valleys lie at about 0.69
 * of the radius, where the far blob's faces lie at 0.79 and the round
 * blob's at 0.86, so between two lumps the box stands up to a tenth of the
 * radius further out from the leaves than it does on Low.
 */
const ROUND_CANOPY = /^(sakura|grove)Canopy\d+$/;
/* The clump shapes the town draws: all but the lean one. */
const TOWN_CLUMPS = [0, 1, 2, 3, 4, 6, 7];

/* The clump for a set, by its kind and its tone: the cherries' three tones
 * take the first three shapes and the groves' four (the fourth is the
 * willows' pale green) the other four. `made` holds this town's, one a
 * shape. */
function nearClump(name, made) {
  const tone = Number(name.slice(name.lastIndexOf('Canopy') + 6)) || 0;
  const k = TOWN_CLUMPS[((name.startsWith('grove') ? 3 : 0) + tone) % TOWN_CLUMPS.length];
  let g = made[k];
  if (!g) {
    g = clumpBlob(k).clone();
    g.scale(0.92, 0.92, 0.92);
    made[k] = g;
  }
  return g;
}

function isRoundBlob(geo) {
  if (geo.type !== 'IcosahedronGeometry' || !geo.parameters || geo.parameters.detail !== 0) {
    return false;
  }
  const p = geo.attributes.position;
  const n = geo.attributes.normal;
  if (!p || !n) {
    return false;
  }
  for (let i = 0; i < p.count; i += 1) {
    const l = Math.hypot(p.getX(i), p.getY(i), p.getZ(i));
    if (Math.abs(n.getX(i) * l - p.getX(i)) > 1e-4 || Math.abs(n.getY(i) * l - p.getY(i)) > 1e-4
      || Math.abs(n.getZ(i) * l - p.getZ(i)) > 1e-4) {
      return false;
    }
  }
  return true;
}

function roundCanopiesNear(cells, clumps, swapped) {
  const twins = new Map();
  const shapes = [];
  let meshes = 0;
  for (const c of cells) {
    for (const item of c.items) {
      item.traverse((o) => {
        if (!o.isInstancedMesh || !ROUND_CANOPY.test(o.name)) {
          return;
        }
        const lo = o.geometry;
        const key = clumps ? `${lo.uuid}:${o.name}` : lo.uuid;
        let hi = twins.get(key);
        if (hi === undefined) {
          hi = null;
          if (isRoundBlob(lo)) {
            /* A clump only stands in for the unit blob both builders draw,
             * and only if it carries every attribute the set's program
             * reads, which after the bake's trimAttributes is position and
             * normal. Otherwise the round blob, as before pass 24. */
            const clump = clumps && lo.parameters.radius === 1 ? nearClump(o.name, shapes) : null;
            if (clump && Object.keys(lo.attributes).every((name) => clump.attributes[name])) {
              hi = clump;
            } else {
              hi = new THREE.IcosahedronGeometry(lo.parameters.radius * 0.92, 1);
              /* The same attributes as the blob it stands in for, so the
               * program three.js built for the set binds it unchanged: the
               * bake's trimAttributes has taken uv off the canopy. */
              for (const name of Object.keys(hi.attributes)) {
                if (!lo.attributes[name]) {
                  hi.deleteAttribute(name);
                }
              }
            }
          }
          twins.set(key, hi);
        }
        if (!hi) {
          return;
        }
        o.userData.leafLo = lo;
        o.userData.leafHi = hi;
        swapped.add(lo);
        swapped.add(hi);
        (c.leaves || (c.leaves = [])).push(o);
        c.leafNear = false;
        meshes += 1;
      });
    }
  }
  return { meshes, sets: new Set([...twins.values()].filter(Boolean)).size, clumps: clumps === true };
}

function buildColliders(world) {
  const colliders = new Colliders();
  let noTop = 0;
  let noBottom = 0;

  /* The fit's own index over the drawn meshes. The town's cars are read as
   * the vendored drawing, not as ours: see townCar. */
  const fitStart = (typeof performance !== 'undefined' ? performance.now() : 0);
  const boxes = drawnBoxes(world.root, {
    maxFootprint: FIT_MAX_FOOTPRINT,
    skip: (o) => COVER_SOFT.test(o.name || '') || FIT_MOVING.test(o.name || '') || o.userData.fitSkip === true,
  });
  const grid = new Map();
  for (let i = 0; i < boxes.length; i += 1) {
    const g = boxes[i];
    const a0 = Math.floor(g.x0 / FIT_CELL);
    const a1 = Math.floor(g.x1 / FIT_CELL);
    const b0 = Math.floor(g.z0 / FIT_CELL);
    const b1 = Math.floor(g.z1 / FIT_CELL);
    for (let a = a0; a <= a1; a += 1) {
      for (let b = b0; b <= b1; b += 1) {
        const k = `${a},${b}`;
        const bucket = grid.get(k);
        if (bucket === undefined) {
          grid.set(k, [i]);
        } else {
          bucket.push(i);
        }
      }
    }
  }
  /*
   * The fit's scratch, allocated once for the whole town. Everything the cut
   * needs per rectangle lives here, so 5885 rectangles do not make 5885 sets
   * of typed arrays during a load that is already the slow part.
   */
  const scratch = {
    lastEmpty: '',
    hi: new Float64Array(SLAB_MAX),
    lo: new Float64Array(SLAB_MAX),
    s0: new Float64Array(SLAB_MAX),
    s1: new Float64Array(SLAB_MAX),
    l0: new Float64Array(SLAB_MAX),
    l1: new Float64Array(SLAB_MAX),
    floor: new Float64Array(SLAB_MAX),
    lift: new Int32Array(SLAB_MAX),
    occ: new Uint8Array(SLAB_MAX),
    gHi: new Float64Array(GRID_MAX_CELLS),
    gLo: new Float64Array(GRID_MAX_CELLS),
    gX0: new Float64Array(GRID_MAX_CELLS),
    gX1: new Float64Array(GRID_MAX_CELLS),
    gZ0: new Float64Array(GRID_MAX_CELLS),
    gZ1: new Float64Array(GRID_MAX_CELLS),
    gFloor: new Float64Array(GRID_MAX_CELLS),
    gLat: new Float64Array((GRID_FLOOR_LATTICE + 1) * (GRID_FLOOR_LATTICE + 1)),
    gLift: new Int32Array(GRID_MAX_CELLS),
    gOcc: new Uint8Array(GRID_MAX_CELLS),
    gUsed: new Uint8Array(GRID_MAX_CELLS),
    seen: new Int32Array(boxes.length),
    mark: 0,
    list: new Int32Array(boxes.length),
  };
  /*
   * The bare ground, cached.
   *
   * fromY far below excludes every platform from the query, so this is the
   * terrain under the town rather than whatever deck happens to be over it,
   * which is what "does the drawing reach above the ground here" has to be
   * measured against. Rounded to a decimetre, well under the finest slab.
   */
  const groundSeen = new Map();
  const floorAt = (x, z) => {
    const k = `${Math.round(x * 10)},${Math.round(z * 10)}`;
    let v = groundSeen.get(k);
    if (v === undefined) {
      v = world.heightAt(x, z, -1000);
      groundSeen.set(k, v);
    }
    return v;
  };
  const fitStats = {
    fitted: 0, unmatched: 0, split: 0, extraBoxes: 0, coverSplit: 0, lifted: 0, topTrims: 0, sideTrims: 0, maxTopTrim: 0, maxSideTrim: 0, totalTopTrim: 0, covered: 0, authoredInside: 0, seeThrough: 0, roofLifts: 0, droppedEmpty: 0, tight: 0, worst: [],
  };
  /*
   * The boxes a split rectangle produced beyond its first.
   *
   * EVERY town collider gets exactly one box at its own index, in order, with
   * no gaps. Index alignment with world.colliders is what lets animation.js
   * raise and lower the two level crossing booms by index, so a rectangle
   * that cuts into four contributes its first piece in place and its other
   * three here, to be added after the whole list has been walked. Nothing
   * downstream indexes past the authored count.
   */
  const extra = [];
  /*
   * One row per authored rectangle, and only when the audit asked for it.
   * See scripts/collider-audit.js.
   */
  /* Rows are the per-rectangle dump. The scan itself does not need them,
   * and stringifying thousands of them is what used to drown the audit. */
  const diag = globalThis.__CITY_SCAN_ROWS ? [] : null;

  for (const c of world.colliders) {
    const y1 = c.top === undefined ? BOX_CEIL : c.top;
    const y0 = c.bottom === undefined ? BOX_FLOOR : c.bottom;
    if (c.top === undefined) {
      noTop += 1;
    }
    if (c.bottom === undefined) {
      noBottom += 1;
    }
    /*
     * The fit. A hull over the drawing inside the rectangle, cut where a
     * quad could fly through, and never grown past what the town authored.
     * See the slab fit above.
     */
    let fx0 = c.x0;
    let fx1 = c.x1;
    let fz0 = c.z0;
    let fz1 = c.z1;
    let fy0 = y0;
    let fy1 = y1;
    const tight = c.skipFit === true
      || ((c.x1 - c.x0) <= FIT_TIGHT && (c.z1 - c.z0) <= FIT_TIGHT);
    const pieces = tight ? null : fitRect(c, y0, y1, boxes, grid, floorAt, scratch);
    if (tight) {
      fitStats.tight += 1;
    } else if (pieces !== null && pieces.length > 0) {
      const p = pieces[0];
      const side = Math.max(p.x0 - c.x0, c.x1 - p.x1, p.z0 - c.z0, c.z1 - p.z1);
      const topTrim = y1 - p.y1;
      if (topTrim > 1e-6) {
        fitStats.topTrims += 1;
        fitStats.totalTopTrim += topTrim;
        if (topTrim > fitStats.maxTopTrim) {
          fitStats.maxTopTrim = topTrim;
        }
      }
      if (side > 1e-6) {
        fitStats.sideTrims += 1;
        if (side > fitStats.maxSideTrim) {
          fitStats.maxSideTrim = side;
        }
      }
      if (side > 0.05 || topTrim > 0.05 || pieces.length > 1) {
        fitStats.worst.push({
          side: +side.toFixed(2),
          topTrim: +topTrim.toFixed(2),
          pieces: pieces.length,
          was: { x: +(c.x1 - c.x0).toFixed(2), z: +(c.z1 - c.z0).toFixed(2), top: +y1.toFixed(2) },
          now: { x: +(p.x1 - p.x0).toFixed(2), z: +(p.z1 - p.z0).toFixed(2), top: +p.y1.toFixed(2) },
          at: [+((c.x0 + c.x1) / 2).toFixed(1), +((c.z0 + c.z1) / 2).toFixed(1)],
        });
      }
      fx0 = p.x0; fx1 = p.x1; fz0 = p.z0; fz1 = p.z1; fy0 = p.y0; fy1 = p.y1;
      if (p.y0 > y0 + 1e-6) {
        fitStats.lifted += 1;
      }
      fitStats.fitted += 1;
      if (pieces.length > 1) {
        fitStats.split += 1;
        for (let k = 1; k < pieces.length; k += 1) {
          extra.push(pieces[k]);
          if (pieces[k].y0 > y0 + 1e-6) {
            fitStats.lifted += 1;
          }
        }
      }
    } else {
      /* Nothing drawn in it. A large barrier with no geometry is usually
       * load bearing (lake edge, map bound). A compact one is dressing
       * whose drawing we stripped: park it below ground, not as a boom
       * (booms are the only two authored at top === -1). */
      fitStats.unmatched += 1;
      const sx = c.x1 - c.x0;
      const sz = c.z1 - c.z0;
      if (c.top !== -1 && sx <= 6 && sz <= 6 && sx * sz <= 12 && y1 < 10) {
        const mx = (c.x0 + c.x1) * 0.5;
        const mz = (c.z0 + c.z1) * 0.5;
        fx0 = mx;
        fx1 = mx + 0.001;
        fz0 = mz;
        fz1 = mz + 0.001;
        fy0 = -2;
        fy1 = -1.999;
        fitStats.droppedEmpty += 1;
      }
    }
    if (diag !== null) {
      const r2 = (v) => (Number.isFinite(v) ? +v.toFixed(3) : null);
      diag.push([
        diag.length,
        r2(c.x1 - c.x0), r2(c.z1 - c.z0), r2(y1),
        r2(fx1 - fx0), r2(fz1 - fz0), r2(fy1),
        pieces === null ? (scratch.lastEmpty === 'nothing' ? -1 : 0) : pieces.length,
        r2(fy0),
        r2((c.x0 + c.x1) * 0.5), r2((c.z0 + c.z1) * 0.5),
      ]);
    }
    /*
     * A degenerate box is given a valid paper thin extent rather than being
     * dropped, because a `continue` here would silently shift every later
     * index by one, and an inverted lo > hi pair would be a quiet wrong
     * answer from the distance solver.
     */
    colliders.addBox('wall', fx0, fy0, fz0, fx1, fy1 > fy0 ? fy1 : fy0 + 0.001, fz1);
  }
  for (const p of extra) {
    colliders.addBox('wall', p.x0, p.y0, p.z0, p.x1, p.y1 > p.y0 ? p.y1 : p.y0 + 0.001, p.z1);
    fitStats.extraBoxes += 1;
  }
  fitStats.ms = (typeof performance !== 'undefined' ? performance.now() : 0) - fitStart;
  fitStats.drawnBoxes = boxes.length;
  fitStats.meanTopTrim = fitStats.topTrims ? fitStats.totalTopTrim / fitStats.topTrims : 0;
  fitStats.worst.sort((a, b) => Math.max(b.side, b.topTrim) - Math.max(a.side, a.topTrim));
  fitStats.worst = fitStats.worst.slice(0, 14);
  /*
   * The other half of hugging the graphics: things that are DRAWN and were
   * never solid at all.
   *
   * The town collides what a walker can walk into, and a walker never walks
   * into a lamp post standing in the middle of a footway, so a great deal of
   * street furniture is scenery. The owner flew it and said so: "the train
   * and lamp posts and many other graphic elements have no collision".
   * Measured at object granularity, which is what ctx.add puts in the root,
   * 403 objects stand on the ground, are at least 0.4 m tall and have no
   * collider over them at all. A 2.4 m lamp post 0.1 m square is the typical
   * one.
   *
   * WHY A FLAT BOX PER OBJECT IS SAFE HERE AND WOULD NOT BE IN GENERAL.
   * Adding the bounding box of every uncovered mesh in the town would make
   * the tunnel bore solid, put a lid on the lake and turn 46000 canopy blobs
   * into walls. So the pass is bounded to COMPACT objects standing on the
   * ground: nothing wider than COVER_MAX_SPAN, nothing with a footprint over
   * COVER_MAX_FOOTPRINT, nothing whose base floats more than COVER_MAX_LIFT
   * above the surface under it. Those bounds exclude buildings, tunnels,
   * hills, roads and the lake by construction, and what is left is furniture,
   * for which its own bounding box IS a fair contact volume.
   *
 * Foliage is collided as one box per leaf blob in trees.js. The
 * cover pass still skips named foliage so canopy instances do not
 * become walls, and skips named frames (torii, schoolLink,
 * overbridgeCage, schoolBell, openFrame) whose baked AABB is a
 * wall across a gap the pilot can see. The tree generators own
 * the mass.
   */
  for (const child of world.root.children) {
    const b = objectExtent(child);
    if (b === null) {
      continue;
    }
    const sx = b.x1 - b.x0;
    const sy = b.y1 - b.y0;
    const sz = b.z1 - b.z0;
    if (sy < COVER_MIN_HEIGHT || Math.min(sx, sz) < COVER_MIN_THICK) {
      continue;
    }
    if (sx * sz > COVER_MAX_FOOTPRINT || Math.max(sx, sz) > COVER_MAX_SPAN) {
      continue;
    }
    const cx = (b.x0 + b.x1) * 0.5;
    const cz = (b.z0 + b.z1) * 0.5;
    if (b.y0 - world.heightAt(cx, cz, -1000) > COVER_MAX_LIFT) {
      continue;
    }
    if (b.vol / Math.max(1e-6, sx * sy * sz) < COVER_MIN_FILL) {
      fitStats.seeThrough += 1;
      continue;
    }
    if (coveredAlready(world.colliders, cx, cz, b.y0 + sy * 0.5)) {
      continue;
    }
    if (sy >= AUTHORED_POST_MIN_HEIGHT && authoredInside(world.colliders, b)) {
      fitStats.authoredInside += 1;
      continue;
    }
    /*
     * And through the same cut as everything else, rather than straight in as
     * a bounding box.
     *
     * The bounds above already keep this pass to compact things standing on
     * the ground, for which a bounding box is a fair contact volume, and
     * COVER_MIN_FILL already turns away a torii or an archway. What they
     * cannot do is anything about the shape of what is left: a signpost with
     * an arm, a shed standing at thirty degrees to the grid, a bus shelter
     * with a bench under an open frame. The slab cut reads all three off the
     * drawing and hugs them, so the box only has to be the envelope it starts
     * from. The roof extension is off here, because unlike a plot rectangle
     * this envelope was measured off the object itself and there is nothing
     * above it to reach for.
     */
    const rect = {
      x0: b.x0, z0: b.z0, x1: b.x1, z1: b.z1,
    };
    const pieces = fitRect(rect, b.y0, b.y1, boxes, grid, floorAt, scratch, { roof: false });
    if (pieces === null || pieces.length === 0) {
      /* A hull we could not cut is a wall across whatever gap the drawing
       * left. Skip it: a ghost prop is the status quo, a filled AABB is
       * the bus-shelter complaint. */
      fitStats.seeThrough += 1;
      continue;
    } else {
      for (const q of pieces) {
        colliders.addBox('obstacle', q.x0, q.y0, q.z0, q.x1, q.y1 > q.y0 ? q.y1 : q.y0 + 0.001, q.z1);
      }
      if (pieces.length > 1) {
        fitStats.coverSplit += 1;
      }
    }
    fitStats.covered += 1;
  }

  let slabs = 0;
  for (const p of world.platforms) {
    /* fromY far below excludes every platform from the query, so this is the
     * bare ground under the platform: exactly what "how high is this deck"
     * has to be measured against. */
    if (p.solid === false) {
      continue;
    }
    const cx = (p.x0 + p.x1) * 0.5;
    const cz = (p.z0 + p.z1) * 0.5;
    const bare = world.heightAt(cx, cz, -1000);
    if (p.top - bare < PLATFORM_SOLID_MIN) {
      continue;
    }
    colliders.addBox(
      'wall',
      p.x0, p.top - PLATFORM_SLAB_THICK, p.z0,
      p.x1, p.top - PLATFORM_SLAB_CLEAR, p.z1,
    );
    slabs += 1;
  }
  if (diag !== null) {
    fitStats.rows = diag;
  }
  return { colliders, noTop, noBottom, slabs, fit: fitStats };
}

export async function buildMap(shell, onProgress, options) {
  const renderer = shell.renderer;
  const camera = shell.camera;
  const progress = onProgress ?? (() => {});
  const q = qualityFor(options && options.quality);
  const fogNear = q.city.fogNear;
  const fogFar = Math.min(q.city.fogFar, q.city.cullRadius - 4);
  const half = q.city.shadowHalf;
  const foliageKeep = q.city.foliageKeep;
  const cullDefault = q.city.cullRadius;

  /* PCF, not PCF soft. The town's shadow map covers 68 m at 2048, which is
   * 3.3 cm per texel, and at that density the softer filter smears a fence
   * post's shadow into a smudge. The field sets its own. Low turns the
   * map off. */
  renderer.shadowMap.enabled = q.shadows;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.setClearColor(new THREE.Color(PAL.fog), 1);

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(PAL.fog, fogNear, fogFar);
  camera.far = CAMERA_FAR;
  camera.updateProjectionMatrix();

  /* The two light anime setup the town is authored for: one warm quantised
   * key, one strong cool bounce carrying the shadow side, a weak underside
   * bounce, and a hemisphere so nothing in shadow goes black. Directions are
   * the town's own. Without the planet there is no local surface frame to
   * seat them in, so they are plain offsets from the shadow target. */
  const sun = new THREE.DirectionalLight(PAL.sun, 2.25);
  sun.castShadow = q.shadows;
  const shadowMap = q.city.shadowMap || 2048;
  sun.shadow.mapSize.set(shadowMap, shadowMap);
  /*
   * 22 m half width on High, not the town's 34.
   *
   * The town's shadow camera is sized for a walker who sees 23 m of ground.
   * A quad at 25 m/s crosses 34 m in 1.4 s, and everything inside that box is
   * submitted to the shadow pass twice over, which measured as roughly half
   * of the frame's draw calls. 22 m is 44 m across at 2048, which is 2.1 cm a
   * texel, so contact shadows under the craft get CRISPER as well as cheaper.
   * What it costs is a cast shadow from a building the pilot is about to
   * reach, which at 25 m/s is under a second of warning.
   */
  sun.shadow.camera.left = -half;
  sun.shadow.camera.right = half;
  sun.shadow.camera.top = half;
  sun.shadow.camera.bottom = -half;
  sun.shadow.camera.near = 1;
  sun.shadow.camera.far = 200;
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.035;
  scene.add(sun);
  scene.add(sun.target);

  const fill = new THREE.DirectionalLight(PAL.fill, 1.08);
  scene.add(fill);
  scene.add(fill.target);
  const bounce = new THREE.DirectionalLight(0xd8cbe8, 0.34);
  scene.add(bounce);
  scene.add(bounce.target);
  scene.add(new THREE.HemisphereLight(PAL.hemiSky, PAL.hemiGround, 1.12));

  const SUN_OFFSET = new THREE.Vector3(-52, 62, 56);
  const FILL_OFFSET = new THREE.Vector3(48, 26, -44);
  const BOUNCE_OFFSET = new THREE.Vector3(10, -18, 40);

  progress(0.04);
  const sky = buildSky(scene, 500);
  /* Heaped cumulus in place of the vendored cards, and the streak cloud on
   * Medium and High: src/render/comicsky.js. */
  comicSky(sky, { cloud: PAL.cloud, shade: PAL.cloudShade, ink: PAL.ink, sun: SUN_OFFSET.toArray() },
    { streaks: q.id !== 'low' });
  progress(0.08);

  /*
   * The town. `bake: false` is the one patched line in the vendored tree and
   * the reason this map is possible at all; see the header and
   * ./vendored/PATCH-world-index.diff.
   *
   * This is the expensive call and it is synchronous: it builds about
   * nineteen thousand meshes and generates every sign, fascia, lantern and
   * price strip with Canvas2D. Yielding to the event loop around it is what
   * lets the loading screen paint the stage it is on rather than freezing on
   * the previous one.
   */
  await yieldToPaint();
  /* Every parked car, and the kei truck at the crossing, drawn by our model
   * at the town's own sizes and placed by the town; see townCar below. */
  const carFit = [];
  setVehicleModel((o) => townCar(o, townVehicle, makeVehicle, carFit));
  setKeiTruckModel((o) => townCar(o, townKeiTruck, makeKeiTruck, carFit));
  let world;
  try {
    world = buildWorld(scene, { bake: false });
  } finally {
    setVehicleModel(null);
    setKeiTruckModel(null);
  }
  /*
   * THE LIVE BLOSSOM FIELD, SETTLED BEFORE ANYTHING IN THE BAKE SEES IT.
   *
   * 980 instanced cards drifting down the street corridor. It owns its own
   * instance buffer and rewrites all of it every step, which makes it the one
   * thing in this town that three separate passes below would each get wrong,
   * so both branches are taken here rather than after them.
   *
   * KEPT: marked `noChunk`, because `chunkInstanced` would otherwise split the
   * three sources into per cell copies and detach the originals, leaving 980
   * matrix writes a step going into meshes that are no longer in the graph.
   * The field would simply vanish, with nothing reported anywhere. `noMerge`
   * is belt and braces, since bakeCity already skips every instanced mesh.
   *
   * DROPPED, on Low: taken out of the graph and freed, not hidden. Hiding it
   * here is not enough, because `buildCullGrid` collects it into a cell and
   * `cullTo` writes `visible` on every item of a cell that changes state, so
   * the first time that cell came back the blossom Low had switched off would
   * come back with it. Out of the graph it cannot be switched on by anything,
   * the 980 matrices are not carried, and the static fallen drifts stay.
   */
  if (world.petals && world.petals.meshes && world.petals.meshes.length) {
    if (q.city.petals) {
      for (const m of world.petals.meshes) {
        m.userData.noChunk = true;
        m.userData.noMerge = true;
      }
    } else {
      for (const m of world.petals.meshes) {
        m.removeFromParent();
        /* Its own instance buffer, its own geometry and its own material.
         * NOT the map: `petalTex()` is a module level singleton in
         * ./vendored/core/textures.js and the static fallen drifts, which
         * Low keeps, are still drawing with it. */
        m.dispose();
        m.geometry.dispose();
        m.material.dispose();
      }
      world.petals.meshes = [];
      world.petals.update = () => {};
    }
  }
  progress(0.86);
  await yieldToPaint();

  /*
   * THE TWO PLACES ON THE WORKS ROAD, and they go in HERE, between the town
   * being built and anything looking at it.
   *
   * 旧ひばり製作所 and ひばり台市民プール are ours, GPLv3, under ./places/,
   * and they are built from the host side rather than added to the vendored
   * district list: /NOTICE's rule is that our shell wraps a vendored module
   * rather than editing it, and the town's own `buildWorld` has been patched
   * once already. Everything downstream sees them because they are added to
   * the same `world.root`, the same `world.colliders` (appended, never
   * inserted, because the crossing booms are identified by index), the same
   * `world.platforms` and the same `world.cuts`. So the collider fit trims
   * them, the cover pass reads them, the merge buckets them, the cull grid
   * cells them and `world.heightAt` puts a quad on the pool block's roof and
   * down inside the empty pool.
   *
   * Before `buildColliders`, which is the whole point: authored boxes that
   * already hug their drawing want to be inspected by the fit, not held out
   * of it. See ./places/index.js.
   */
  /*
   * Find the level crossing booms NOW, before anything runs the town forward
   * AND before anything adds a collider to it.
   *
   * They are identified by being parked below ground, and `top` is RUNTIME
   * state: the town rewrites it on every `world.update`. bake.js then runs the
   * town for 48 simulated seconds to measure what moves, which leaves the
   * crossing in whatever phase that lands on. Measured, PROBE_STEPS in 95 to
   * 117 and 202 to 213 leaves both booms DOWN, and the identification would
   * throw. It happens to work at 120. Doing it here makes the ordering
   * irrelevant instead of lucky.
   *
   * IT ALSO HAS TO RUN BEFORE `buildPlaces`, and that is the newer half.
   * `findBoomBlocks` asserts the two parked colliders are the LAST TWO in the
   * list, which is a true and worth-keeping fact about the town's own build
   * and stops being true the moment anything appends. Called here it is
   * checked against exactly what it is a statement about, and the two indices
   * it returns stay valid afterwards because ./places/ only ever appends:
   * nothing is inserted, so nothing before them moves.
   */
  const boomIndices = findBoomBlocks(world.colliders);

  /* `petals` is the same preset flag the town's own field is gated on: the
   * two places get their own field, over their own ground, for the reason in
   * ./places/blossom.js. */
  const places = buildPlaces(world, { petals: q.city.petals });
  markCanopies(world.root);
  progress(0.87);
  await yieldToPaint();

  const { colliders, noTop, noBottom, slabs, fit } = buildColliders(world);
  /* The collider fit has read the vendored cars; they go now, before the
   * audits, the references and the merge see anything. */
  dropCarFit(carFit);

  /*
   * The train, as three moving boxes.
   *
   * It is 59.6 m of solid steel crossing the town at 23.5 m/s and it had no
   * collision of any kind: the owner flew through it. It cannot be a static
   * box because the broadphase grid is indexed on x and z, which is the same
   * reason a level crossing boom may only move in y, so it uses the moving
   * box path in src/game/collide.js instead.
   *
   * One box per car rather than one for the whole set, because the gap
   * between cars is a real gap and a single 59.6 m box would be a wall across
   * the coupling. Each car's extent is measured off its own drawn meshes here
   * and then only translated, which is exactly what animation.js does to the
   * group: it sets `train.group.position` along x and never rotates it, so
   * the boxes stay axis aligned and a half extent measured once stays true.
   */
  const trainCars = [];
  for (const car of world.train.cars) {
    const b = objectExtent(car);
    if (b === null) {
      continue;
    }
    const i = colliders.addMoving(
      'train',
      (b.x1 - b.x0) * 0.5, (b.y1 - b.y0) * 0.5, (b.z1 - b.z0) * 0.5,
    );
    trainCars.push({
      index: i,
      /* The car's centre in the group's own frame, so animation.js only has
       * to add the group's offset. */
      x: (b.x0 + b.x1) * 0.5,
      y: (b.y0 + b.y1) * 0.5,
      z: (b.z0 + b.z1) * 0.5,
    });
  }

  colliders.build();
  progress(0.9);

  /*
   * The audit, and only when it is asked for.
   *
   * ./scan.js measures the solid world against the drawn one in both
   * directions: solid volume with nothing drawn under it, which is what a
   * pilot flying the gaps meets as an invisible wall, and drawn objects with
   * nothing solid in them, which is scenery a quad passes through. It has to
   * run here, after the collider set is built and before bakeCity merges the
   * per mesh geometry away, and it costs seconds, so no ordinary load pays
   * for it. scripts/collider-audit.js sets the flag.
   */
  /* Imported here rather than at the top of the file so an ordinary load
   * never fetches it: check 16 counts the city's modules and a diagnostic
   * should not be one of them. */
  const scan = globalThis.__CITY_SCAN
    ? (await import('./scan.js')).scanCity(world, colliders)
    : null;
  /*
   * And the third direction, which neither of the other two can see: air the
   * town draws and the town will not let a craft into. ./cavity.js voxelises
   * the drawing against the collider set AND the contact floor, so an
   * undercroft sealed by a `ctx.cut` rather than by a box is a finding rather
   * than an anecdote. Same window, same reason, its own flag because it costs
   * its own seconds. scripts/cavity-scan.js sets it.
   */
  const cavity = globalThis.__CITY_CAVITY
    ? (await import('./cavity.js')).scanCavities(
      world,
      colliders,
      {
        ...(typeof globalThis.__CITY_CAVITY === 'object' ? globalThis.__CITY_CAVITY : {}),
        /* So `--fit` shows what the FIT sees, not what is drawn: a named
         * frame is invisible to it and that is usually the answer. */
        fitSkip: (o) => COVER_SOFT.test(o.name || '') || FIT_MOVING.test(o.name || ''),
        /* What a craft may fly through without it being a defect: this
         * module's own see-through list, plus the train, which is not where
         * it is drawn. See ./cavity.js. */
        softName: (o) => COVER_SOFT.test(o.name || '') || FIT_MOVING.test(o.name || ''),
      },
    )
    : null;

  /*
   * Reference measurements BEFORE the merge. The merge applies each
   * instance's matrix into its vertices, so after it a door is anonymous
   * floats in a shared buffer and there is nothing left to measure.
   */
  const references = cityReferences(world);
  /* The works and the pool measure their own, off what they built rather
   * than off the tables they were built from, and hand them up. Same
   * principle as cityReferences: a number in stats() has to be evidence. */
  Object.assign(references, places.references);
  progress(0.91);

  /*
   * Merge, then group for culling, in that order: the cull grid has to see
   * the merged meshes, not the twenty thousand it replaced.
   */
  /* Low only, with the fog bands: the same buckets, simplified a hair
   * before they are banded. The simplifier is a 67 KB WASM module, so it
   * is fetched here and nowhere else. See loadSimplifier in ./bake.js. */
  const simplify = q.city.fogBands === true
    ? await loadSimplifier()
    : null;
  const baked = bakeCity(world, {
    cell: MERGE_CELL,
    shadowCell: q.shadows ? MERGE_SHADOW_CELL : MERGE_CELL,
    cullCell: CULL_CELL,
    casterMinRadius: q.shadows ? CASTER_MIN_RADIUS : 1e9,
    casterMinRadiusInstanced: q.shadows ? CASTER_MIN_RADIUS_INSTANCED : 1e9,
    /* See findAnimated in ./bake.js. Turn this OFF the day anything in this
     * shell can press one of the town's buttons. */
    releaseStillRigs: true,
    shadowProxyCell: q.shadows ? q.city.shadowProxyCell : 0,
    fogBanding: q.city.fogBands === true,
    simplify,
  });
  const thinned = thinFoliage(world.root, { keep: foliageKeep });
  const chunked = chunkInstanced(world.root, { cell: CULL_CELL });
  progress(0.92);
  const cull = buildCullGrid(world.root, { cell: CULL_CELL });
  /* After the cull grid, which must not take it: see fogFloor in ./bake.js. */
  const floor = fogFloor(baked.merged, PAL.fog);
  if (floor) {
    world.root.add(floor);
  }
  const leafRound = q.city.leafRound ?? 0;
  /* Every blob and twin the near canopies swap between, for dispose(). */
  const leafSwapped = new Set();
  const roundLeaves = leafRound > 0
    ? roundCanopiesNear(cull.cells, q.city.leafClumps === true, leafSwapped)
    : { meshes: 0, sets: 0, clumps: false };
  const leafR2 = leafRound * leafRound;
  /*
   * Last of the passes that add to the tree, so the chunks, the proxies and
   * the fog floor are frozen with the rest: see freezeStill in ./bake.js.
   * The near canopies swap geometry, never matrices, so they freeze too.
   * The scene's own flag goes with it, because a scene that recomposes
   * forces every child (the note there says why).
   */
  const frozen = freezeStill(world.root, baked.moving);
  scene.matrixAutoUpdate = false;
  const anim = cityAnimation(world, colliders, boomIndices, trainCars);
  let placeStep = 0;
  /* Measured AFTER cityAnimation has seated the booms at step zero, so it is
   * the extent a quad would actually meet. */
  references.crossingBoomCollider = {
    measured: boomColliderExtent(anim.boomExtentDown(), references.crossingBoomGround),
    unit: 'm',
    real: 'must bracket the drawn arm hinge, with the arms DOWN',
  };
  progress(0.94);

  /* groundAuto: the bake has folded colour into vertices and merged the
   * town's roads, walls and cars into shared materials, so its ground
   * cannot be marked material by material (render/comic.js, GROUND). */
  setComicQuality(q, { groundAuto: true, edges: true });
  const pipeline = new CityPipeline(renderer, scene, camera, {
    /*
     * 2.6e6 on High, not the town's own 4.6e6.
     *
     * The pipeline holds three full resolution targets plus a depth texture:
     * half float RGBA for the scene and the ink result at 8 bytes a pixel, a
     * 32 bit depth texture at 4, and a byte RGBA for the grade result at 4,
     * so 24 bytes per pixel of budget. At 4.6e6 that is 110.4 MB, and with
     * the default framebuffer on top the frame lands at 118.7 MB against a
     * 120 MB ceiling, with nothing left for anything else that ever wants a
     * target. At 2.6e6 it is 62.4 MB. The cost is supersampling: the town
     * asks for 1.5x on a low DPI screen and gets about 1.1x at 1080p. The
     * measured effect on the ink is in PROGRESS.md. Medium and Low tighten
     * the budget further; see src/render/quality.js.
     */
    pixelBudget: q.city.pixelBudget,
    minScale: q.city.minScale,
    preferScale: q.city.preferScale,
    /* The Render scale slider and Auto's factor: see userScale there. */
    userScale: options && options.renderScale,
  });
  pipeline.enabled.ink = q.city.ink;
  /* What the preset gave, which the pilot's Manga and scoring switch may
   * only narrow: see setInkLines in src/render/quality.js. */
  pipeline.inkPreset = q.city.ink;
  pipeline.enabled.fxaa = q.city.fxaa;
  /* High's contact shade: see src/render/shade.js. The same rule. */
  if (q.city.shade === true) {
    shadePipeline(pipeline);
  }
  /* High's light wrap: see src/render/glow.js. Never built on Low or
   * Medium, whose pipeline is then exactly what it was. */
  if (q.city.glow === true) {
    glowPipeline(pipeline, GLOW_DAY);
  }
  const d = shell.resize();
  pipeline.setSize(d.w, d.h);

  scene.add(shell.quad);
  /* Every program the street draws, linked now and against the pipeline's
   * scene target instead of one at a time as the pilot first sees each: see
   * render/warm.js. */
  await warmPrograms(renderer, scene, camera, pipeline.rtScene);
  progress(1);

  const shadowTarget = new THREE.Vector3();
  /* How often the map is redrawn: see render/shadowrate.js. */
  const shadowRate = makeShadowRate(renderer, q.shadows ? (q.city.shadowEvery || 1) : 1, half);
  function seat(light, offset, origin) {
    light.target.position.copy(origin);
    light.position.copy(origin).add(offset);
    light.target.updateMatrixWorld();
  }

  /*
   * Which shadow proxies are inside the shadow box.
   *
   * The shadow camera is an orthographic box of SHADOW_HALF a side looking
   * from the sun's offset at the shadow target, so the test is that box's own
   * test done by hand: put the cell centre into the light's view space and
   * compare against the half extents, widened by the cell's own radius so a
   * cell straddling the edge is kept rather than clipped. Done here rather
   * than from `sun.shadow.camera` because that camera's matrices are only
   * brought up to date inside the shadow pass, which runs after this.
   *
   * Every vector and matrix here is allocated once at build time. This runs
   * every frame and P8 forbids allocating in that path.
   */
  const proxyMeshes = baked.proxies ? baked.proxies.meshes : [];
  /* quality.js owns this number; there used to be a SHADOW_PROXY_CELL
   * constant here holding a second copy of the same 24. The `||` rather
   * than `??` is deliberate and narrow: the lowest tier sets
   * shadowProxyCell 0 next to shadowMap 0, so shadows are off there and a
   * zero cell would only give proxyReach nothing to work with. */
  const proxyCell = q.city.shadowProxyCell || 24;
  const proxyReach = Math.hypot(proxyCell, proxyCell) * 0.5;
  const proxyView = new THREE.Matrix4();
  const proxyEye = new THREE.Vector3();
  const proxyUp = new THREE.Vector3(0, 1, 0);
  const proxyAt = new THREE.Vector3();
  function gateProxies(target) {
    if (!proxyMeshes.length) {
      return;
    }
    /* A proxy paints nothing, but the colour pass draws it all the same, so
     * on a frame that does not redraw the shadow map (shadowrate.js) it is a
     * draw and its triangles for nothing: every proxy is hidden then. */
    if (!renderer.shadowMap.autoUpdate && !renderer.shadowMap.needsUpdate) {
      for (let i = 0; i < proxyMeshes.length; i += 1) {
        proxyMeshes[i].visible = false;
      }
      return;
    }
    proxyEye.copy(target).add(SUN_OFFSET);
    proxyView.lookAt(proxyEye, target, proxyUp);
    proxyView.setPosition(proxyEye);
    proxyView.invert();
    for (let i = 0; i < proxyMeshes.length; i += 1) {
      const m = proxyMeshes[i];
      proxyAt.set(m.userData.cellX, target.y, m.userData.cellZ).applyMatrix4(proxyView);
      /* x and y are across the light's view, z is depth into it and negative
       * in front of the camera. The depth range is the shadow camera's own
       * near and far, widened the same way. */
      const d = -proxyAt.z;
      m.visible = Math.abs(proxyAt.x) <= half + proxyReach
        && Math.abs(proxyAt.y) <= half + proxyReach
        && d >= sun.shadow.camera.near - proxyReach
        && d <= sun.shadow.camera.far + proxyReach;
    }
  }

  function updateShadowFocus(target) {
    /* Snapped to a 0.5 m grid. A shadow camera that follows a quad exactly
     * shimmers every texel boundary, and at 3.3 cm per texel that is a
     * crawling edge on every fence in frame. */
    shadowTarget.set(
      Math.round(target.x * 2) / 2,
      Math.round(target.y * 2) / 2,
      Math.round(target.z * 2) / 2,
    );
    seat(sun, SUN_OFFSET, shadowTarget);
    seat(fill, FILL_OFFSET, shadowTarget);
    seat(bounce, BOUNCE_OFFSET, shadowTarget);
    shadowRate.step(shadowTarget);
    /* The dome is centred on the flat origin, so it has to trail the camera
     * or a quad flying 200 m out flies out of its own sky. */
    sky.dome.position.copy(camera.position);
    sky.clouds.position.copy(camera.position);
    cullTo(camera.position);
    /* Gated on the SHADOW target rather than the camera: a proxy matters
     * because it is near the light's box, which follows the craft, and not
     * because it is near the eye. */
    gateProxies(shadowTarget);
  }

  /* Overridable so a sweep can measure the draw call count against the cull
   * radius rather than one value being asserted. Harness only. */
  let cullRadius = cullDefault;
  let cullR2 = cullRadius * cullRadius;
  function setCullRadius(r) {
    cullRadius = r == null ? cullDefault : r;
    cullR2 = cullRadius * cullRadius;
  }
  /*
   * Half a cell, because the test below measures to the NEAREST POINT of a
   * cell and not to its centre.
   *
   * Measuring to the centre makes the radius a lie by up to a cell half
   * diagonal, 28 m here: a cell whose centre is at the radius holds things
   * from 28 m nearer than that to 28 m further, and switching the cell off
   * takes the near ones with it. At the old 145 m radius against a fog that
   * ended at 135 the error was invisible, because everything it could reach
   * was already fog coloured. At 100 m against a fog ending at 95 it reaches
   * 72 m, where the fog is only two thirds of the way in and a building
   * winking out is something you would see.
   *
   * Clamping to the cell's bounds costs two max calls a cell and makes the
   * radius mean the distance it is written as: nothing inside it is ever
   * switched off. The cost is that a cell is only dropped once ALL of it is
   * beyond the radius, which is why the radius could not simply be shortened
   * to 72 instead.
   */
  const cullHalf = cull.cell * 0.5;
  function cullTo(eye) {
    for (let i = 0; i < cull.cells.length; i += 1) {
      const c = cull.cells[i];
      const dx = Math.max(0, Math.abs(eye.x - c.x) - cullHalf);
      const dz = Math.max(0, Math.abs(eye.z - c.z) - cullHalf);
      const d2 = dx * dx + dz * dz;
      if (c.leaves) {
        const near = d2 <= leafR2;
        if (c.leafNear !== near) {
          c.leafNear = near;
          for (let j = 0; j < c.leaves.length; j += 1) {
            const o = c.leaves[j];
            o.geometry = near ? o.userData.leafHi : o.userData.leafLo;
          }
        }
      }
      const on = d2 <= cullR2;
      if (c.on === on) {
        continue;
      }
      c.on = on;
      for (let j = 0; j < c.items.length; j += 1) {
        c.items[j].visible = on;
      }
    }
  }

  /* Nothing on the field's wall clock decoration path exists here: the town's
   * moving parts are all on the fixed step clock in updateAnim. Present so
   * the shell has one call shape for both maps. */
  function updateWind() {}

  /* One frozen answer, so the shell's per frame read allocates nothing
   * here either. A town with no gates has no target and never gains one. */
  const CITY_AIM = { active: false, sceneIndex: -1, correct: true, distance: 0 };

  return {
    id: 'city',
    name: 'The town',
    mode: 'freestyle',
    graphics: q.id,
    scene,
    post: pipeline,
    colliders,
    /* No gates, no racing line, no lap. */
    gates: [],
    curve: null,
    spawn: SPAWN,
    /* Only path, speed, lookAhead and aimDrop are read: see the top of
     * src/render/attract.js. This object used to carry x, y, z, radius, eye
     * and aim as well, left over from the orbit shot the city's flythrough
     * replaced, and they read as live camera settings. */
    attract: {
      path: cityAttractPath(world),
      /* Slower than the field's 13 m/s. The field's shot is a lap of a
       * course and wants to read as racing; this one is a street with things
       * in it, and at 13 m/s a 6 m wide corridor is a blur. */
      speed: 9,
      lookAhead: 13,
      /* Only a little down. The camera is IN the street rather than over the
       * course, so the interest is at eye height and ahead, not below. 2.4
       * over a 13 m look ahead is ten degrees of that held for the whole
       * loop, and it lands on top of whatever the climb is already doing;
       * 1.6 is seven. */
      aimDrop: 1.6,
    },
    /*
     * The contact surface, and the third argument is what makes a city fly.
     * `fromY` is the height the query is made FROM: a platform is only
     * eligible if it is within a step of it, so a quad above the overbridge
     * lands on the deck and a quad under it sees the road.
     */
    height: (x, z, fromY) => world.heightAt(x, z, fromY),
    /* The parts of the town that move and are solid, for the plant to read
     * every step. See solids in ./animation.js. */
    solids: anim.solids,
    /* Where the STF mark is painted, on the corner shop at the end of the
     * spawn's street: see STF_SPOT in ./places/index.js and `egg` in
     * src/maps/README.md. Paint only; nothing about it is solid. */
    egg: places.egg,
    /* Where the partners' marks are painted, one each, by hand: see
     * PARTNER_SPOTS in ./places/index.js and `marks` in src/maps/README.md. */
    marks: places.marks,
    setNextGate() {},
    /* No gates, so nothing is ever the next one. Present so the shell has
     * one call shape for both maps and the target mark stays off here. */
    targetAim: () => CITY_AIM,
    approachSide: () => null,
    /* No gates, so no line to be on or off. Present so the shell has one
     * call shape for both maps. */
    hasRacingLine: false,
    setRacingLine() {},
    updateRacingLine() { return null; },
    updateShadowFocus,
    updateWind,
    /*
     * The town's own step clock, with the two places on the works road
     * hanging off it. Nothing in either of them animates today and the list
     * is empty, but it is wired rather than dropped: a hook that silently
     * swallows an animated part is only ever noticed by a pilot asking why
     * the thing that moves does not. `anim.update` derives its dt from the
     * fixed step count, so anything here is on the physics clock and not on
     * frame time, which is the rule for anything a craft can hit.
     */
    updateAnim: places.updaters.length
      ? (step) => {
        const dt = Math.max(0, Math.min(0.25, (step - placeStep) * 0.001));
        placeStep = step;
        anim.update(step);
        for (const fn of places.updaters) {
          fn(dt);
        }
      }
      : anim.update,
    references,
    setCullRadius,
    world,
    stats: () => ({
      colliders: colliders.stats(),
      cityColliders: world.colliders.length,
      platforms: world.platforms.length,
      platformSlabs: slabs,
      collidersWithNoTop: noTop,
      collidersWithNoBottom: noBottom,
      /* What the geometry fit did to the town's walker rectangles, so the
       * claim that the solid world hugs the drawn one is a measurement
       * rather than a comment. */
      colliderFit: fit,
      /* null unless globalThis.__CITY_SCAN was set before the map was
       * built. See ./scan.js. */
      colliderScan: scan,
      /* null unless globalThis.__CITY_CAVITY was set before the map was
       * built. See ./cavity.js. */
      colliderCavity: cavity,
      trainCarColliders: trainCars.length,
      cullCells: cull.cells.length,
      cullAlways: cull.always.length,
      cullRadius,
      foliageKeep,
      roundLeaves: { ...roundLeaves, radius: leafRound },
      planting: world.planting ?? null,
      places: {
        ...places.stats,
        planting: places.planting,
        sites: places.sites,
      },
      ...thinned,
      ...baked.stats,
      ...chunked,
      /* Nodes whose matrices the frame no longer recomputes, and the ones
       * it still does: see freezeStill in ./bake.js. */
      frozen,
      shadowExtent: half,
      pipelineScale: pipeline.scale,
      pipelineSize: { x: pipeline.size.x, y: pipeline.size.y },
      /* Whether Stage F's edit found its lines: see src/render/manga.js. */
      manga: { lines: pipeline.manga.ok, tone: pipeline.manga.tone },
      ...anim.stats(),
    }),
    dispose() {
      /* The works road's blossom owns three instanced meshes with dynamic
       * buffers and a geometry the three share. `disposeSceneGraph` would
       * find them anyway, since they are in this scene; this frees the shared
       * plane once and takes them out of the graph first, which is what the
       * town's own field gets from index.js's Low branch. */
      if (places.blossom) {
        places.blossom.dispose();
      }
      /* The craft and the ghost rig are the session's. This read the
       * shell live and so never had the field's stale-capture bug, but it
       * named only the craft, and the ghost rig is parented into this same
       * scene whenever one is on screen. The shell keeps the register. */
      shell.evictSessionRoots(scene);
      pipeline.dispose();
      disposeSceneGraph(scene, SESSION_TEXTURES);
      /* A near canopy set shows its blob or its twin (passes 15 and 24),
       * and the walk above freed only the one each set showed last, so a
       * twin drawn once and then left behind stayed on the GPU. Freeing a
       * geometry twice is a no-op. */
      for (const g of leafSwapped) {
        g.dispose();
      }
    },
  };
}
